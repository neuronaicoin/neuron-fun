"use client";

import { useEffect, useState } from "react";
import { db } from "./data";
import { V6 } from "./config";
import { authedPost, type SignFn } from "./alerts";

export type MyPoints = {
  total: number;
  rank: number;
  players: number;
  today: number;
  streak: number;
  quests: string[];
  friends: number;
  friendsPts: number;
};
export type BoardRow = { owner: string; total: number; rank: number };
/** earned/paid/pending: older per-chain rewards in wei; usd*: dollar rewards (race coins, other
 * DEXs' coins, futures) in USDC units (6 decimals), paid in USDC on Base. */
export type Rewards = {
  earned: number;
  paid: number;
  pending: number;
  friends: number;
  friendsTraded: number;
  usdEarned: number;
  usdPaid: number;
  usdPending: number;
};

type Quest = { id: string; icon: string; title: string; note: string; pts: number; href?: string; action?: "follow" | "share" };
const ALL_QUESTS: readonly Quest[] = [
  { id: "follow_x", icon: "𝕏", title: "Follow @sasapadfun on X", note: "News, launches and giveaways", pts: 50, action: "follow" },
  { id: "share_x", icon: "📣", title: "Share sasa on X", note: "Post your invite link or a coin", pts: 100, action: "share" },
  { id: "launch", icon: "🚀", title: "Launch your first coin", note: "Any chain, any idea", pts: 200, href: V6 ? "/create/" : "/race/launch/" },
  { id: "elysium", icon: "🧪", title: "Launch on Elysium testnet", note: "Free with test HYPE. Then 50 a launch (3 a day), 10 a trade (10 a day)", pts: 100, href: "/elysium/" },
  { id: "ai", icon: "✨", title: "Create a coin with AI", note: "Try the AI designer once", pts: 100, href: V6 ? "/create/?ai=1" : "/race/launch/" },
  { id: "buy", icon: "🛒", title: "Make your first buy", note: "Any coin", pts: 50, href: "/explore/" },
  { id: "follow3", icon: "👥", title: "Follow 3 traders", note: "From Traders or a profile", pts: 50, href: "/traders/" },
  { id: "copy", icon: "🪞", title: "Copy a trader", note: "Turn copying on for someone", pts: 100, href: "/traders/" },
  { id: "alert", icon: "🔔", title: "Set a price alert", note: "Tap the bell on any coin", pts: 30, href: "/explore/" },
  { id: "forum", icon: "💬", title: "Post in a coin forum", note: "As a holder", pts: 50, href: "/forum/" },
  { id: "locked", icon: "🔒", title: "Launch with a creator lock", note: "1 hour or 24 hours", pts: 150, href: "/create/" },
];
/** On mainnet, quests that need v6 pages (traders, copy, creator lock) are left out. */
export const QUESTS: readonly Quest[] = V6 ? ALL_QUESTS : ALL_QUESTS.filter((q) => !["follow3", "copy", "locked"].includes(q.id));

/** Marks an X quest done (follow / share). Each counts once; repeats are ignored. */
export async function claimQuest(sign: SignFn, id: "follow_x" | "share_x"): Promise<void> {
  await authedPost<{ ok: boolean }>(sign, "social/quest", { id });
}

const n = (v: unknown) => Number(v ?? 0) || 0;

export async function fetchMyPoints(address: string): Promise<MyPoints | null> {
  const { data, error } = await db.rpc("points_me", { p_owner: address.toLowerCase() });
  if (error) throw error;
  const r = ((data ?? []) as Record<string, unknown>[])[0];
  if (!r) return null;
  return {
    total: n(r.total),
    rank: n(r.rank),
    players: n(r.players),
    today: n(r.today),
    streak: n(r.streak),
    quests: (r.quests as string[] | null) ?? [],
    friends: n(r.friends),
    friendsPts: n(r.friends_pts),
  };
}

export async function fetchBoard(limit = 50): Promise<BoardRow[]> {
  const { data, error } = await db.rpc("points_board", { p_limit: limit });
  if (error) throw error;
  return ((data ?? []) as Record<string, unknown>[]).map((r) => ({ owner: String(r.owner), total: n(r.total), rank: n(r.rank) }));
}

/** Invite + copy rewards: the older ones in wei (summed over chains), the dollar ones in USDC units. */
export async function fetchRewards(address: string): Promise<Rewards | null> {
  const { data, error } = await db.rpc("reward_summary", { p_owner: address.toLowerCase() });
  if (error) return null;
  const r = ((data ?? []) as Record<string, unknown>[])[0];
  if (!r) return null;
  return {
    earned: n(r.earned),
    paid: n(r.paid),
    pending: n(r.pending),
    friends: n(r.friends),
    friendsTraded: n(r.friends_traded),
    usdEarned: n(r.usd_earned),
    usdPaid: n(r.usd_paid),
    usdPending: n(r.usd_pending),
  };
}

/** Streak boost for a day's trading points: 1x, growing to 2x at 7 days in a row. */
export const boostFor = (streak: number) => Math.min(2, 1 + Math.max(0, streak - 1) / 6);

// ------------------------------------------------------------------ invites

const REF_KEY = "sasa-ref";

/** Remembers an invite (?ref=) for 30 days, until the visitor is signed in. */
export function rememberRef() {
  try {
    const ref = new URLSearchParams(window.location.search).get("ref");
    if (ref && /^@?[a-zA-Z0-9_]{2,42}$/.test(ref)) {
      localStorage.setItem(REF_KEY, JSON.stringify({ ref: ref.replace(/^@/, ""), at: Date.now() }));
    }
  } catch {}
}

export function pendingRef(): string | null {
  try {
    const v = JSON.parse(localStorage.getItem(REF_KEY) ?? "null");
    if (!v || typeof v.ref !== "string" || Date.now() - v.at > 30 * 86400e3) return null;
    return v.ref;
  } catch {
    return null;
  }
}

export async function claimRef(sign: SignFn, ref: string): Promise<{ ok: boolean; reason?: string }> {
  const r = await authedPost<{ ok: boolean; reason?: string }>(sign, "social/referral", { ref });
  // Done either way: accepted, or it can never apply to this wallet.
  try {
    localStorage.removeItem(REF_KEY);
  } catch {}
  return r;
}

/** Your points total, for the header. Refreshes every 2 minutes. */
export function useMyTotal(address: string | null | undefined): number | null {
  const [total, setTotal] = useState<number | null>(null);
  useEffect(() => {
    if (!address) {
      setTotal(null);
      return;
    }
    let alive = true;
    const load = () =>
      fetchMyPoints(address)
        .then((p) => alive && setTotal(p?.total ?? 0))
        .catch(() => {});
    load();
    const t = setInterval(load, 120_000);
    return () => {
      alive = false;
      clearInterval(t);
    };
  }, [address]);
  return total;
}

// ------------------------------------------------------------------ airdrop activity

/** What counts toward the future airdrop: coins created and dollars traded (mainnet). */
export type Airdrop = { coins: number; traded: number; rank: number; players: number };
export type AirdropRow = { owner: string; coins: number; traded: number; rank: number };

export async function fetchMyAirdrop(address: string): Promise<Airdrop | null> {
  const { data, error } = await db.rpc("airdrop_me", { p_owner: address.toLowerCase() });
  if (error) throw error;
  const r = ((data ?? []) as Record<string, unknown>[])[0];
  if (!r) return null;
  return { coins: n(r.coins), traded: n(r.traded_usd), rank: n(r.rank), players: n(r.players) };
}

export async function fetchAirdropBoard(limit = 100): Promise<AirdropRow[]> {
  const { data, error } = await db.rpc("airdrop_board", { p_limit: limit });
  if (error) throw error;
  return ((data ?? []) as Record<string, unknown>[]).map((r) => ({ owner: String(r.owner), coins: n(r.coins), traded: n(r.traded_usd), rank: n(r.rank) }));
}

/** Your place on the airdrop list, for the header (0 = not on it yet). Refreshes every 2 minutes. */
export function useMyAirdrop(address: string | null | undefined): Airdrop | null {
  const [a, setA] = useState<Airdrop | null>(null);
  useEffect(() => {
    if (!address) {
      setA(null);
      return;
    }
    let alive = true;
    const load = () =>
      fetchMyAirdrop(address)
        .then((x) => alive && setA(x ?? { coins: 0, traded: 0, rank: 0, players: 0 }))
        .catch(() => {});
    load();
    const t = setInterval(load, 120_000);
    return () => {
      alive = false;
      clearInterval(t);
    };
  }, [address]);
  return a;
}
