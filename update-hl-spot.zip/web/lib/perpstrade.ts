"use client";

/**
 * Perps trading on Hyperliquid (orders, money in and out). Read-only data is in lib/perps.ts.
 *
 * Signing: Hyperliquid's trading messages are signed for its own chain (1337), which browser
 * wallets refuse while on another chain, so wallet users approve a trading key once (an
 * "agent", kept in this browser; it can trade but never move money out). Email accounts sign
 * with their own key directly. Two approvals happen once, on the first trade: sasa's 0.07%
 * builder fee, and (wallets) the trading key.
 *
 * Money in: Base USDC → the user's Hyperliquid perps balance, through Relay (one Base step).
 * Money out: Hyperliquid sends it (minus its ~$1 fee) to a Relay deposit address on Arbitrum,
 * which delivers USDC to the user's address on Base.
 */
import { useMemo } from "react";
import type { Address, Chain, Hex, LocalAccount, WalletClient } from "viem";
import type { IRequestTransport } from "@nktkas/hyperliquid";
import type { Call } from "./tx";
import { generatePrivateKey, privateKeyToAccount } from "viem/accounts";
import { ExchangeClient, HttpTransport, InfoClient } from "@nktkas/hyperliquid";
import { useWallet } from "@/components/wallet";
import { CHAINS, HL_BUILDER } from "./config";
import { getQuote } from "./relay";
import { quoteCallsOn } from "./extcross";
import { BUILDER_FEE, BUILDER_FEE_TENTHS_BP, HL_API, HL_TAKER_FEE, MIN_NOTIONAL, PERPS_TRADING, fetchPerpAccount, priceString, sizeString, type PerpMarket, type PerpOrder, type PerpPosition } from "./perps";
import { baseCashUsd, transitAdd, transitToCash } from "./transit";
import { cashOf } from "./portfolio";
import { SPOT_FEE_TENTHS_BP, SPOT_MIN, spotPrice, type HlSpot } from "./hlspot";
import { PREDICT_FEE_TENTHS_BP, PREDICT_MIN, bestOf, fetchPredictWallet, type PredictHolding, type PredictOutcome } from "./predict";

/** Hyperliquid's perps USDC, as Relay names it. */
const HL_PERPS_USDC = "0x00000000000000000000000000000000";
const HL_CHAIN_ID = 1337;
const ARBITRUM = 42161;
const ARBITRUM_USDC = "0xaf88d065e77c8cC2239327C5EDb3A432268e5831";
/** Hyperliquid's withdrawal fee (dollars), taken from what is moved out. */
export const HL_WITHDRAW_FEE = 1;
export const MIN_MOVE = 10; // the route fee is about a dollar: below $10 it eats too much
/** How far a market order may fill from the mark price (open) and when closing. */
const SLIP_OPEN = 0.01;
const SLIP_CLOSE = 0.02;
const AGENT_NAME = "sasa";
/** The key sasa copies trades with (copy trading): its own name, so it never replaces the trading key. */
const COPY_AGENT_NAME = "sasa copy";

/** `limitPx`: a limit order that waits at that price; none: a market order. */
export type OpenOrder = { market: PerpMarket; side: "long" | "short"; margin: number; lev: number; coins: string; tp: number | null; sl: number | null; limitPx?: number | null };
export type PerpsTrade = {
  deposit: (amount: number, onStep: (m: string | null) => void) => Promise<void>;
  withdraw: (amount: number, onStep: (m: string | null) => void) => Promise<void>;
  open: (o: OpenOrder, onStep: (m: string | null) => void) => Promise<{ avgPx: number | null; resting?: boolean }>;
  /** Closes all of a position, or a part (fraction 0.25 = a quarter). */
  close: (p: PerpPosition, m: PerpMarket | null, fraction?: number) => Promise<void>;
  /** Sets (or removes, with null) the take profit and stop loss of an open position. */
  setTpsl: (p: PerpPosition, m: PerpMarket | null, t: { tp: number | null; sl: number | null }, current: PerpOrder[]) => Promise<void>;
  cancel: (o: PerpOrder, m: PerpMarket | null) => Promise<void>;
  /** Buys `usd` dollars of one side of a prediction; money comes from Predict cash, then futures, then Base cash. */
  predictBuy: (o: PredictOutcome, side: 0 | 1, usd: number, onStep: (m: string | null) => void) => Promise<{ shares: number; avgPx: number | null }>;
  /** Sells all the shares of a holding at the best price on offer. */
  predictSell: (h: PredictHolding, onStep: (m: string | null) => void) => Promise<{ usd: number | null }>;
  /** Approves sasa's copy-trading key (it trades, never withdraws) and sasa's fee, once. */
  approveCopy: (agent: string, onStep: (m: string | null) => void) => Promise<void>;
  /** Buys `usd` dollars of a Hyperliquid spot token; money comes from the spot balance, then futures, then Base cash. */
  spotBuy: (m: HlSpot, usd: number, onStep: (m: string | null) => void) => Promise<{ amount: number; avgPx: number | null }>;
  /** Sells `amount` of a Hyperliquid spot token; the dollars stay in the Hyperliquid balance. */
  spotSell: (m: HlSpot, amount: number, onStep: (m: string | null) => void) => Promise<{ usd: number | null }>;
  /** Moves Predict cash back to the futures balance. */
  predictToFutures: (amount: number, onStep: (m: string | null) => void) => Promise<void>;
};

const defaultTransport = new HttpTransport({ apiUrl: HL_API });
const defaultInfo = new InfoClient({ transport: defaultTransport });
const agentKey = (user: string) => `sasa.hl.agent.${user.toLowerCase()}`;

function readAgent(store: Pick<Storage, "getItem"> | null, user: string): `0x${string}` | null {
  try {
    const k = store?.getItem(agentKey(user));
    return k && /^0x[0-9a-f]{64}$/i.test(k) ? (k as `0x${string}`) : null;
  } catch {
    return null;
  }
}

/** Hyperliquid's error text, in plain words where we know it. */
export function hlError(e: unknown): Error {
  const m = String((e as { message?: string })?.message ?? e);
  if (/insufficient margin|not enough/i.test(m)) return new Error("Not enough in your futures balance for that.");
  if (/could not immediately match|no resting orders/i.test(m)) return new Error("The price moved too fast. Try again.");
  if (/minimum value|min.*\$10/i.test(m)) return new Error("The smallest position is $10 (amount × leverage).");
  if (/builder fee has not been approved|builder/i.test(m) && /approv/i.test(m)) return new Error("Trading isn't approved yet. Try again to approve it.");
  if (/does not exist|user or api wallet/i.test(m)) return new Error("Your futures account isn't set up yet. Add money first.");
  if (/rejected|denied|user rejected/i.test(m)) return new Error("You cancelled it in your wallet.");
  return new Error(m.length > 160 ? `${m.slice(0, 160)}…` : m);
}

/** What trading needs from the wallet (lib/perpstrade tests pass their own). */
export type TradeDeps = {
  address: string | null;
  embeddedSigner: LocalAccount | null;
  walletClient: (chain: Chain) => WalletClient;
  send: (chain: Chain, calls: Call[], onStep?: (m: string) => void) => Promise<Hex>;
  transport?: IRequestTransport;
  storage?: Pick<Storage, "getItem" | "setItem">;
};

export function usePerpsTrade(after: () => Promise<void>): PerpsTrade {
  const w = useWallet();
  return useMemo(
    () => makePerpsTrade({ address: w.address ?? null, embeddedSigner: w.embeddedSigner, walletClient: w.walletClient, send: w.send }, after),
    [w.address, w.embeddedSigner, w.walletClient, w.send, after]
  );
}

export function makePerpsTrade(w: TradeDeps, after: () => Promise<void>): PerpsTrade {
  {
    const transport = w.transport ?? defaultTransport;
    const infoClient = w.transport ? new InfoClient({ transport }) : defaultInfo;
    const store = w.storage ?? (typeof localStorage !== "undefined" ? localStorage : null);
    const base = CHAINS.find((c) => c.key === "base");
    const user = w.address as Address | null;

    /** The user's own key: signs approvals and moving money out. */
    function mainClient(): ExchangeClient {
      if (!user) throw new Error("Log in first.");
      if (w.embeddedSigner) return new ExchangeClient({ transport, wallet: w.embeddedSigner, signatureChainId: "0x2105" });
      if (!base) throw new Error("Base isn't set up on this site.");
      // the browser wallet, signing on Base (Hyperliquid accepts any chain for these approvals)
      const wc = w.walletClient(base.chain);
      const wallet = {
        signTypedData: (p: object) => wc.signTypedData({ account: user, ...(p as object) } as never) as Promise<`0x${string}`>,
        getAddresses: async () => [user] as `0x${string}`[],
        getChainId: () => wc.getChainId(),
      };
      return new ExchangeClient({ transport, wallet });
    }

    /** sasa's fee approved once; wallets: a trading key approved once. Returns the client that trades. */
    /** `feeTenths`: the highest sasa fee this kind of trade carries (predictions: PREDICT_FEE_TENTHS_BP). */
    async function ready(onStep: (m: string | null) => void, feeTenths = BUILDER_FEE_TENTHS_BP): Promise<ExchangeClient> {
      if (!PERPS_TRADING) throw new Error("Trading opens at mainnet.");
      if (!user) throw new Error("Log in first.");
      const max = await infoClient.maxBuilderFee({ user, builder: HL_BUILDER }).catch(() => 0);
      if (Number(max) < feeTenths) {
        onStep("Approve trading (one time)…");
        await mainClient().approveBuilderFee({ maxFeeRate: `${feeTenths / 1000}%`, builder: HL_BUILDER });
      }
      if (w.embeddedSigner) return new ExchangeClient({ transport, wallet: w.embeddedSigner, signatureChainId: "0x2105" });
      let key = readAgent(store, user);
      const agents = await infoClient.extraAgents({ user }).catch(() => [] as { address: string; validUntil: number | null }[]);
      const live = key && agents.some((a) => a.address.toLowerCase() === privateKeyToAccount(key!).address.toLowerCase() && (a.validUntil ?? Number.MAX_SAFE_INTEGER) > Date.now() + 60_000);
      if (!live) {
        key = generatePrivateKey();
        onStep("Approve trading in your wallet (once)…");
        await mainClient().approveAgent({ agentAddress: privateKeyToAccount(key).address, agentName: AGENT_NAME });
        try {
          store?.setItem(agentKey(user), key);
        } catch {
          /* private window: approved again next time */
        }
      }
      return new ExchangeClient({ transport, wallet: privateKeyToAccount(key!) });
    }

    const builder = { b: HL_BUILDER as `0x${string}`, f: BUILDER_FEE_TENTHS_BP };

    /**
     * Stocks, commodities and indices live on Hyperliquid's builder exchanges (HIP-3). Their
     * margin is drawn from the same futures balance once "dex abstraction" is on: switched on
     * here the first time, by the trading key (or the email account itself), no extra popup.
     */
    async function builderDexReady(ex: ExchangeClient, onStep: (m: string | null) => void) {
      if (!user) throw new Error("Log in first.");
      const mode = await infoClient.userAbstraction({ user }).catch(() => null);
      if (mode === "unifiedAccount" || mode === "portfolioMargin") return;
      if ((await infoClient.userDexAbstraction({ user }).catch(() => null)) === true) return;
      onStep("Turning on stocks & commodities (one time)…");
      try {
        if (w.embeddedSigner) await ex.userDexAbstraction({ user, enabled: true });
        else await ex.agentEnableDexAbstraction();
      } catch (e) {
        throw hlError(e);
      }
    }

    // ------------------------------------------------------------------ predictions (HIP-4)

    let usdcToken: string | null = null;
    /** "USDC:0x…", as Hyperliquid's transfers name it. */
    async function usdcName(): Promise<string> {
      if (usdcToken) return usdcToken;
      const meta = await infoClient.spotMeta();
      const t = meta.tokens.find((x) => x.name === "USDC");
      if (!t) throw new Error("Hyperliquid's USDC isn't listed right now. Try again in a moment.");
      usdcToken = `${t.name}:${t.tokenId}`;
      return usdcToken;
    }
    const predictCash = async () => (await fetchPredictWallet(user!).catch(() => ({ cash: 0, holdings: [] }))).cash;
    /** One balance for spot and futures (Hyperliquid's unified / portfolio margin accounts): nothing to move. */
    const unified = async () => {
      const mode = await infoClient.userAbstraction({ user: user! }).catch(() => null);
      return mode === "unifiedAccount" || mode === "portfolioMargin";
    };
    /** Moves `amount` dollars between futures and Predict (spot), by the trading key or the email account itself. */
    async function moveUsdc(ex: ExchangeClient, amount: number, toFutures: boolean) {
      const a = (Math.floor(amount * 100) / 100).toFixed(2);
      if (!(Number(a) > 0)) return;
      if (w.embeddedSigner) await ex.usdClassTransfer({ amount: a, toPerp: toFutures });
      else
        await ex.agentSendAsset({
          destination: user as `0x${string}`,
          sourceDex: toFutures ? "spot" : "",
          destinationDex: toFutures ? "" : "spot",
          token: await usdcName(),
          amount: a,
        });
    }
    /** Places an order with sasa's prediction fee; if Hyperliquid won't take a builder fee here, without it. */
    async function predictOrder(ex: ExchangeClient, order: Parameters<ExchangeClient["order"]>[0]["orders"][number], fee = PREDICT_FEE_TENTHS_BP) {
      try {
        return await ex.order({ orders: [order], grouping: "na", builder: { b: HL_BUILDER as `0x${string}`, f: fee } });
      } catch (e) {
        const m = String((e as { message?: string })?.message ?? e);
        if (/builder/i.test(m) && !/approv/i.test(m)) return await ex.order({ orders: [order], grouping: "na" });
        throw e;
      }
    }
    const filledOf = (res: Awaited<ReturnType<ExchangeClient["order"]>>) => {
      const first = res.response.data.statuses[0];
      if (first && typeof first === "object" && "filled" in first) return { sz: Number(first.filled.totalSz), px: Number(first.filled.avgPx) };
      return null;
    };
    /** Prices in Hyperliquid's outcome range, rounded to 0.001 (a multiple of every tick it uses). */
    const pricePx = (v: number, up: boolean) => Math.min(0.999, Math.max(0.001, (up ? Math.ceil(v * 1000) : Math.floor(v * 1000)) / 1000)).toFixed(3);

    const futuresFree = async () => Number((await infoClient.clearinghouseState({ user: user! }).catch(() => null))?.withdrawable ?? 0);
    /** The futures balance as the header counts it (all its exchanges), for "has it landed". */
    const futuresValue = async () => (await fetchPerpAccount(user!).catch(() => null))?.accountValue ?? 0;

    /**
     * Makes sure the futures balance can pay `need` dollars: the difference (at least $5, Relay's
     * smallest move) comes from the user's cash on Base, then the order waits for it to land.
     */
    async function fundFutures(need: number, onStep: (m: string | null) => void) {
      if (!user || !base) throw new Error("Log in first.");
      const have = await futuresFree();
      if (have + 1e-6 >= need) return;
      const top = Math.max(MIN_MOVE, Math.ceil(((need - have) * 1.02 + 0.25) * 100) / 100);
      const cash = Number(await cashOf(base, user)) / 1e6;
      if (cash + 1e-6 < top)
        throw new Error(
          have + cash + 1e-6 >= need
            ? `Futures takes at least $${MIN_MOVE} from your cash at a time, and you have $${cash.toFixed(2)}. Add a little money first.`
            : `Not enough money: $${have.toFixed(2)} in futures and $${cash.toFixed(2)} cash. Add money first.`
        );
      onStep(`Moving $${top.toFixed(2)} from your cash to futures…`);
      const q = await getQuote({
        user,
        recipient: user,
        originChainId: base.chain.id,
        originCurrency: base.usdc,
        destinationChainId: HL_CHAIN_ID,
        destinationCurrency: HL_PERPS_USDC,
        amount: String(Math.round(top * 1e6)),
      });
      const inFutures = await futuresValue();
      await w.send(base.chain, quoteCallsOn(q, base.chain.id), (s) => onStep(s));
      transitAdd(top, { to: "futures", futuresAtLeast: inFutures + top * 0.9, ms: 600_000, etaMs: 45_000 });
      void after();
      onStep("Waiting for the money to land in futures…");
      const until = Date.now() + 120_000;
      while (Date.now() < until) {
        await new Promise((r) => setTimeout(r, 2_000));
        if ((await futuresFree()) + 1e-6 >= need) return;
      }
      throw new Error(`Your $${top.toFixed(2)} is on its way to futures (usually under a minute). Tap again in a moment.`);
    }

    return {
      async deposit(amount, onStep) {
        if (!PERPS_TRADING) throw new Error("Trading opens at mainnet.");
        if (!user || !base) throw new Error("Log in first.");
        if (!(amount >= MIN_MOVE)) throw new Error(`The smallest amount is $${MIN_MOVE}.`);
        onStep("Getting the route…");
        const q = await getQuote({
          user,
          recipient: user,
          originChainId: base.chain.id,
          originCurrency: base.usdc,
          destinationChainId: HL_CHAIN_ID,
          destinationCurrency: HL_PERPS_USDC,
          amount: String(Math.round(amount * 1e6)),
        });
        const inFutures = await futuresValue();
        await w.send(base.chain, quoteCallsOn(q, base.chain.id), (m) => onStep(m));
        // on its way for under a minute: still counted in the total, and shown as on its way
        transitAdd(amount, { to: "futures", futuresAtLeast: inFutures + amount * 0.9, ms: 600_000, etaMs: 45_000 });
        onStep(null);
        setTimeout(() => void after(), 8_000);
        setTimeout(() => void after(), 30_000);
      },

      async withdraw(amount, onStep) {
        if (!PERPS_TRADING) throw new Error("Trading opens at mainnet.");
        if (!user || !base) throw new Error("Log in first.");
        if (!(amount >= MIN_MOVE)) throw new Error(`The smallest amount is $${MIN_MOVE}.`);
        onStep("Getting the route…");
        // a one-time Relay address on Arbitrum that delivers to the user's address on Base
        const q = await getQuote({
          user,
          recipient: user,
          originChainId: ARBITRUM,
          originCurrency: ARBITRUM_USDC,
          destinationChainId: base.chain.id,
          destinationCurrency: base.usdc,
          amount: String(Math.round((amount - HL_WITHDRAW_FEE) * 1e6)),
          useDepositAddress: true,
          refundTo: user,
        });
        if (!q.depositAddress || !/^0x[0-9a-fA-F]{40}$/.test(q.depositAddress)) throw new Error("This route isn't available right now. Try again in a moment.");
        onStep("Confirm in your wallet…");
        const cashBefore = await baseCashUsd(user);
        try {
          await mainClient().withdraw3({ destination: q.depositAddress as `0x${string}`, amount: String(amount) });
        } catch (e) {
          throw hlError(e);
        }
        // Hyperliquid's own bridge takes a few minutes: counted in the total meanwhile, and shown
        transitToCash(amount - HL_WITHDRAW_FEE, cashBefore, { ms: 20 * 60_000, etaMs: 4 * 60_000 });
        onStep(null);
        setTimeout(() => void after(), 5_000);
      },

      async open(o, onStep) {
        const ex = await ready(onStep);
        const m = o.market;
        const buy = o.side === "long";
        // the margin and the fee, brought over from the cash balance when futures holds less
        await fundFutures(o.margin + o.margin * o.lev * (HL_TAKER_FEE * (m.dex ? 2 : 1) + BUILDER_FEE) + 0.05, onStep);
        if (m.dex) await builderDexReady(ex, onStep);
        try {
          onStep(`Setting ${o.lev}x…`);
          await ex.updateLeverage({ asset: m.index, isCross: false, leverage: o.lev });
          onStep("Opening…");
          const orders: Parameters<ExchangeClient["order"]>[0]["orders"] = [
            o.limitPx
              ? { a: m.index, b: buy, p: priceString(o.limitPx, m.szDecimals), s: o.coins, r: false, t: { limit: { tif: "Gtc" } } }
              : { a: m.index, b: buy, p: priceString(m.mark * (buy ? 1 + SLIP_OPEN : 1 - SLIP_OPEN), m.szDecimals), s: o.coins, r: false, t: { limit: { tif: "Ioc" } } },
          ];
          for (const [kind, at] of [["tp", o.tp], ["sl", o.sl]] as const) {
            if (!at) continue;
            // closing side; the limit is a 10% slippage bound behind the trigger
            orders.push({
              a: m.index,
              b: !buy,
              p: priceString(at * (buy ? 0.9 : 1.1), m.szDecimals),
              s: o.coins,
              r: true,
              t: { trigger: { isMarket: true, triggerPx: priceString(at, m.szDecimals), tpsl: kind } },
            });
          }
          const res = await ex.order({ orders, grouping: orders.length > 1 ? "normalTpsl" : "na", builder });
          const first = res.response.data.statuses[0];
          onStep(null);
          void after();
          if (first && typeof first === "object" && "filled" in first) return { avgPx: Number(first.filled.avgPx) };
          if (o.limitPx && first && typeof first === "object" && "resting" in first) return { avgPx: null, resting: true };
          throw new Error("The order didn't fill. Try again.");
        } catch (e) {
          throw hlError(e);
        }
      },

      async close(p, m, fraction = 1) {
        if (!m) throw new Error("This market isn't loaded yet.");
        const all = !(fraction > 0 && fraction < 1);
        const size = all ? sizeString(Math.abs(p.size), m.szDecimals) : sizeString(Math.abs(p.size) * fraction, m.szDecimals);
        // a part must still be a real order, and leave a real position behind
        // (with room: the order's limit sits a little under the price)
        if (!all && (Number(size) * m.mark < MIN_NOTIONAL * 1.05 || (Math.abs(p.size) - Number(size)) * m.mark < MIN_NOTIONAL * 1.05))
          throw new Error(`That part is too small (the smallest order is $${MIN_NOTIONAL}). Close all of it instead.`);
        if (!(Number(size) > 0)) throw new Error("Nothing to close.");
        const ex = await ready(() => {});
        const buy = p.side === "short";
        try {
          await ex.order({
            orders: [{ a: m.index, b: buy, p: priceString(m.mark * (buy ? 1 + SLIP_CLOSE : 1 - SLIP_CLOSE), m.szDecimals), s: size, r: true, t: { limit: { tif: "Ioc" } } }],
            grouping: "na",
            builder,
          });
        } catch (e) {
          throw hlError(e);
        }
        void after();
      },

      async setTpsl(p, m, t, current) {
        if (!m) throw new Error("This market isn't loaded yet.");
        const long = p.side === "long";
        const ref = m.mark;
        if (t.tp && (long ? t.tp <= ref : t.tp >= ref)) throw new Error(`Take profit must be ${long ? "above" : "below"} the price.`);
        if (t.sl && (long ? t.sl >= ref : t.sl <= ref)) throw new Error(`Stop loss must be ${long ? "below" : "above"} the price.`);
        if (t.sl && p.liq && (long ? t.sl <= p.liq : t.sl >= p.liq)) throw new Error("Stop loss is past the liquidation price.");
        const ex = await ready(() => {});
        const size = sizeString(Math.abs(p.size), m.szDecimals);
        const old = current.filter((o) => o.coin === p.coin && (o.tpsl === "tp" || o.tpsl === "sl"));
        try {
          // the new ones first, so the position is never left without them; then the old ones go
          const orders: Parameters<ExchangeClient["order"]>[0]["orders"] = [];
          for (const [kind, at] of [["tp", t.tp], ["sl", t.sl]] as const) {
            if (!at) continue;
            orders.push({
              a: m.index,
              b: !long,
              p: priceString(at * (long ? 0.9 : 1.1), m.szDecimals),
              s: size,
              r: true,
              t: { trigger: { isMarket: true, triggerPx: priceString(at, m.szDecimals), tpsl: kind } },
            });
          }
          if (orders.length) {
            try {
              await ex.order({ orders, grouping: "na", builder });
            } catch (e) {
              // part of it may have gone through (the SDK throws if any order fails): look at what is
              // open now, and drop only the old ones that a new one replaced, so nothing is doubled
              const oldIds = new Set(old.map((o) => o.oid));
              const now = (await infoClient.frontendOpenOrders({ user: user! }).catch(() => [])) as { coin: string; oid: number; orderType: string }[];
              const kinds = new Set(
                now
                  .filter((o) => o.coin === p.coin && !oldIds.has(o.oid))
                  .map((o) => (/take profit/i.test(o.orderType) ? "tp" : /stop/i.test(o.orderType) ? "sl" : ""))
              );
              const gone = old.filter((o) => o.tpsl && kinds.has(o.tpsl));
              if (gone.length) await ex.cancel({ cancels: gone.map((o) => ({ a: m.index, o: o.oid })) }).catch(() => {});
              throw e;
            }
          }
          // the old ones go: those replaced, and those removed (box left empty)
          if (old.length) {
            try {
              await ex.cancel({ cancels: old.map((o) => ({ a: m.index, o: o.oid })) });
            } catch {
              throw new Error("The new TP/SL is set, but an old one couldn't be removed. Cancel it in TP/SL & orders.");
            }
          }
        } catch (e) {
          throw hlError(e);
        }
        void after();
      },

      async predictBuy(o, side, usd, onStep) {
        if (!o.tradable) throw new Error("This prediction can't be bought here yet.");
        const s = o.sides[side];
        const ex = await ready(onStep, PREDICT_FEE_TENTHS_BP);
        onStep("Getting the price…");
        const { ask } = await bestOf(s.coin);
        if (!ask) throw new Error(`No one is selling "${s.name}" right now. Try the other side or a moment later.`);
        // a market order: up to 3% over the best offer, never past 0.999
        const px = pricePx(ask * 1.03, true);
        const shares = Math.floor(usd / Number(px));
        if (shares * Number(px) < PREDICT_MIN) throw new Error(`The smallest prediction is $${PREDICT_MIN}.`);
        const cost = shares * Number(px);
        try {
          if (!(await unified())) {
            const have = await predictCash();
            if (have + 1e-6 < cost) {
              const need = Math.ceil((cost - have + 0.05) * 100) / 100;
              await fundFutures(need, onStep);
              onStep("Moving money to Predict…");
              await moveUsdc(ex, need, false);
              const until = Date.now() + 20_000;
              while ((await predictCash()) + 1e-6 < cost && Date.now() < until) await new Promise((r) => setTimeout(r, 1_500));
            }
          }
          onStep(`Buying ${s.name}…`);
          const res = await predictOrder(ex, { a: s.asset, b: true, p: px, s: String(shares), r: false, t: { limit: { tif: "Ioc" } } });
          const f = filledOf(res);
          onStep(null);
          void after();
          if (!f || !(f.sz > 0)) throw new Error("The price moved before it filled. Try again.");
          return { shares: f.sz, avgPx: f.px || null };
        } catch (e) {
          throw hlError(e);
        }
      },

      async predictSell(h, onStep) {
        const shares = Math.floor(h.shares);
        if (!(shares > 0)) throw new Error("Nothing to sell.");
        const ex = await ready(onStep, PREDICT_FEE_TENTHS_BP);
        onStep("Getting the price…");
        const coin = `#${10 * h.outcome + h.side}`;
        const { bid } = await bestOf(coin);
        if (!bid) throw new Error("No one is buying right now. It pays out by itself when it ends.");
        if (shares * bid < PREDICT_MIN) throw new Error(`Worth under $${PREDICT_MIN}: too small to sell. It pays out by itself when it ends.`);
        try {
          onStep("Selling…");
          const res = await predictOrder(ex, { a: 100_000_000 + 10 * h.outcome + h.side, b: false, p: pricePx(bid * 0.97, false), s: String(shares), r: false, t: { limit: { tif: "Ioc" } } });
          const f = filledOf(res);
          onStep(null);
          void after();
          if (!f || !(f.sz > 0)) throw new Error("The price moved before it filled. Try again.");
          return { usd: f.sz * f.px || null };
        } catch (e) {
          throw hlError(e);
        }
      },

      async spotBuy(m, usd, onStep) {
        if (!PERPS_TRADING) throw new Error("Trading opens at mainnet.");
        if (!(usd >= SPOT_MIN)) throw new Error(`The smallest buy is $${SPOT_MIN}.`);
        const ex = await ready(onStep, SPOT_FEE_TENTHS_BP);
        onStep("Getting the price…");
        const { ask } = await bestOf(m.coin);
        if (!ask) throw new Error(`No one is selling ${m.token} right now. Try again in a moment.`);
        // a market order: up to 2% over the best offer
        const px = spotPrice(ask * 1.02, m.szDecimals);
        const size = sizeString(usd / Number(px), m.szDecimals);
        if (!(Number(size) > 0) || Number(size) * Number(px) < SPOT_MIN) throw new Error(`The smallest buy is $${SPOT_MIN}.`);
        const cost = Number(size) * Number(px);
        try {
          if (!(await unified())) {
            const have = await predictCash();
            if (have + 1e-6 < cost) {
              const need = Math.ceil((cost - have + 0.05) * 100) / 100;
              await fundFutures(need, onStep);
              onStep("Moving money to spot…");
              await moveUsdc(ex, need, false);
              const until = Date.now() + 20_000;
              while ((await predictCash()) + 1e-6 < cost && Date.now() < until) await new Promise((r) => setTimeout(r, 1_500));
            }
          }
          onStep(`Buying ${m.token}…`);
          const res = await predictOrder(ex, { a: m.asset, b: true, p: px, s: size, r: false, t: { limit: { tif: "Ioc" } } }, SPOT_FEE_TENTHS_BP);
          const f = filledOf(res);
          onStep(null);
          void after();
          if (!f || !(f.sz > 0)) throw new Error("The price moved before it filled. Try again.");
          return { amount: f.sz, avgPx: f.px || null };
        } catch (e) {
          throw hlError(e);
        }
      },

      async spotSell(m, amount, onStep) {
        if (!PERPS_TRADING) throw new Error("Trading opens at mainnet.");
        const size = sizeString(amount, m.szDecimals);
        if (!(Number(size) > 0)) throw new Error("Nothing to sell.");
        const ex = await ready(onStep, SPOT_FEE_TENTHS_BP);
        onStep("Getting the price…");
        const { bid } = await bestOf(m.coin);
        if (!bid) throw new Error(`No one is buying ${m.token} right now. Try again in a moment.`);
        if (Number(size) * bid < SPOT_MIN) throw new Error(`Worth under $${SPOT_MIN}: Hyperliquid's smallest order.`);
        try {
          onStep(`Selling ${m.token}…`);
          const res = await predictOrder(ex, { a: m.asset, b: false, p: spotPrice(bid * 0.98, m.szDecimals), s: size, r: false, t: { limit: { tif: "Ioc" } } }, SPOT_FEE_TENTHS_BP);
          const f = filledOf(res);
          onStep(null);
          void after();
          if (!f || !(f.sz > 0)) throw new Error("The price moved before it filled. Try again.");
          return { usd: f.sz * f.px || null };
        } catch (e) {
          throw hlError(e);
        }
      },

      async approveCopy(agent, onStep) {
        if (!PERPS_TRADING) throw new Error("Trading opens at mainnet.");
        if (!user) throw new Error("Log in first.");
        if (!/^0x[0-9a-fA-F]{40}$/.test(agent)) throw new Error("Copying isn't ready. Try again.");
        try {
          const max = await infoClient.maxBuilderFee({ user, builder: HL_BUILDER }).catch(() => 0);
          if (Number(max) < BUILDER_FEE_TENTHS_BP) {
            onStep("Approve trading (one time)…");
            await mainClient().approveBuilderFee({ maxFeeRate: `${BUILDER_FEE_TENTHS_BP / 1000}%`, builder: HL_BUILDER });
          }
          const agents = await infoClient.extraAgents({ user }).catch(() => [] as { address: string; validUntil: number | null }[]);
          const live = agents.some((a) => a.address.toLowerCase() === agent.toLowerCase() && (a.validUntil ?? Number.MAX_SAFE_INTEGER) > Date.now() + 86_400_000);
          if (!live) {
            onStep("Approve copying in your wallet (once)…");
            await mainClient().approveAgent({ agentAddress: agent as `0x${string}`, agentName: COPY_AGENT_NAME });
          }
          onStep(null);
        } catch (e) {
          throw hlError(e);
        }
      },

      async predictToFutures(amount, onStep) {
        if (!(amount > 0)) throw new Error("Nothing to move.");
        const ex = await ready(onStep);
        try {
          onStep("Moving to futures…");
          await moveUsdc(ex, amount, true);
          onStep(null);
          void after();
        } catch (e) {
          throw hlError(e);
        }
      },

      async cancel(o, m) {
        if (!m) throw new Error("This market isn't loaded yet.");
        const ex = await ready(() => {});
        try {
          await ex.cancel({ cancels: [{ a: m.index, o: o.oid }] });
        } catch (e) {
          throw hlError(e);
        }
        void after();
      },
    };
  }
}
