"use client";

import { BoostedRow } from "@/components/boost";

import Link from "next/link";
import { useEffect, useMemo, useRef, useState } from "react";
import { CoinAvatar, useCoins, usd } from "@/components/coins";
import { coinMarketCapUsd } from "@/components/discover";
import { TARGET_USD, V6 } from "@/lib/config";
import { RACE_SUPPLY, coinSupply, fetchRaceCoins, laneUsd, leadLane, raceHref, racePhase, type RaceCoin } from "@/lib/race";
import { coinHref, isImageUrl, type Coin, type SortKey } from "@/lib/data";
import { fetchPrices } from "@/lib/price";
import { Landing } from "@/components/landing";
import { compactUsd } from "@/lib/format";
import { EXT_NETWORKS, SOL_EXT_NETWORK, extHref, extNetwork, fetchAiCoins, fetchExtCoins, fetchSasaSolCoins, isAiCoin, type ExtCoin, type ExtSort } from "@/lib/extcoins";
import { useWallet } from "@/components/wallet";
import { solanaFor } from "@/lib/solana";
import { MERGED_SORTS, rankMerged, type Ranked } from "@/lib/rank";
import { RaceBanner } from "@/components/racepromo";
import { LiveRaces } from "@/components/liveraces";
import { BotBanner, ElysiumBanner } from "@/components/airdropcta";
import { CreatorBonusBanner } from "@/components/creatorbonus";
import { ELYSIUM_LISTED } from "@/lib/elysium";
import { Hero, HeroStrip } from "@/components/hero";
import { PulseStrip } from "@/components/pulse";
import { TopWins } from "@/components/topwins";
import { HolderCount } from "@/components/holderlive";
import { openMoney, useMoney } from "@/lib/portfolio";
import { rememberCoin } from "@/lib/coincache";
import { extHolderKey, fetchHolderLive, raceHolderKey, type HolderLive } from "@/lib/holderlive";

// Sorts that also apply to coins from other DEXs (the rest are about our curves).
// Trending: new and rising meme coins first, every chain mixed (indexer/memes.sql, lib/rank.ts).
const EXT_SORT: Partial<Record<SortKey, ExtSort>> = { trending: "trending", gainers: "gainers", losers: "losers", new: "new" };

/** Explore tabs: v6 sorts on testnet; on mainnet the race tabs replace the bonding-curve ones. */
type Tab = SortKey | "racing" | "winners" | "ai";
const SORTS: { id: Tab; label: string }[] = V6
  ? [
      { id: "trending", label: "Trending" },
      { id: "ai", label: "AI agents" },
      { id: "new", label: "New" },
      { id: "hot", label: "Almost graduating" },
      { id: "bonding", label: "Bonding" },
      { id: "graduated", label: "Graduated" },
      { id: "gainers", label: "Gainers" },
      { id: "losers", label: "Losers" },
    ]
  : [
      { id: "trending", label: "Trending" },
      { id: "ai", label: "AI agents" },
      { id: "new", label: "New" },
      { id: "racing", label: "Racing now" },
      { id: "winners", label: "Winners" },
      { id: "gainers", label: "Gainers" },
      { id: "losers", label: "Losers" },
    ];
/** Explore's chain filter ids (lib/extcoins.ts) → race chain keys (lib/race.ts). */
const RACE_KEY: Record<string, string> = { base: "base", bsc: "bnb", robinhood: "robinhood", arc: "arc" };

// Minimum 24h volume and liquidity, in USD. Liquidity of a coin still on its
// curve is the money in its curves; other DEXs report their pool's liquidity.
const VOLUME_FILTERS = [0, 10_000, 50_000, 100_000, 500_000] as const;
const LIQUIDITY_FILTERS = [0, 5_000, 25_000, 100_000] as const;
const filterLabel = (v: number) => (v === 0 ? "Any" : `$${v >= 1000 ? `${v / 1000}K` : v}+`);

// Coins shown at first and added by each "Load more".
const STEP = 24;

export function Discover({ withLanding = false }: { withLanding?: boolean }) {
  const [tab, setTab] = useState<Tab>("trending");
  // the v6 list only knows its own sorts (and is empty on mainnet anyway)
  // AI agents: the AI-agent coins of every list, ranked like Trending (by real volume)
  const ai = tab === "ai";
  const sort: SortKey = tab === "racing" || tab === "winners" ? "new" : tab === "ai" ? "trending" : tab;
  const [chain, setChain] = useState<string>("all");
  // Solana's coins: a chip of their own, for people who see Solana yet
  const { address: me, restoring } = useWallet();
  const solChip = solanaFor(me);
  useEffect(() => {
    if (!solChip && chain === "solana") setChain("all");
  }, [solChip, chain]);
  const [query, setQuery] = useState("");
  const [search, setSearch] = useState("");
  const { coins, error, reload, hasMore, loadMore, loadingMore } = useCoins(sort, search);
  const [minVol, setMinVol] = useState(0);
  const [minLiq, setMinLiq] = useState(0);
  const [showFilters, setShowFilters] = useState(false);
  const [shown, setShown] = useState(STEP);
  const [growing, setGrowing] = useState(false);
  // A new tab, chain, search or filter starts from the top again.
  useEffect(() => setShown(STEP), [tab, chain, search, minVol, minLiq]);
  const [ethUsd, setEthUsd] = useState<number | null>(null);
  // Coins from every other DEX on the same chains, shown after ours.
  const [ext, setExt] = useState<ExtCoin[] | null>(null);
  const extSort = tab === "racing" || tab === "winners" ? undefined : EXT_SORT[sort];
  // Race coins (mainnet): the race tabs, and the newest races at the top of "New"
  const raceTab = !V6 && (tab === "racing" || tab === "winners" || tab === "new");
  const [races, setRaces] = useState<RaceCoin[] | null>(null);
  // coins on each race coin's price chain (market cap = price × these, not always 1B)
  const [supplies, setSupplies] = useState<Map<string, number>>(new Map());
  useEffect(() => {
    if (!races?.length) return;
    let alive = true;
    void Promise.all(races.map(async (r) => [r.id, await coinSupply(r)] as const)).then((pairs) => {
      if (alive) setSupplies(new Map(pairs));
    });
    return () => {
      alive = false;
    };
  }, [races]);
  useEffect(() => {
    if (!raceTab) {
      setRaces([]);
      return;
    }
    let alive = true;
    const load = () =>
      fetchRaceCoins(Math.min(200, shown + STEP), { only: tab === "racing" ? "racing" : tab === "winners" ? "winners" : undefined, search })
        .then((r) => alive && setRaces(r))
        .catch(() => alive && setRaces((cur) => cur ?? []));
    setRaces(null);
    void load();
    const t = setInterval(() => {
      if (document.visibilityState === "visible") void load();
    }, 15_000);
    return () => {
      alive = false;
      clearInterval(t);
    };
  }, [raceTab, tab, search, shown]);
  // Ask for one step more than shown, so we know whether "Load more" has anything to add.
  const extLimit = shown + STEP;
  const firstExt = useRef(true);
  useEffect(() => {
    firstExt.current = true;
  }, [extSort, chain, search, minVol, minLiq, ai]);
  useEffect(() => {
    if (!extSort) {
      setExt([]);
      return;
    }
    let alive = true;
    // Only a new list blanks the grid; loading more keeps what's on screen.
    if (firstExt.current) setExt(null);
    firstExt.current = false;
    // The list query can take a few seconds and now and then times out: try again a few times
    // (the grid keeps its loading look) before showing an empty list.
    const load = async (tries = 3) => {
      for (let i = 0; i < tries; i++) {
        try {
          const [l, sol] = await Promise.all([
            ai
              ? fetchAiCoins(chain === "all" ? null : chain, search, extLimit, { minVol, minLiq }, solChip)
              : fetchExtCoins(extSort, chain === "all" ? null : chain, search, extLimit, { minVol, minLiq }),
            // All chains, New: Solana coins launched on sasa too (for people who see Solana yet;
            // the other lists rank them on their own numbers, under the Solana chip)
            solChip && chain === "all" && extSort === "new" ? fetchSasaSolCoins(20, search).catch(() => []) : Promise.resolve([] as ExtCoin[]),
          ]);
          if (alive) setExt(sol.length ? [...l, ...sol.filter((c) => !l.some((x) => x.address === c.address))] : l);
          return;
        } catch {
          if (!alive) return;
          if (i < tries - 1) await new Promise((r) => setTimeout(r, 1500 * (i + 1)));
        }
      }
      if (alive) setExt((e) => e ?? []);
    };
    void load();
    const t = setInterval(() => {
      if (document.visibilityState === "visible") void load();
    }, 20_000);
    return () => {
      alive = false;
      clearInterval(t);
    };
  }, [extSort, chain, search, extLimit, minVol, minLiq, solChip, ai]);

  useEffect(() => {
    fetchPrices().then((p) => setEthUsd(p?.ETH ?? null));
  }, []);
  useEffect(() => {
    const t = setTimeout(() => setSearch(query.trim()), 300);
    return () => clearTimeout(t);
  }, [query]);

  const list = useMemo(() => {
    let l = coins ?? [];
    if (ai) l = l.filter((c) => isAiCoin(c.name, c.symbol));
    if (chain !== "all") l = l.filter((c) => c.curves.some((k) => k.chain.key === chain));
    if (minVol > 0) l = l.filter((c) => (ethUsd ? c.volumeNative24h * ethUsd : 0) >= minVol);
    if (minLiq > 0) l = l.filter((c) => (c.totalUsd ?? 0) >= minLiq);
    return l;
  }, [coins, chain, minVol, minLiq, ethUsd, ai]);

  // One fair list: our coins and other DEXs' ranked by the same measure.
  const ranked = useMemo(
    () => (MERGED_SORTS.has(sort) ? rankMerged(list, ext ?? [], sort, ethUsd) : list.map((c) => ({ kind: "ours" as const, coin: c }))),
    [list, ext, sort, ethUsd]
  );
  // race coins first (on a chain, only races that run there), then the rest
  const raceRows = useMemo(() => {
    const l = (races ?? []).filter(
      (r) => (chain === "all" || r.lanes.some((ln) => ln.state !== 3 && ln.chain.key === RACE_KEY[chain])) && !(tab !== "new" && r.lanes.length === 1)
    );
    return minVol > 0 || minLiq > 0 ? l.filter((r) => raceVol(r) >= minVol && raceLiq(r) >= minLiq) : l;
  }, [races, chain, minVol, minLiq, tab]);
  const visible = ranked.slice(0, Math.max(0, shown - raceRows.length));
  const extFull = !!extSort && (ext?.length ?? 0) >= extLimit;
  const canGrow = ranked.length + raceRows.length > shown || hasMore || extFull || (raceTab && (races?.length ?? 0) >= Math.min(200, shown + STEP));
  const filtered = minVol > 0 || minLiq > 0;

  async function grow() {
    setGrowing(true);
    try {
      // Fetch the next page of our coins too when we're about to run out of them.
      if (hasMore && list.length < shown + STEP) await loadMore();
      setShown((n) => n + STEP);
    } finally {
      setGrowing(false);
    }
  }

  const racing = coins?.filter((c) => !c.graduatedOn) ?? [];
  const rows = [...raceRows.slice(0, shown).map((r) => raceRow(r, supplies.get(r.id))), ...visible.map((r) => toRow(r, ethUsd))];
  // live holder counts (and their 15-minute change) for the cards on screen, every 30 seconds
  const hkeys = rows.map((r) => r.hkey ?? "").filter(Boolean).join(",");
  const [holders, setHolders] = useState<Map<string, HolderLive>>(new Map());
  useEffect(() => {
    if (!hkeys) return;
    let alive = true;
    const load = () =>
      fetchHolderLive(hkeys.split(","))
        .then((m) => alive && setHolders(m))
        .catch(() => {});
    void load();
    const t = setInterval(() => document.visibilityState === "visible" && void load(), 30_000);
    return () => {
      alive = false;
      clearInterval(t);
    };
  }, [hkeys]);
  const loading = (!coins && !error) || (raceTab && races === null);
  const moreLoading = !!coins && (growing || (ext === null && !!extSort));

  return (
    <>
    {withLanding && (
      <div className="landing-root">
        <Landing />
      </div>
    )}
    <div className="app-root">
      {/* sasapad.fun for people who aren't logged in: the hero (one line, two buttons, live box).
          Logged in (or coming back logged in) and on /explore/: the bands, straight to the coins. */}
      {withLanding && !me && !restoring ? (
        <div className="max-w-7xl mx-auto"><Hero /><div className="px-4 sm:px-6 pt-3"><CreatorBonusBanner /></div><HeroStrip /></div>
      ) : (
        <div className="max-w-7xl mx-auto">
          {/* phones: balance and Deposit first, like a wallet app; the promo bands live on bigger screens */}
          {me && <BalanceBar />}
          <div className="px-4 sm:px-6 pt-3"><CreatorBonusBanner /></div>
          <div className="hidden sm:block"><ElysiumBanner /><BotBanner /></div>
        </div>
      )}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 pt-3"><PulseStrip /></div>
      <div className="max-w-7xl mx-auto hidden sm:block"><LiveRaces fallback={<RaceBanner />} /></div>
      <div className="max-w-7xl mx-auto"><TopWins /></div>
      <section id="explore" className="max-w-7xl mx-auto pb-8 scroll-mt-20">
        <div className="px-4 sm:px-6 pt-4 sm:pt-6 flex items-center gap-3">
          <h1 className="font-display font-bold text-[1.375rem] sm:text-[1.625rem] tracking-tight shrink-0">Explore</h1>
          <div className="flex-1" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search"
            aria-label="Search coins"
            type="search"
            enterKeyHint="search"
            autoComplete="off"
            onKeyDown={(e) => {
              // a pasted Solana address: Enter opens the coin straight away
              const a = query.trim();
              if (e.key === "Enter" && SOL_ADDR.test(a)) window.location.href = extHref({ network: SOL_EXT_NETWORK.id, address: a });
            }}
            className="h-10 w-full max-w-[13rem] sm:max-w-[20rem] min-w-0 px-3 rounded-xl border border-line bg-paper text-ink placeholder:text-ink-3 focus:border-ink-3 outline-none"
          />
        </div>
        <AddressJump query={query} />

        <SasaLaunches solToo={!!solChip} />
        <div className="px-4 sm:px-6">
          <BoostedRow />
          <AlmostThere coins={racing} />
        </div>

        <div className="mt-3 border-b border-line">
          <div className="ex-tabs flex gap-5 sm:gap-6 overflow-x-auto px-4 sm:px-6" role="tablist" aria-label="Sort coins">
            {SORTS.map((s) => (
              <button
                key={s.id}
                type="button"
                role="tab"
                aria-selected={tab === s.id}
                onClick={(e) => {
                  setTab(s.id);
                  e.currentTarget.scrollIntoView({ inline: "nearest", block: "nearest" });
                }}
                className={
                  "shrink-0 -mb-px py-3 border-b-2 text-[0.9375rem] whitespace-nowrap " +
                  (tab === s.id ? "border-ink text-ink font-semibold" : "border-transparent text-ink-3 font-medium hover:text-ink")
                }
              >
                {s.label}
              </button>
            ))}
          </div>
        </div>

        <div className="px-4 sm:px-6 pt-2.5 flex items-center gap-2">
          <div className="ex-tabs flex-1 min-w-0 flex gap-1 overflow-x-auto" role="group" aria-label="Chain">
            {/* Elysium leads the chain row: sasa is Elysium's launchpad. Its coins live on the
                dedicated Elysium page (separate contracts), so this chip links there rather than
                filtering the grid. The other chains below are live grid filters. */}
            {ELYSIUM_LISTED && (
              <button
                type="button"
                aria-pressed={chain === "elysium"}
                onClick={() => setChain("elysium")}
                className={
                  "shrink-0 h-8 px-3 rounded-lg text-[0.875rem] whitespace-nowrap flex items-center gap-1.5 " +
                  (chain === "elysium" ? "bg-night-2 text-ink font-bold" : "text-ink font-semibold hover:bg-night-2")
                }
              >
                <span className="w-2 h-2 rounded-full shrink-0" style={{ background: "#2e8b7a" }} aria-hidden="true" />
                Elysium
              </button>
            )}
            {[
              // Solana right after Robinhood (for people who see it yet)
              ...EXT_NETWORKS.flatMap((n) => (n.id === "robinhood" && solChip ? [n, SOL_EXT_NETWORK] : [n])).map((n) => ({ key: n.id, short: n.label, color: n.color })),
            ].map((c) => (
              <button
                key={c.key}
                type="button"
                aria-pressed={chain === c.key}
                onClick={() => setChain(c.key)}
                className={
                  "shrink-0 h-8 px-3 rounded-lg text-[0.875rem] whitespace-nowrap flex items-center gap-1.5 " +
                  (chain === c.key ? "bg-night-2 text-ink font-bold" : "text-ink font-semibold hover:bg-night-2")
                }
              >
                {c.color && <span className="w-2 h-2 rounded-full shrink-0" style={{ background: c.color }} aria-hidden="true" />}
                {c.short}
              </button>
            ))}
          </div>
          <button
            type="button"
            onClick={() => setShowFilters((v) => !v)}
            aria-expanded={showFilters}
            className={"shrink-0 h-8 px-3 rounded-lg border text-[0.8125rem] font-medium flex items-center gap-1.5 " + (minVol || minLiq ? "border-ink text-ink" : "border-line text-ink-2")}
          >
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true"><path d="M4 6h16M7 12h10M10 18h4" strokeLinecap="round" /></svg>
            Filters{minVol || minLiq ? ` (${(minVol ? 1 : 0) + (minLiq ? 1 : 0)})` : ""}
          </button>
        </div>
        {showFilters && (
          <div className="px-4 sm:px-6 pt-2.5 grid gap-2 sm:flex sm:flex-wrap sm:gap-4">
            <FilterRow label="Volume 24h" values={VOLUME_FILTERS} value={minVol} onChange={setMinVol} />
            <FilterRow label="Liquidity" values={LIQUIDITY_FILTERS} value={minLiq} onChange={setMinLiq} />
          </div>
        )}

        {error && (
          <div className="mx-4 sm:mx-6 mt-4 p-4 rounded-xl bg-warn-bg text-warn-ink text-[0.9375rem] flex items-center justify-between gap-4">
            <span>{error}</span>
            <button type="button" onClick={reload} className="font-semibold underline shrink-0">Try again</button>
          </div>
        )}

        {/* Every screen: a grid of coin cards (2 columns on phones, up to 5 on wide screens). */}
        {/* Phones: one clean row per coin (picture, name, market cap, change). */}
        <ul className="sm:hidden px-4 pt-2" aria-label="Coins">
          {loading && Array.from({ length: 10 }, (_, i) => <RowSkeleton key={i} />)}
          {rows.map((r) => <CoinRow key={r.key} r={r} />)}
          {moreLoading && Array.from({ length: 3 }, (_, i) => <RowSkeleton key={`m${i}`} />)}
        </ul>
        <ul className="ex-grid hidden sm:grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-2.5 min-[380px]:gap-3 md:gap-4 px-4 sm:px-6 pt-3.5 md:pt-4">
          {loading && Array.from({ length: 10 }, (_, i) => <CardSkeleton key={i} />)}
          {rows.map((r) => <CoinCard key={r.key} r={r} live={r.hkey ? holders.get(r.hkey) : undefined} />)}
          {moreLoading && Array.from({ length: 4 }, (_, i) => <CardSkeleton key={`m${i}`} />)}
        </ul>

        {coins && rows.length > 0 && (
          <div className="mt-5 px-4 flex flex-col items-center gap-2">
            {canGrow ? (
              <button
                type="button"
                onClick={() => void grow()}
                disabled={growing || loadingMore}
                className="h-11 px-8 rounded-xl border border-line text-ink font-semibold hover:bg-night disabled:opacity-50"
              >
                {growing || loadingMore ? "Loading…" : "Load more"}
              </button>
            ) : null}
            <p className="text-[0.75rem] text-ink-3">{canGrow ? `Showing ${rows.length}` : `All ${rows.length} shown`}</p>
          </div>
        )}
        {coins && rows.length === 0 && ext !== null && races !== null && (
          <div className="mx-4 sm:mx-6 mt-5 text-center py-12 border border-dashed border-line rounded-xl">
            <p className="text-ink-2">
              {chain === "elysium"
                ? "Elysium coins launched on sasa are on the Elysium page."
                : filtered
                ? "No coins match these filters."
                : search
                  ? "Nothing matches that search."
                  : tab === "graduated"
                    ? "No graduates yet."
                    : tab === "bonding"
                      ? "No coins on their bonding curve right now."
                      : tab === "racing"
                        ? "No race running right now. Start one."
                        : tab === "winners"
                          ? "No winners yet. Start the first race."
                          : "No coins here yet. Start one."}
            </p>
            {filtered ? (
              <button
                type="button"
                onClick={() => {
                  setMinVol(0);
                  setMinLiq(0);
                }}
                className="inline-flex mt-4 h-11 px-6 rounded-xl border border-line font-semibold items-center"
              >
                Clear filters
              </button>
            ) : chain === "elysium" ? (
              <div className="flex flex-wrap justify-center gap-2 mt-4">
                <Link href="/elysium/" className="inline-flex h-11 px-6 rounded-xl bg-emerald text-on-accent font-semibold items-center">See Elysium coins</Link>
                <Link href="/race/launch/?chain=elysium" className="inline-flex h-11 px-6 rounded-xl border border-line font-semibold items-center">Create a coin</Link>
              </div>
            ) : (
              <Link href="/race/launch/" className="inline-flex mt-4 h-11 px-6 rounded-xl bg-emerald text-on-accent font-semibold items-center">Create a coin</Link>
            )}
          </div>
        )}
      </section>
    </div>
    </>
  );
}

/** A filter row: label, then the minimums. */
function FilterRow({ label, values, value, onChange }: { label: string; values: readonly number[]; value: number; onChange: (v: number) => void }) {
  return (
    <div className="ex-tabs flex items-center gap-1 overflow-x-auto min-w-0" role="group" aria-label={`Minimum ${label.toLowerCase()}`}>
      <span className="shrink-0 pr-2 text-[0.8125rem] font-semibold text-ink whitespace-nowrap">{label}</span>
      {values.map((v) => (
        <button
          key={v}
          type="button"
          aria-pressed={value === v}
          onClick={() => onChange(v)}
          className={
            "shrink-0 h-8 px-3 rounded-lg text-[0.8125rem] whitespace-nowrap " +
            (value === v ? "bg-night-2 text-ink font-semibold" : "text-ink-3 font-medium hover:text-ink")
          }
        >
          {filterLabel(v)}
        </button>
      ))}
    </div>
  );
}

/* ------------------------------------------------------------------ rows */

type Row = {
  key: string;
  href: string;
  name: string;
  symbol: string;
  image: string | null;
  seed: string;
  mc: number | null;
  /** Percent (12.5 = +12.5%). */
  change: number | null;
  vol: number | null;
  liq: number | null;
  holders: number | null;
  since: string | null;
  /** 0..1 while on its curve; null for coins from other DEXs. */
  progress: number | null;
  graduated: boolean;
  graduating: boolean;
  /** Chain name, shown for coins from other DEXs. */
  where: string | null;
  /** Race coins: "Racing" or "Won on Base". */
  badge?: string;
  /** Key for live holder counts (lib/holderlive.ts). */
  hkey?: string;
};

const raceVol = (r: RaceCoin) => r.lanes.reduce((s, l) => s + l.volumeUsd, 0);
const raceLiq = (r: RaceCoin) => (r.totalUsd ?? r.lanes.reduce((s, l) => s + laneUsd(l), 0));

/** A race coin as an Explore card: market cap from the leading (or winning) chain's price. */
function raceRow(r: RaceCoin, supply = RACE_SUPPLY): Row {
  const lead = leadLane(r);
  const price = lead?.priceUsd ?? null;
  const phase = racePhase(r, Date.now());
  const decided = phase === "decided";
  return {
    key: `race:${r.id}`,
    hkey: raceHolderKey(r.id),
    href: raceHref(r.id),
    name: r.name,
    symbol: r.symbol,
    image: r.logo && isImageUrl(r.logo) ? r.logo : null,
    seed: r.id,
    mc: price ? price * supply : null,
    change: null,
    vol: raceVol(r),
    liq: raceLiq(r),
    holders: null,
    since: r.launchedAt ? new Date(r.launchedAt).toISOString() : null,
    progress: null,
    graduated: false,
    graduating: false,
    // a coin launched on one chain doesn't race: it just trades there
    where: r.lanes.length === 1 ? r.lanes[0].chain.short : decided ? (r.winner?.short ?? null) : `${r.lanes.length} chains`,
    badge: r.lanes.length === 1 ? undefined : decided ? (r.winner ? `Won on ${r.winner.short}` : "Finished") : phase === "open" ? "Every chain" : "Racing",
  };
}

function toRow(r: Ranked, ethUsd: number | null): Row {
  if (r.kind === "ours") {
    const c = r.coin;
    return {
      key: c.id,
      href: coinHref(c),
      name: c.name,
      symbol: c.symbol,
      image: c.logo && isImageUrl(c.logo) ? c.logo : null,
      seed: c.id,
      mc: coinMarketCapUsd(c, ethUsd),
      change: c.change24h === null || !Number.isFinite(c.change24h) ? null : c.change24h * 100,
      vol: ethUsd ? c.volumeNative24h * ethUsd : null,
      liq: c.totalUsd,
      holders: c.holders,
      since: c.createdAt,
      progress: c.graduatedOn ? 1 : Math.max(0, Math.min(1, c.progress)),
      graduated: !!c.graduatedOn,
      graduating: c.graduating,
      where: null,
    };
  }
  const c = r.coin;
  return {
    key: `${c.network}:${c.address}`,
    hkey: extHolderKey(c.network, c.address),
    href: extHref(c),
    name: c.name,
    symbol: c.symbol,
    image: c.image,
    seed: c.address,
    mc: c.mcapUsd,
    change: c.change24h,
    vol: c.vol24h,
    liq: c.liqUsd,
    holders: null,
    since: c.poolCreated,
    progress: null,
    graduated: false,
    graduating: false,
    where: extNetwork(c.network)?.label ?? null,
  };
}

/** A stable number from any text (FNV-1a), so each coin keeps its colour. */
function hue(s: string) {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return (h >>> 0) % 360;
}

function Change({ v }: { v: number | null }) {
  if (v === null || !Number.isFinite(v)) return <span className="text-ink-3">—</span>;
  const a = Math.abs(v);
  const text = a >= 1000 ? `${(a / 1000).toFixed(1)}K%` : `${a >= 100 ? a.toFixed(0) : a.toFixed(1)}%`;
  const up = v > 0.05;
  const down = v < -0.05;
  return <span className={up ? "text-up" : down ? "text-danger" : "text-ink-3"}>{(up ? "+" : down ? "−" : "") + text}</span>;
}

/** "3m", "5h", "2d": short, so the row stays one line. */
function age(iso: string | null): string {
  if (!iso) return "—";
  const s = Math.max(0, Math.floor((Date.now() - new Date(iso).getTime()) / 1000));
  if (s < 60) return `${s}s`;
  if (s < 3600) return `${Math.floor(s / 60)}m`;
  if (s < 86400) return `${Math.floor(s / 3600)}h`;
  return `${Math.floor(s / 86400)}d`;
}

// Calm, flat colours for coins without a picture: a soft background and the letter in a deeper tone.
const ART = [
  ["#f4d9c6", "#c2551a"],
  ["#d8e6dc", "#2f7a4f"],
  ["#dbe3f3", "#3557a8"],
  ["#efe2c4", "#9a6b12"],
  ["#e8dbe9", "#7a3f82"],
  ["#d6e9ea", "#22737a"],
  ["#f0d6d6", "#a33a3a"],
  ["#e3e3dc", "#55554c"],
] as const;

function CardArt({ r }: { r: Row }) {
  const [broken, setBroken] = useState(false);
  if (r.image && !broken) {
    // eslint-disable-next-line @next/next/no-img-element
    return <img src={r.image} alt="" loading="lazy" decoding="async" className="absolute inset-0 w-full h-full object-cover" onError={() => setBroken(true)} />;
  }
  const h = hue(r.seed);
  const [bg, fg] = ART[h % ART.length];
  const shape = h % 3;
  return (
    <svg viewBox="0 0 200 200" preserveAspectRatio="xMidYMid slice" className="absolute inset-0 w-full h-full" aria-hidden="true">
      <rect width="200" height="200" fill={bg} />
      {shape === 0 ? (
        <circle cx="100" cy="100" r="58" fill={fg} opacity="0.14" />
      ) : shape === 1 ? (
        <rect x="44" y="44" width="112" height="112" rx="30" fill={fg} opacity="0.12" />
      ) : (
        <path d="M100 38l62 62-62 62-62-62z" fill={fg} opacity="0.12" />
      )}
      <text x="100" y="100" dy="0.35em" textAnchor="middle" fontFamily="-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Arial, sans-serif" fontWeight="700" fontSize="72" fill={fg}>
        {(r.symbol || r.name || "?").slice(0, 1).toUpperCase()}
      </text>
    </svg>
  );
}

/** Launched in the last 15 minutes. */
function isNew(iso: string | null) {
  return !!iso && Date.now() - new Date(iso).getTime() < 15 * 60_000;
}

function CoinCard({ r, live }: { r: Row; live?: HolderLive }) {
  const onCurve = r.progress !== null && !r.graduated && !r.graduating;
  // a short green / red flash on the market cap when it moves
  const lastMc = useRef<number | null>(r.mc);
  const [mcFlash, setMcFlash] = useState("");
  useEffect(() => {
    const was = lastMc.current;
    lastMc.current = r.mc;
    if (was === null || r.mc === null || was === r.mc) return;
    setMcFlash(r.mc > was ? "flash-up" : "flash-down");
    const t = setTimeout(() => setMcFlash(""), 900);
    return () => clearTimeout(t);
  }, [r.mc]);
  const pct = r.progress === null ? 0 : Math.min(99, Math.floor(r.progress * 100));
  return (
    <li className="min-w-0">
      <Link href={r.href} onClick={() => remember(r)} className="ex-card group flex flex-col h-full min-w-0 rounded-[14px] border border-line bg-surface overflow-hidden">
        <span className="relative block aspect-square bg-night overflow-hidden">
          <CardArt r={r} />
          {(r.graduated || r.graduating || r.badge) && (
            <span className="absolute left-2 bottom-2 h-[22px] px-2 rounded-md bg-black/60 text-white text-[0.6875rem] font-semibold flex items-center max-w-[calc(100%-1rem)] truncate">
              {r.badge ?? (r.graduated ? "Graduated" : "Graduating")}
            </span>
          )}
          {live && (
            <span className="absolute left-2 top-2 h-[22px] px-1.5 rounded-md bg-black/65 text-white text-[0.6875rem] font-semibold font-mono flex items-center gap-1 max-w-[calc(100%-1rem)]">
              <span aria-hidden="true">👥</span>
              <HolderCount live={live} compact />
            </span>
          )}
          {isNew(r.since) && (
            <span className="absolute right-2 bottom-2 h-[22px] px-2 rounded-md bg-surface text-ink text-[0.6875rem] font-semibold flex items-center">New</span>
          )}
        </span>
        <span className="flex flex-col flex-1 min-w-0 p-2 min-[341px]:p-2.5">
          <span className="block font-semibold text-[0.9375rem] leading-snug truncate">{r.name}</span>
          <span className="block text-[0.75rem] text-ink-3 truncate">
            {r.symbol} · {age(r.since)}
          </span>
          <span className="flex items-baseline justify-between gap-1.5 mt-1.5 font-mono">
            <span className={"font-bold text-[1rem] tracking-tight truncate rounded px-0.5 -mx-0.5 " + mcFlash}>{compactUsd(r.mc)}</span>
            <span className="text-[0.8125rem] font-semibold shrink-0">
              <Change v={r.change} />
            </span>
          </span>
          {onCurve && (
            <span className="block h-1 rounded-full bg-line overflow-hidden mt-2" aria-hidden="true">
              <span className="block h-full rounded-full bg-emerald" style={{ width: `${Math.max(4, pct)}%` }} />
            </span>
          )}
          <span className="flex justify-between gap-2 text-[0.6875rem] text-ink-3 mt-1.5 font-mono">
            {onCurve ? (
              <>
                <span className="truncate">{pct}% bonded</span>
                <span className="shrink-0">{r.holders === null ? "" : `${r.holders.toLocaleString("en-US")} holders`}</span>
              </>
            ) : (
              <>
                <span className="truncate">Vol {compactUsd(r.vol)}</span>
                <span className="shrink-0 truncate">{r.where ?? (r.holders === null ? "" : `${r.holders.toLocaleString("en-US")} holders`)}</span>
              </>
            )}
          </span>
        </span>
      </Link>
    </li>
  );
}

/** "Launched on sasa": the newest coins launched here (every chain, Solana too), on every tab. */
function SasaLaunches({ solToo }: { solToo: boolean }) {
  const [rows, setRows] = useState<Row[] | null>(null);
  useEffect(() => {
    let alive = true;
    const load = async () => {
      const [races, sol] = await Promise.all([
        fetchRaceCoins(12).catch(() => [] as RaceCoin[]),
        solToo ? fetchSasaSolCoins(12).catch(() => [] as ExtCoin[]) : Promise.resolve([] as ExtCoin[]),
      ]);
      const supplies = await Promise.all(races.map((r) => coinSupply(r).catch(() => RACE_SUPPLY)));
      const all = [
        ...races.map((r, i) => raceRow(r, supplies[i])),
        ...sol.map((c) => ({ ...toRow({ kind: "ext", coin: c } as Ranked, null), where: "Solana" })),
      ].sort((a, b) => (Date.parse(b.since ?? "") || 0) - (Date.parse(a.since ?? "") || 0));
      if (alive) setRows(all.slice(0, 16));
    };
    void load();
    const t = setInterval(() => document.visibilityState === "visible" && void load(), 30_000);
    return () => {
      alive = false;
      clearInterval(t);
    };
  }, [solToo]);
  if (!rows?.length) return null;
  return (
    <section aria-label="Launched on sasa" className="pt-4">
      <div className="px-4 sm:px-6 flex items-baseline justify-between gap-2">
        <h2 className="font-display font-bold text-[1.0625rem]">🚀 Launched on sasa</h2>
        <Link href="/race/launch/" className="text-[0.8125rem] font-semibold text-emerald">Launch yours →</Link>
      </div>
      <div className="mt-2.5 flex gap-2.5 overflow-x-auto no-scrollbar px-4 sm:px-6 snap-x">
        {rows.map((r) => (
          <Link
            key={r.key}
            href={r.href}
            onClick={() => remember(r)}
            className="snap-start shrink-0 w-[8.5rem] rounded-2xl border border-line bg-surface p-2.5 active:scale-[0.98] transition-transform"
          >
            <span className="relative block w-11 h-11 rounded-full overflow-hidden bg-night">
              <CardArt r={r} />
            </span>
            <b className="block mt-2 font-semibold text-[0.875rem] truncate">{r.name}</b>
            <span className="block text-[0.6875rem] text-ink-3 truncate">
              {r.where ? `${r.where} · ` : ""}
              {age(r.since)}
            </span>
            <span className="block mt-1 font-mono font-bold text-[0.875rem] tabular-nums">{compactUsd(r.mc)}</span>
          </Link>
        ))}
      </div>
    </section>
  );
}

/** What the coin page can show at once, before its own data arrives (lib/coincache.ts). */
function remember(r: Row) {
  rememberCoin(r.href, { name: r.name, symbol: r.symbol, image: r.image, mc: r.mc, change: r.change, where: r.where });
}

/** Phones: balance and Deposit at the top of the home screen. */
function BalanceBar() {
  const { portfolio: p } = useMoney();
  const total = p?.totalUsd ?? null;
  const day = p?.dayUsd ?? 0;
  const [whole, cents] = total === null ? ["$—", ""] : (() => {
    const t = total.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    const i = t.lastIndexOf(".");
    return ["$" + t.slice(0, i), t.slice(i)];
  })();
  return (
    <div className="sm:hidden px-4 pt-4 flex items-center justify-between gap-3">
      <button type="button" onClick={() => openMoney({ kind: "portfolio" })} className="min-w-0 text-left">
        <span className="block font-display font-extrabold text-[2rem] leading-none tracking-tight tabular-nums">
          {whole}
          <span className="text-ink-3">{cents}</span>
        </span>
        <span className={"block mt-1 text-[0.8125rem] font-semibold tabular-nums " + (day > 0.005 ? "text-up" : day < -0.005 ? "text-danger" : "text-ink-3")}>
          {total === null ? "\u00a0" : `${day >= 0 ? "+" : "-"}$${Math.abs(day).toFixed(2)}`} <span className="text-ink-3 font-medium">24h</span>
        </span>
      </button>
      <button
        type="button"
        onClick={() => openMoney({ kind: "deposit" })}
        className="shrink-0 h-12 px-7 rounded-2xl bg-emerald text-on-accent font-bold text-[1rem] active:scale-[0.97] transition-transform"
      >
        Deposit
      </button>
    </div>
  );
}

/** Phones: a coin as one row, big picture, name and market cap, change on the right. */
function CoinRow({ r }: { r: Row }) {
  const lastMc = useRef<number | null>(r.mc);
  const [mcFlash, setMcFlash] = useState("");
  useEffect(() => {
    const was = lastMc.current;
    lastMc.current = r.mc;
    if (was === null || r.mc === null || was === r.mc) return;
    setMcFlash(r.mc > was ? "flash-up" : "flash-down");
    const t = setTimeout(() => setMcFlash(""), 900);
    return () => clearTimeout(t);
  }, [r.mc]);
  return (
    <li>
      <Link href={r.href} onClick={() => remember(r)} className="flex items-center gap-3 py-2.5 active:opacity-70">
        <span className="relative shrink-0 w-12 h-12 rounded-full overflow-hidden bg-night">
          <CardArt r={r} />
        </span>
        <span className="min-w-0 flex-1">
          <span className="flex items-center gap-1.5 min-w-0">
            <b className="font-semibold text-[1rem] truncate">{r.name}</b>
            {isNew(r.since) && <span className="shrink-0 px-1.5 rounded bg-emerald-soft text-emerald text-[0.625rem] font-bold">NEW</span>}
          </span>
          <span className="block text-[0.8125rem] text-ink-3 truncate">
            {r.symbol}
            {r.where ? ` · ${r.where}` : ""} · {age(r.since)}
          </span>
        </span>
        <span className="shrink-0 text-right font-mono">
          <span className={"block font-bold text-[1rem] tabular-nums rounded px-0.5 -mx-0.5 " + mcFlash}>{compactUsd(r.mc)}</span>
          <span className="block text-[0.8125rem] font-semibold tabular-nums">
            <Change v={r.change} />
          </span>
        </span>
      </Link>
    </li>
  );
}

function RowSkeleton() {
  return (
    <li className="flex items-center gap-3 py-2.5" aria-hidden="true">
      <span className="shimmer shrink-0 w-12 h-12 rounded-full" />
      <span className="flex-1 grid gap-1.5">
        <span className="shimmer h-4 w-1/2 rounded" />
        <span className="shimmer h-3 w-1/3 rounded" />
      </span>
      <span className="grid gap-1.5 justify-items-end">
        <span className="shimmer h-4 w-14 rounded" />
        <span className="shimmer h-3 w-10 rounded" />
      </span>
    </li>
  );
}

function CardSkeleton() {
  return (
    <li className="rounded-[14px] border border-line overflow-hidden" aria-hidden="true">
      <span className="shimmer block aspect-square" />
      <span className="grid gap-1.5 p-2.5">
        <span className="shimmer h-4 w-3/4 rounded" />
        <span className="shimmer h-3 w-1/2 rounded" />
        <span className="shimmer h-4 w-2/3 rounded mt-1" />
        <span className="shimmer h-1 w-full rounded mt-1" />
      </span>
    </li>
  );
}

/** Coins close to graduating (70%+), as a plain row. Plain data, no paid placement. */
function AlmostThere({ coins }: { coins: Coin[] }) {
  const near = coins
    .filter((c) => !c.graduatedOn && !c.graduating && c.progress >= 0.7 && c.progress < 1)
    .sort((a, b) => b.progress - a.progress)
    .slice(0, 10);
  if (!near.length) return null;
  return (
    <section aria-label="Almost graduating" className="mt-4">
      <div className="flex items-baseline justify-between gap-2 mb-2">
        <h2 className="font-semibold text-[0.9375rem]">Almost graduating</h2>
        <span className="text-[0.75rem] text-ink-3">70% or more</span>
      </div>
      <div className="ex-tabs flex gap-2 overflow-x-auto pb-1 -mx-4 px-4 sm:mx-0 sm:px-0">
        {near.map((c) => {
          const pct = Math.min(99, Math.floor(c.progress * 100));
          const left = c.totalUsd !== null ? Math.max(0, TARGET_USD - c.totalUsd) : null;
          return (
            <Link key={c.id} href={coinHref(c)} className="shrink-0 w-[12.5rem] rounded-xl border border-line p-2.5 hover:border-ink-3">
              <span className="flex items-center gap-2.5">
                <CoinAvatar logo={c.logo} symbol={c.symbol} size={36} />
                <span className="min-w-0">
                  <b className="block truncate font-semibold text-[0.9375rem]">{c.name}</b>
                  <span className="block text-[0.75rem] text-ink-3">
                    <span className="font-mono text-ink font-semibold">{pct}%</span>
                    {left !== null && ` · ${usd(left, left < 100 ? 2 : 0)} to go`}
                  </span>
                </span>
              </span>
              <span className="block h-1 rounded-full bg-line mt-2.5 overflow-hidden" aria-hidden="true">
                <span className="block h-full bg-emerald" style={{ width: `${pct}%` }} />
              </span>
            </Link>
          );
        })}
      </div>
    </section>
  );
}

const SOL_ADDR = /^[1-9A-HJ-NP-Za-km-z]{32,44}$/;
const EVM_ADDR = /^0x[0-9a-fA-F]{40}$/;

/**
 * A contract address pasted in Search: any coin on that chain opens on sasa (its page reads the
 * numbers from DexScreener when it isn't in our lists yet), not just the ones listed here.
 */
function AddressJump({ query }: { query: string }) {
  const a = query.trim();
  const sol = SOL_ADDR.test(a);
  const evm = EVM_ADDR.test(a);
  if (!sol && !evm) return null;
  return (
    <div className="px-4 sm:px-6 mt-3">
      <div className="rounded-2xl border-2 border-emerald bg-emerald-soft p-3 sm:p-4">
        <div className="text-[0.875rem] font-semibold">Contract address</div>
        <div className="font-mono text-[0.75rem] text-ink-3 truncate">{a}</div>
        <div className="mt-2.5 flex flex-wrap gap-2">
          {sol ? (
            <Link href={extHref({ network: SOL_EXT_NETWORK.id, address: a })} className="h-10 px-4 rounded-xl bg-emerald text-on-accent font-bold text-[0.875rem] inline-flex items-center">
              Open this Solana coin →
            </Link>
          ) : (
            [
              <Link key="scan" href={`/scan/?a=${a}`} className="h-10 px-3.5 rounded-xl bg-emerald text-on-accent font-bold text-[0.8125rem] inline-flex items-center">
                🛡️ Is it safe?
              </Link>,
              ...EXT_NETWORKS.map((n) => (
              <Link key={n.id} href={extHref({ network: n.id, address: a.toLowerCase() })} className="h-10 px-3.5 rounded-xl border border-line bg-paper font-semibold text-[0.8125rem] inline-flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full" style={{ background: n.color }} aria-hidden="true" />
                Open on {n.label}
              </Link>
              )),
            ]
          )}
        </div>
      </div>
    </div>
  );
}
