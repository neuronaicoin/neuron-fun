// The X bot's words (xbot.mjs). Each kind of post has many ways of saying it; the bot picks one
// it hasn't used for that kind in the last 7 days, so the account never reads like a template.
// Style: lowercase and loose like a person typing, attention words in CAPS, the coin as a
// $CASHTAG (X turns it into a price chip), a question or a hook, then 4 hashtags.

const num = (v) => (Number.isFinite(Number(v)) ? Number(v) : 0);
export function money(v) {
  const a = Math.abs(num(v));
  if (a >= 1e9) return `$${(a / 1e9).toFixed(2)}B`;
  if (a >= 1e6) return `$${(a / 1e6).toFixed(a >= 1e7 ? 1 : 2)}M`;
  if (a >= 1e3) return `$${Math.round(a / 1e3)}K`;
  return `$${Math.round(a)}`;
}
const px = (p) => (p >= 1000 ? `$${Math.round(p).toLocaleString("en-US")}` : p >= 1 ? `$${p.toFixed(2)}` : `$${Number(Number(p).toPrecision(4))}`);
const pct = (v) => `${v >= 0 ? "+" : "-"}${Math.abs(v) >= 100 ? Math.round(Math.abs(v)) : Math.abs(v).toFixed(1)}%`;
const shuffle = (a) => a.map((x) => [Math.random(), x]).sort((p, q) => p[0] - q[0]).map((x) => x[1]);

const NAMES = {
  BTC: "Bitcoin", ETH: "Ethereum", SOL: "Solana", XRP: "XRP", DOGE: "Dogecoin", HYPE: "Hyperliquid", BNB: "BNB",
  TSLA: "Tesla", NVDA: "Nvidia", AAPL: "Apple", MSFT: "Microsoft", AMZN: "Amazon", GOOGL: "Google", META: "Meta", NFLX: "Netflix",
  AMD: "AMD", HOOD: "Robinhood", COIN: "Coinbase", MSTR: "MicroStrategy", PLTR: "Palantir", GOLD: "Gold", SILVER: "Silver",
  CL: "Oil", OIL: "Oil", BRENTOIL: "Oil", NATGAS: "NaturalGas", XYZ100: "Nasdaq", SPX: "SP500",
};
const STOCKS = new Set(["TSLA", "NVDA", "AAPL", "MSFT", "AMZN", "GOOGL", "META", "NFLX", "AMD", "INTC", "HOOD", "COIN", "MSTR", "PLTR", "ORCL", "TSM"]);
export const ticker = (coin) => String(coin).slice(String(coin).indexOf(":") + 1).toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 12) || "COIN";
const cash = (t) => (/^[A-Z][A-Z0-9]{0,9}$/.test(t) ? `$${t}` : t); // X cashtags: letters first, short

/** 4 hashtags: the name, then a rotating set that fits the topic. */
function tags(t, pool) {
  const name = NAMES[t] && NAMES[t].toUpperCase() !== t ? `#${NAMES[t].replace(/[^A-Za-z0-9]/g, "")}` : null;
  return [...new Set([name, ...shuffle(pool)].filter(Boolean))].slice(0, 4).join(" ");
}
const CRYPTO = ["#Crypto", "#CryptoNews", "#Altcoins", "#CryptoTrading", "#Bitcoin"];
const WHALE = ["#WhaleAlert", "#Whales", "#SmartMoney", "#Crypto", "#CryptoTrading"];

// every builder returns a list of [id, text]; ids are what "not used lately" remembers
export function whale(m, w) {
  const t = ticker(m.coin);
  const C = cash(t);
  const size = money(m.usd);
  const S = m.side === "long" ? "LONG" : "SHORT";
  const dir = m.side === "long" ? "UP" : "DOWN";
  const lev = m.lev ? `${Math.round(m.lev)}x` : null;
  const month = w.pnl_month > 0 ? money(w.pnl_month) : null;
  const rank = w.rank ? `#${w.rank}` : null;
  let v;
  if (m.kind === "open" || m.kind === "add") {
    v = [
      ["o1", `a WHALE just put ${size} on ${C} going ${dir}${lev ? ` at ${lev}` : ""} 👀${month ? `\n\nsame wallet is +${month} this month` : ""}`],
      ["o2", `${size} ${S} on ${C}. just now.${month ? `\n\nthis guy made ${month} in 30 days. you fading him?` : "\n\nyou fading this?"}`],
      ["o3", `${rank ? `the ${rank} trader on the board` : "one of the top WHALES"} just went ${S} ${C}${lev ? ` with ${lev}` : ""}\n\nhe knows something we don't?`],
      ["o4", `someone just bet ${size} that ${C} goes ${dir} from ${px(m.px)} 😳\n\nfollow or fade?`],
      ["o5", `WHALE ALERT 🐋\n\n${size} ${S} ${C}${lev ? ` · ${lev}` : ""} · entry ${px(m.px)}${month ? `\n\n+${month} this month. not a random wallet` : ""}`],
      ["o6", `${C} ${S}. ${size}. from a wallet that ${month ? `printed ${month} this month` : "rarely misses"}\n\nbookmark this one, we'll see who was right 👀`],
      ["o7", `while you were scrolling, a WHALE opened ${size} ${S} on ${C} 👀\n\nwhat's he seeing?`],
    ];
    if (m.kind === "add") v = v.map(([id, x]) => [id.replace("o", "a"), x.replace(/just (put|went|opened|bet)/, "just ADDED")]);
  } else if (m.kind === "flip") {
    v = [
      ["f1", `a WHALE just FLIPPED ${C} to ${S}. ${size} on it now 👀\n\nsomething changed his mind`],
      ["f2", `was long, now ${S}. ${size} on ${C}. ${rank ? `the ${rank} trader` : "this whale"} just switched sides 😳`],
      ["f3", `${C} FLIP 🔄 ${size} ${S}${lev ? ` at ${lev}` : ""}\n\nwhen the smart money turns around, you look`],
      ["f4", `plot twist. top WHALE just FLIPPED his ${C} position to ${S}. ${size}\n\nwhat did he see?`],
    ];
  } else {
    v = [
      ["c1", `WHALE just closed his ${size} ${C} ${S} at ${px(m.px)} 👀\n\nhe knows something?`],
      ["c2", `${rank ? `the ${rank} trader` : "a top WHALE"} just took ${size} of ${C} off the table. out.\n\ntop signal or just profit?`],
      ["c3", `${size} ${C} ${S}, gone. closed at ${px(m.px)}\n\nwhen this wallet leaves, people usually wish they'd followed`],
      ["c4", `a WHALE just walked away from ${C}. ${size} ${S} closed 👀`],
    ];
  }
  return v.map(([id, x]) => [id, `${x}\n\n${tags(t, WHALE)}`]);
}

export function fear(score, prev) {
  const lab = score <= 24 ? "EXTREME FEAR" : score <= 44 ? "FEAR" : score <= 55 ? "NEUTRAL" : score <= 74 ? "GREED" : "EXTREME GREED";
  const move = prev !== null && prev !== undefined && prev !== score ? `${prev > score ? "down" : "up"} from ${prev} yesterday` : null;
  const tg = tags("BTC", ["#FearAndGreed", "#Crypto", "#Bitcoin", "#BTC", "#CryptoMarket"]);
  const v =
    score <= 44
      ? [
          ["d1", `crypto fear & greed: ${score}. ${lab} 😬${move ? `\n\n${move}` : ""}\n\nbe greedy when others are fearful… right?`],
          ["d2", `${score}/100. ${lab}.\n\nthis is usually where WHALES start buying quietly 👀`],
          ["d3", `everyone's scared again. index at ${score}${move ? `, ${move}` : ""}\n\nare you buying this or running?`],
          ["d4", `${lab} at ${score}. last time it was this low people said "never again"… then regretted not buying`],
        ]
      : score >= 56
        ? [
            ["g1", `fear & greed just hit ${score}. ${lab} 🤑${move ? `\n\n${move}` : ""}\n\nlast time it was this high people got liquidated`],
            ["g2", `${score}/100. everyone's feeling smart again 👀\n\nwho's taking profit?`],
            ["g3", `${lab} at ${score}. this is where the WHALES start selling to you`],
          ]
        : [
            ["n1", `fear & greed sitting at ${score}${move ? ` (${move})` : ""}. nobody knows what's next, and that's exactly when the big moves come 👀`],
            ["n2", `${score}/100. dead neutral. the calm before something?`],
          ];
  return v.map(([id, x]) => [id, `${x}\n\n${tg}`]);
}

export function biggest(p) {
  const t = ticker(p.coin);
  const C = cash(t);
  const S = p.side === "long" ? "LONG" : "SHORT";
  const v = [
    ["b1", `the biggest bet a top WHALE has on right now: ${money(p.v)} ${S} on ${C} 👀\n\nif this goes wrong…`],
    ["b2", `${money(p.v)}. one position. ${C} ${S}${p.l ? ` at ${Math.round(p.l)}x` : ""}\n\nthis is what conviction looks like`],
    ["b3", `someone is sitting on a ${money(p.v)} ${C} ${S} right now and not blinking 😳`],
    ["b4", `largest open position on the board: ${C} ${S}, ${money(p.v)}\n\nwould you take the other side?`],
    ["b5", `${money(p.v)} on ${C} going ${p.side === "long" ? "UP" : "DOWN"}. one wallet. still open.\n\nwho blinks first, him or the market?`],
  ];
  return v.map(([id, x]) => [id, `${x}\n\n${tags(t, WHALE)}`]);
}

export function predict(title, yes, underlying) {
  const t = ticker(underlying || "BTC");
  const C = cash(t);
  const q = title.replace(new RegExp(`^${t}\\b`), C);
  const p = Math.round(yes * 100);
  const v = [
    ["p1", `${q} market says ${p}% YES.\n\nyou think they're wrong? 👀`],
    ["p2", `${q}\n\nYES or NO. no in between`],
    ["p3", `${p}% of people think YES. ${q}\n\nright call pays $1 a share`],
    ["p4", `quick one 👇 ${q}\n\ncrowd's at ${p}/${100 - p}. which side are you?`],
    ["p5", `${q} i'd fade the crowd on this one. you?`],
  ];
  return v.map(([id, x]) => [id, `${x}\n\n${tags(t, ["#Predictions", "#PredictionMarket", "#Crypto", "#Trading"])}`]);
}

export function stock(m, closed) {
  const t = ticker(m.label);
  const C = cash(t);
  const ch = pct(m.change);
  const name = NAMES[t] || m.name || t;
  const up = m.change >= 0;
  const v = closed
    ? [
        ["s1", `markets are closed. ${C} isn't 👀 ${ch}\n\nmonday open is gonna be interesting`],
        ["s2", `wall street is asleep and ${name} is ${ch} 👀\n\nyou can still go LONG or SHORT ${C} right now`],
        ["s3", `${C} ${ch} while the stock market's closed. this is the move nobody's watching`],
        ["s4", `weekend ${C} trading is wild. ${ch} already 😳`],
      ]
    : [
        ["s5", `${name} ${ch} today and it's not stopping when the bell rings 👀\n\n${C} trades 24/7`],
        ["s6", `${C} ${ch}. biggest mover of the day\n\n${up ? "chasing or waiting for a dip?" : "buying this dip or no?"}`],
        ["s7", `${C} is ${up ? "RIPPING" : "DUMPING"} ${ch} 📈\n\nlong or short it 24/7, even after hours`],
        ["s8", `${ch} on ${C} today. ${up ? "who's still holding?" : "who's buying?"} 👇`],
      ];
  const pool = STOCKS.has(t) ? ["#Stocks", "#StockMarket", "#Trading", "#WallStreet"] : ["#Commodities", "#Trading", "#Markets", "#Futures"];
  return v.map(([id, x]) => [id, `${x}\n\n${tags(t, pool)}`]);
}

export function spot(c) {
  const t = ticker(c.symbol);
  const C = cash(t);
  const ch = pct(c.change_24h);
  const v = [
    ["g1", `${C} ${ch} today. biggest gainer in the top 500 right now 👀\n\nstill early or already late?`],
    ["g2", `nothing in the top 500 is pumping like ${C} today. ${ch} 🚀\n\nyou holding any?`],
    ["g3", `${c.name} just did ${ch} in a day. #${c.rank} by market cap and moving like a meme 👀`],
    ["g4", `${C} ${ch} 📈 while most of the market is flat\n\nwhat's the catalyst?`],
    ["g5", `top gainer today: ${C} ${ch}\n\nbuy the breakout or wait for the dip? 👇`],
  ];
  return v.map(([id, x]) => [id, `${x}\n\n${tags(t, ["#Altcoins", "#Crypto", "#TopGainers", "#CryptoNews", "#Altseason"])}`]);
}

export function meme(c, net) {
  const t = ticker(c.symbol);
  const C = cash(t);
  const ch = pct(c.change_24h);
  const chain = net === "BNB" ? "#BNBChain" : net === "BASE" ? "#Base" : `#${net.charAt(0)}${net.slice(1).toLowerCase()}`;
  const v = [
    ["m1", `this meme is ${ch} today on ${net} 👀\n\n${C}. ${money(c.vol)} volume in 24h. people are paying attention`],
    ["m2", `${C} ${ch} in 24 hours. ${money(c.mcap)} market cap now\n\nwho caught this one early? 🙋`],
    ["m3", `${ch} today. ${C} on ${net} is the hottest meme out there right now 🔥`],
    ["m4", `${C} went ${ch} while you were asleep 😭\n\nstill early at ${money(c.mcap)}?`],
    ["m5", `memes are back?? ${C} ${ch} today on ${net} 👀`],
  ];
  return v.map(([id, x]) => [id, `${x}\n\n${[...new Set([`#${t}`, "#MemeCoin", chain, "#Memecoins", "#Crypto"])].slice(0, 4).join(" ")}`]);
}

export function poll() {
  const v = [
    ["q1", `$BTC by tonight. UP or DOWN? 👇\n\nno "crab" option, pick a side`],
    ["q2", `where's $BTC by the end of the day? vote and come back to flex 👇`],
    ["q3", `quick one. $BTC tonight 👇`],
    ["q4", `be honest. $BTC tonight? 👇`],
    ["q5", `WHALES are positioned. are you? $BTC by tonight 👇`],
  ];
  return v.map(([id, x]) => [id, `${x}\n\n${tags("BTC", ["#Bitcoin", "#Crypto", "#Poll", "#BTC"])}`]);
}

export function recap(top) {
  const a = top[0];
  const sum = top.reduce((x, w) => x + w.pnl_day, 0);
  const v = [
    ["r1", `today's best WHALE is up ${money(a.pnl_day)} 👀\n\n#2 and #3 aren't far behind. guess what they're holding`],
    ["r2", `${money(a.pnl_day)} made today by one wallet. TODAY.\n\nhere's who's printing right now`],
    ["r3", `the top 3 WHALES made ${money(sum)} between them today. you're watching the wrong charts`],
    ["r4", `while CT argued about the top, these 3 wallets made ${money(sum)} today 😭`],
    ["r5", `daily WHALE leaderboard 🏆\n\n#1 +${money(a.pnl_day)}\n\nwant to see what they're holding?`],
  ];
  return v.map(([id, x]) => [id, `${x}\n\n${tags("", WHALE.concat(["#Leaderboard"]))}`]);
}

export function followup(f) {
  const t = f.hours < 1 ? `${Math.max(1, Math.round(f.hours * 60))} minutes` : `${Math.round(f.hours)}h`;
  if (f.pnl >= 0)
    return [
      ["u1", `remember this one? he just closed it. +${money(f.pnl)} in ${t} 👀\n\nfollow so you catch the next one`],
      ["u2", `and it's done. +${money(f.pnl)} in ${t}. told you this wallet doesn't miss much 🐋`],
      ["u3", `called it 👆 WHALE closed for +${money(f.pnl)} in ${t}`],
      ["u4", `update: he's out. +${money(f.pnl)}. ${t}. that's the trade`],
    ];
  return [
    ["l1", `closed. -${money(-f.pnl)} this time. even WHALES get it wrong sometimes`],
    ["l2", `he's out. took a -${money(-f.pnl)} hit on this one. next move is the one to watch 👀`],
    ["l3", `update: this one didn't work. -${money(-f.pnl)}. the market humbles everyone`],
  ];
}

/**
 * sasa on Elysium: the account's main beat. Curiosity / FOMO hooks aimed at people who follow and
 * trade on Elysium, to pull them to sasa. Never flat descriptions. No fixed dates, no made-up
 * numbers (the bot posts on its own). Attention words in CAPS, loose and human. EVERY post tags the
 * Elysium accounts, carries the sasapad.fun link, and uses a DIFFERENT, heavy hashtag set.
 */
const LINK = "sasapad.fun";
export function elysium() {
  return [
    ["e1", `a new chain just opened and most people haven't noticed yet 👀\n\n@Enter_Elysium is live and the first coins here are the ones that get seen. launch yours on sasa\n\n👉 ${LINK}\n\n#Elysium #Memecoins #NewChain #Crypto #DeFi #sasa`],
    ["e2", `every chain had ONE window where launching early meant everything\n\n@Enter_Elysium is in that window right now. get in on sasa before the crowd shows up\n\n👉 ${LINK}\n\n#Elysium #CryptoTrading #Altcoins #GEM #Web3 #Pump`],
    ["e3", `you keep saying you missed the early days of every chain\n\n@Enter_Elysium is day one. one tap on sasa and your coin is live 🚀\n\n👉 ${LINK}\n\n#Elysium #Memecoin #100x #LaunchPad #Crypto #Degens`],
    ["e4", `the WHALES are already sniffing around @HyperliquidX's new chain 👀\n\nbe where the smart money's looking. trade or launch on sasa\n\n👉 ${LINK}\n\n#Elysium #Whales #HYPE #SmartMoney #Altcoins #Crypto`],
    ["e5", `no bridge. no 12 steps. just launch on ELYSIUM with one tap on sasa\n\nwhat are you waiting for? @Enter_Elysium\n\n👉 ${LINK}\n\n#Elysium #Memecoins #CryptoNews #DeFi #NewChain #Web3`],
    ["e6", `new chains make new names. whoever shows up first on @Enter_Elysium is who everyone copies later\n\nstart on sasa\n\n👉 ${LINK}\n\n#Elysium #Altcoins #CryptoGems #Memecoin #OnChain #Degens`],
    ["e7", `quiet chains don't stay quiet 👀\n\n@Enter_Elysium is early and sasa is already live on it. launch, trade, be FIRST\n\n👉 ${LINK}\n\n#Elysium #CryptoTrading #HYPE #Altseason #Memecoins #Crypto`],
    ["e8", `the best time to launch on a new chain is BEFORE anyone's watching\n\nthat's @Enter_Elysium right now. sasa makes it one tap\n\n👉 ${LINK}\n\n#Elysium #Memecoins #OnChain #LaunchPad #Web3 #GEM`],
    ["e9", `everyone's about to ask what ELYSIUM is\n\nyou could already have a coin live there. sasa, one tap 🚀 @Enter_Elysium\n\n👉 ${LINK}\n\n#Elysium #Memecoin #CryptoNews #100x #Altcoins #Pump`],
    ["e10", `coins are being created on @Enter_Elysium right now while you read this 👀\n\njoin them on sasa or watch someone else's pump\n\n👉 ${LINK}\n\n#Elysium #Whales #Altcoins #GEM #Memecoins #Crypto`],
    ["e11", `launching on ELYSIUM takes less time than reading this post\n\none tap on sasa. no wallet gymnastics @Enter_Elysium\n\n👉 ${LINK}\n\n#Elysium #Memecoins #CryptoTrading #DeFi #Degens #Web3`],
    ["e12", `the earliest coins on any chain write the story for the rest\n\nwrite yours on @Enter_Elysium with sasa\n\n👉 ${LINK}\n\n#Elysium #Crypto #Memecoin #NewChain #100x #CryptoGems`],
    ["e13", `@fomo made @Enter_Elysium their home. the smart money's already moving in 👀\n\nget your coin in early on sasa\n\n👉 ${LINK}\n\n#Elysium #Altcoins #SmartMoney #Memecoins #HYPE #sasa`],
    ["e14", `trade it, launch it, be first on it\n\n@HyperliquidX's ELYSIUM is live on sasa and the crowd isn't here yet 🚀\n\n👉 ${LINK}\n\n#Elysium #Memecoins #HYPE #Hyperliquid #Altseason #Crypto`],
    ["e15", `you don't catch the next chain by waiting for the headlines\n\n@Enter_Elysium is already open on sasa. MOVE 👀\n\n👉 ${LINK}\n\n#Elysium #CryptoTrading #Memecoin #100x #Degens #Altcoins`],
    ["e16", `one tap. your coin. a brand new chain called ELYSIUM\n\nthe rest of the timeline finds out later. sasa @Enter_Elysium\n\n👉 ${LINK}\n\n#Elysium #Memecoins #LaunchPad #GEM #Web3 #Crypto`],
    ["e17", `WHALES love a fresh chain with room to move 🐋\n\n@Enter_Elysium has it. so does sasa. launch before it fills up\n\n👉 ${LINK}\n\n#Elysium #Whales #Altcoins #SmartMoney #Memecoin #HYPE`],
    ["e18", `being early isn't luck, it's showing up before the crowd\n\nshow up on @Enter_Elysium with sasa\n\n👉 ${LINK}\n\n#Elysium #Memecoin #CryptoNews #Web3 #NewChain #Degens`],
    ["e19", `@AscendLaunch gets the spotlight on @Enter_Elysium, but sasa is where YOU launch your own coin in one tap 👀\n\n👉 ${LINK}\n\n#Elysium #Memecoins #LaunchPad #Altcoins #Crypto #sasa`],
    ["e20", `the chart you'll screenshot in a month starts as a launch TODAY\n\ndo it on @Enter_Elysium with sasa 🚀\n\n👉 ${LINK}\n\n#Elysium #Altcoins #100x #CryptoGems #Pump #Memecoins`],
    ["e21", `HYPE built a whole new chain and barely anyone's launched on it yet 👀\n\n@Enter_Elysium. sasa. your move\n\n👉 ${LINK}\n\n#Elysium #HYPE #Hyperliquid #Memecoin #NewChain #DeFi`],
    ["e22", `first mover on a new chain beats best builder on a crowded one, every time\n\nbe first on @Enter_Elysium with sasa\n\n👉 ${LINK}\n\n#Elysium #CryptoTrading #NewChain #GEM #Altseason #Web3`],
    ["e23", `your coin. live on @Enter_Elysium. in the time it takes to make coffee ☕\n\none tap on sasa\n\n👉 ${LINK}\n\n#Elysium #Memecoins #Altseason #LaunchPad #100x #Crypto`],
    ["e24", `the crowd always shows up LATE 👀\n\nbeat them to @Enter_Elysium. launch or trade on sasa right now\n\n👉 ${LINK}\n\n#Elysium #Whales #Crypto #SmartMoney #Memecoin #Degens`],
    ["e25", `nobody remembers coin #4000 on a chain. they remember the FIRST ones\n\nbe one of them on @Enter_Elysium with sasa\n\n👉 ${LINK}\n\n#Elysium #Memecoin #100x #CryptoGems #Altcoins #Pump`],
    ["e26", `@Enter_Elysium is the cleanest launch field in crypto right now — empty and early 👀\n\nplant your flag on sasa\n\n👉 ${LINK}\n\n#Elysium #Altcoins #NewChain #DeFi #Memecoins #Web3`],
    ["e27", `everyone wants the next big chain's first 100x. it starts with a LAUNCH\n\n@Enter_Elysium, one tap on sasa 🚀\n\n👉 ${LINK}\n\n#Elysium #Memecoins #100x #HYPE #Pump #CryptoGems`],
    ["e28", `the whales on @HyperliquidX don't wait for permission. neither should you\n\nlaunch on @Enter_Elysium with sasa 👀\n\n👉 ${LINK}\n\n#Elysium #Whales #Hyperliquid #SmartMoney #Altcoins #Memecoin`],
    ["e29", `launch a coin, trade a coin, be early — all on ELYSIUM, all on sasa\n\nthe crowd isn't here yet @Enter_Elysium\n\n👉 ${LINK}\n\n#Elysium #CryptoTrading #Memecoin #Altseason #Degens #Crypto`],
    ["e30", `a brand new chain only happens ONCE 👀\n\n@Enter_Elysium is now. launch on sasa before it's obvious\n\n👉 ${LINK}\n\n#Elysium #Memecoins #CryptoNews #GEM #NewChain #100x`],
  ];
}

// sasa itself: launch, trade, spot, futures, whales, the trap scan, the contest. Text only, no
// made-up numbers (the bot posts on its own). Every line has its own hashtag set; fresh() keeps a
// line from coming back for 7 days, so the timeline doesn't repeat itself.
export function promo() {
  return [
    ["p1", `made a coin in the time it took my coffee to cool down ☕\n\nname, picture, one tap. it's live on several chains at once\n\n👉 ${LINK}\n\n#Memecoin #CryptoTrading #Base #BNB #Web3 #sasa`],
    ["p2", `the WHALES bought something 4 minutes ago. you'll read about it tomorrow\n\nor you can watch it happen live 👀\n\n👉 ${LINK}\n\n#WhaleAlert #SmartMoney #Crypto #OnChain #Altcoins #Degens`],
    ["p3", `long BTC. short ETH. buy the meme. launch your own coin\n\nsame app, same balance, logged in with just an email\n\n👉 ${LINK}\n\n#Bitcoin #Futures #CryptoTrading #Ethereum #Memecoins #DeFi`],
    ["p4", `stop aping into coins you haven't checked\n\npaste any contract on sasa, see if it's a TRAP before you buy. free\n\n👉 ${LINK}\n\n#CryptoSafety #Rugpull #DYOR #Memecoin #Solana #Crypto`],
    ["p5", `honest question: why are you still launching on ONE chain?\n\none launch on sasa = your coin on Base, BNB, Robinhood and Arc together 🚀\n\n👉 ${LINK}\n\n#Base #BNBChain #RobinhoodChain #Arc #Memecoins #LaunchPad`],
    ["p6", `$100,000. one creator. coins launched on sasa\n\nthe contest is still open and most people haven't even tried 👀\n\n👉 ${LINK}\n\n#CryptoContest #Memecoin #Airdrop #Web3 #Altseason #sasa`],
    ["p7", `no seed phrase. no bridge. no "add network" popup\n\nlog in with email, pay in dollars, trade. that's it\n\n👉 ${LINK}\n\n#CryptoTrading #Web3 #DeFi #Onboarding #Altcoins #USDC`],
    ["p8", `your coin makes money while you sleep 😴\n\ncreators on sasa get a cut of every trade on their coin. FOREVER\n\n👉 ${LINK}\n\n#PassiveIncome #Memecoin #CryptoGems #Creators #Web3 #Pump`],
    ["p9", `everyone has a meme coin idea in their notes app\n\nyou're one tap away from it being real. do it tonight 👀\n\n👉 ${LINK}\n\n#Memecoins #Crypto #100x #LaunchPad #GEM #Degens`],
    ["p10", `the market dumped and your bags are red?\n\nsome people went SHORT and are smiling. futures on sasa, from your USDC balance\n\n👉 ${LINK}\n\n#Futures #ShortSelling #Bitcoin #CryptoTrading #Leverage #BTC`],
    ["p11", `thousands of coins. every chain. one search box\n\nfind it, check it's not a trap, buy it. 3 taps\n\n👉 ${LINK}\n\n#Altcoins #CryptoGems #DEX #Solana #Base #CryptoTrading`],
    ["p12", `the wallets that called the last 3 pumps are buying again right now 🐋\n\nsee exactly what they buy on sasa\n\n👉 ${LINK}\n\n#SmartMoney #Whales #CopyTrading #Crypto #Altseason #OnChain`],
    ["p13", `gm. what are we launching today? 🚀\n\ndrop the name below, the best one might actually go live 👀\n\n👉 ${LINK}\n\n#GM #Memecoin #CryptoCommunity #Web3 #LaunchPad #Degens`],
    ["p14", `TSLA. NVDA. GOLD. OIL\n\ngo long or short on stocks and commodities with crypto, 24/7. even when Wall Street sleeps\n\n👉 ${LINK}\n\n#Stocks #Gold #Oil #Tesla #NVDA #Trading`],
    ["p15", `your friend made 10x on a coin he found on a random tuesday\n\nhe probably saw the WHALES buy it first 👀\n\n👉 ${LINK}\n\n#WhaleWatching #Crypto #100x #Memecoins #SmartMoney #Altcoins`],
    ["p16", `4 chains race. the winner takes ALL the liquidity\n\nthat's how a coin launches on sasa. 5 minutes, then it's on the chain that won 🏁\n\n👉 ${LINK}\n\n#ChainRace #Memecoin #Base #BNB #Crypto #LaunchPad`],
    ["p17", `copy the traders who are actually winning\n\nfollow them on sasa, get pinged when they buy, one tap to buy too\n\n👉 ${LINK}\n\n#CopyTrading #CryptoTrading #SmartMoney #Altcoins #DeFi #Traders`],
    ["p18", `will BTC be higher in an hour? you probably have an opinion\n\nput it to work: predictions on sasa, YES or NO, from $1\n\n👉 ${LINK}\n\n#Bitcoin #Predictions #BTC #CryptoTrading #PredictionMarkets #Crypto`],
    ["p19", `launching a coin used to need a dev, a wallet and a whole weekend\n\nnow it needs an email and 30 seconds. welcome to sasa\n\n👉 ${LINK}\n\n#Memecoins #NoCode #Web3 #Crypto #Builders #LaunchPad`],
    ["p20", `rug pulls are getting smarter. so is our scanner 🛡️\n\nhoneypot, hidden tax, dev holding half? sasa tells you BEFORE you buy\n\n👉 ${LINK}\n\n#Honeypot #RugPull #CryptoSafety #DYOR #Memecoin #BSC`],
    ["p21", `the best traders keep everything in one place. memes, spot, futures\n\none dollar balance, all of it, on sasa\n\n👉 ${LINK}\n\n#CryptoTrading #Spot #Futures #Portfolio #USDC #Altcoins`],
    ["p22", `most coins die in a day. some go 100x in a week\n\nthe difference is usually who bought EARLY. watch them live 🐋\n\n👉 ${LINK}\n\n#EarlyBird #Memecoins #Whales #CryptoGems #100x #OnChain`],
    ["p23", `ok but imagine your coin trending while you're at work 👀\n\nlaunch it now, share the link, let it run\n\n👉 ${LINK}\n\n#Trending #Memecoin #Crypto #Pump #Viral #Web3`],
    ["p24", `you don't need to hold SOL, ETH and BNB to trade on all of them\n\njust dollars. sasa handles the rest behind the scenes\n\n👉 ${LINK}\n\n#MultiChain #Solana #Ethereum #BNB #CryptoTrading #USDC`],
    ["p25", `which chain wins the next race: Base, BNB, Robinhood or Arc? 🏁\n\nreply with your pick. then go watch one live\n\n👉 ${LINK}\n\n#Base #BNBChain #RobinhoodChain #Arc #CryptoPoll #Memecoins`],
    ["p26", `bought the top again? same 😅\n\nnext time check what the smart wallets are doing first. it's free on sasa\n\n👉 ${LINK}\n\n#CryptoMemes #SmartMoney #Altcoins #CryptoTrading #Whales #Degens`],
    ["p27", `SOL is moving and you're on the sidelines?\n\nlong it, short it, or buy the memes riding it. all from one app\n\n👉 ${LINK}\n\n#Solana #SOL #Futures #Memecoins #CryptoTrading #Altseason`],
    ["p28", `free to launch. free to check. pay only when you trade\n\nthat's the whole deal on sasa 🤝\n\n👉 ${LINK}\n\n#Crypto #Memecoin #LaunchPad #DeFi #Web3 #Transparency`],
    ["p29", `the next coin everyone talks about hasn't been launched yet\n\nwhy not yours? 🚀\n\n👉 ${LINK}\n\n#Memecoins #NextBigThing #Crypto #100x #CryptoGems #Pump`],
    ["p30", `3am and the market's wild? sasa doesn't sleep either\n\nlive WHALE buys, live races, live charts. come see\n\n👉 ${LINK}\n\n#CryptoNeverSleeps #Whales #Altcoins #CryptoTrading #NightTrader #Crypto`],
    ["p31", `you can launch a coin on sasa with a picture and a name\n\nor let the AI make the whole thing from one sentence 🤖\n\n👉 ${LINK}\n\n#AI #Memecoin #AIAgents #Crypto #LaunchPad #Web3`],
    ["p32", `still trading memes on 4 different sites with 4 different wallets?\n\nthere's an easier way 👀\n\n👉 ${LINK}\n\n#CryptoTrading #DEX #Memecoins #Altcoins #Solana #Base`],
  ];
}

export function result(r, underlying) {
  const right = Math.round((r.yesWon ? r.yes : 1 - r.yes) * 100);
  const W = r.yesWon ? "YES" : "NO";
  const C = cash(ticker(underlying));
  return [
    ["x1", `${W} won. ${C} was at ${px(r.closePx)} 👀\n\n${right}% called it. next one's already live`],
    ["x2", `and the answer is… ${W}. ${C} ${px(r.closePx)}\n\n${right < 50 ? "only " : ""}${right}% got it right. you in for the next one?`],
    ["x3", `${W} 🎯 ${C} closed at ${px(r.closePx)}. how did you call it?`],
  ];
}
