"use client";

import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import { TARGET_USD, chainById } from "@/lib/config";
import { coinHref, fetchTrades, isImageUrl, marketCapNative, type Coin, type Trade } from "@/lib/data";
import { shortAddr } from "@/lib/format";
import { ChainChip, timeAgo, usd } from "./coins";
import { Sparkline } from "./spark";
import { LockBadge } from "./lock";

/** Market value in dollars: the biggest of the coin's chains (the one that matters). */
export function coinMarketCapUsd(coin: Coin, ethUsd: number | null): number | null {
  if (!ethUsd) return null;
  const caps = coin.curves.filter((c) => c.state !== "closed").map((c) => marketCapNative(c) * ethUsd);
  return caps.length ? Math.max(...caps) : null;
}

// One formatter for every market cap on the site (see lib/format.ts).
import { compactUsd } from "@/lib/format";
export { compactUsd };

/** Deterministic artwork for coins without a picture. */
function hue(s: string) {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) % 360;
  return h;
}

export function CoinArt({ coin, className = "", small = false }: { coin: Coin; className?: string; small?: boolean }) {
  const [broken, setBroken] = useState(false);
  if (coin.logo && isImageUrl(coin.logo) && !broken) {
    // eslint-disable-next-line @next/next/no-img-element
    return <img src={coin.logo} alt="" className={"w-full h-full object-cover " + className} onError={() => setBroken(true)} />;
  }
  const h = hue(coin.id);
  return (
    <div
      className={"w-full h-full flex items-center justify-center " + className}
      style={{ background: `radial-gradient(120% 90% at 20% 10%, hsl(${h} 70% 42%), hsl(${(h + 60) % 360} 60% 14%) 70%)` }}
    >
      <span className="font-display font-bold text-white/90" style={{ fontSize: small ? "22px" : "clamp(36px, 8vw, 84px)" }}>
        {(coin.symbol || "?").slice(0, 2).toUpperCase()}
      </span>
    </div>
  );
}

/** The progress bar, split by chain: each chain's share of the target in its own colour. */
export function RaceBar({ coin, thick = false }: { coin: Coin; thick?: boolean }) {
  const h = thick ? "h-3" : "h-2";
  if (coin.graduatedOn) {
    return (
      <div className={"w-full rounded-full overflow-hidden " + h} style={{ background: coin.graduatedOn.chain.color }} />
    );
  }
  let left = 100;
  return (
    <div className={"w-full rounded-full bg-line overflow-hidden flex " + h}>
      {coin.curves
        .filter((c) => c.state === "trading" || c.state === "frozen")
        .sort((a, b) => (b.usd ?? 0) - (a.usd ?? 0))
        .map((c) => {
          const w = Math.min(left, ((c.usd ?? 0) / TARGET_USD) * 100);
          left -= w;
          return <div key={c.chain.key} className="h-full" style={{ width: `${w}%`, background: c.chain.color }} />;
        })}
    </div>
  );
}

/** A coin card. Flashes when a new trade lands. */
export function CoinTile({ coin, ethUsd, spark }: { coin: Coin; ethUsd: number | null; spark?: number[] | null }) {
  const last = useRef(coin.lastTradeAt);
  const [flash, setFlash] = useState(false);
  useEffect(() => {
    if (coin.lastTradeAt && last.current && coin.lastTradeAt !== last.current) {
      setFlash(true);
      const t = setTimeout(() => setFlash(false), 2600);
      last.current = coin.lastTradeAt;
      return () => clearTimeout(t);
    }
    last.current = coin.lastTradeAt;
  }, [coin.lastTradeAt]);

  const pct = Math.round(coin.progress * 100);
  return (
    <Link
      href={coinHref(coin)}
      className={"group block rounded-3xl bg-surface border border-line p-2.5 sm:p-3 hover:border-emerald/60 transition-colors " + (flash ? "flash" : "")}
    >
      <div className="relative aspect-square rounded-2xl overflow-hidden bg-night">
        <CoinArt coin={coin} className="transition-transform duration-500 group-hover:scale-105" />
        <div className="absolute top-2 left-2 right-2 flex gap-1 overflow-hidden">
          {coin.curves.map((c) => (
            <span
              key={c.chain.key}
              className={"h-5 sm:h-6 px-1.5 sm:px-2 rounded-full text-[0.625rem] sm:text-[0.6875rem] font-semibold flex items-center shrink-0 " + (c.state === "closed" || c.state === "moved" ? "bg-black/60 text-white/60" : "text-white")}
              style={c.state === "closed" || c.state === "moved" ? undefined : { background: c.chain.color }}
            >
              {c.chain.short}
            </span>
          ))}
        </div>
        <LockBadge coinId={coin.id} size="sm" onArt className="absolute bottom-2 left-2" />
        {coin.graduatedOn ? (
          <span className="absolute bottom-2 right-2 h-6 px-2 rounded-full text-[0.6875rem] font-bold bg-emerald text-on-accent flex items-center">Graduated</span>
        ) : coin.graduating ? (
          <span className="absolute bottom-2 right-2 h-6 px-2 rounded-full text-[0.6875rem] font-bold bg-black/65 backdrop-blur-sm text-white flex items-center gap-1">🎓 Graduating…</span>
        ) : pct >= 80 ? (
          <span className="absolute bottom-2 right-2 h-6 px-2 rounded-full text-[0.6875rem] font-bold bg-warn-ink text-on-accent flex items-center">🔥 {pct}%</span>
        ) : null}
      </div>
      <div className="px-1.5 sm:px-2 pt-3 pb-1">
        <div className="font-display font-semibold text-[1rem] sm:text-[1.1875rem] leading-tight truncate">{coin.name}</div>
        <div className="text-[0.75rem] sm:text-[0.8125rem] text-ink-3 mt-0.5">${coin.symbol}</div>
        <div className="grid grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-2 sm:gap-3 mt-2.5">
          <span className="leading-none">
            <span className="block text-[0.625rem] font-semibold tracking-wider uppercase text-ink-3">MC</span>
            <span className="block font-mono font-bold tabular-nums tracking-tight text-[1.0625rem] sm:text-[1.3125rem] mt-1">
              {compactUsd(coinMarketCapUsd(coin, ethUsd))}
            </span>
          </span>
          <Sparkline pts={spark} className="w-full h-8 sm:h-9" />
          <ChangePill value={coin.change24h} />
        </div>
        <div className="flex justify-between text-[0.6875rem] sm:text-[0.75rem] text-ink-3 mt-2 mb-1.5">
          <span>{coin.graduatedOn ? `Won on ${coin.graduatedOn.chain.short}` : "Graduation"}</span>
          <span className="font-mono text-ink-2">{pct}%</span>
        </div>
        <RaceBar coin={coin} />
        <div className="flex justify-between items-center text-[0.6875rem] sm:text-[0.75rem] mt-3 pt-2.5 border-t border-line">
          <span className="font-mono text-ink-3 truncate">{coin.holders} holders · {shortAddr(coin.creator)}</span>
          <span className="text-emerald font-semibold shrink-0 ml-2">{timeAgo(coin.createdAt)}</span>
        </div>
      </div>
    </Link>
  );
}

/** The coins closest to graduating, big. */
export function GraduationRadar({ coins, ethUsd }: { coins: Coin[]; ethUsd: number | null }) {
  const top = coins
    .filter((c) => !c.graduatedOn && c.totalUsd !== null)
    .sort((a, b) => b.progress - a.progress)
    .slice(0, 3);
  if (top.length === 0) return null;
  return (
    <div className="grid gap-3 md:grid-cols-3">
      {top.map((c, i) => {
        const left = Math.max(0, TARGET_USD - (c.totalUsd ?? 0));
        return (
          <Link key={c.id} href={coinHref(c)} className="flex gap-3 items-center rounded-2xl bg-surface border border-line p-3 hover:border-emerald/60">
            <div className="relative w-16 h-16 rounded-xl overflow-hidden shrink-0">
              <CoinArt coin={c} small />
              <span className="absolute bottom-0 left-0 right-0 text-center text-[0.625rem] font-bold bg-black/60 text-white">#{i + 1}</span>
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex justify-between items-baseline gap-2">
                <span className="font-semibold truncate">{c.name}</span>
                <span className="font-display font-semibold text-emerald">{Math.round(c.progress * 100)}%</span>
              </div>
              <div className="mt-2">
                <RaceBar coin={c} />
              </div>
              <div className="text-[0.75rem] text-ink-3 mt-1.5 truncate">
                {left > 0 ? `${usd(left, 2)} to go` : "Graduating now"} · MC {compactUsd(coinMarketCapUsd(c, ethUsd))}
              </div>
            </div>
          </Link>
        );
      })}
    </div>
  );
}

/** Scrolling strip of the latest trades across the whole site. */
export function LiveTicker({ coins, ethUsd }: { coins: Coin[]; ethUsd: number | null }) {
  const [trades, setTrades] = useState<Trade[]>([]);
  useEffect(() => {
    let alive = true;
    const load = () =>
      fetchTrades({ limit: 24 })
        .then((t) => alive && setTrades(t))
        .catch(() => {});
    load();
    const t = setInterval(load, 6_000);
    return () => {
      alive = false;
      clearInterval(t);
    };
  }, []);
  const byId = new Map(coins.map((c) => [c.id, c]));
  const items = trades
    .map((t) => ({ t, coin: byId.get(t.coinId), chain: chainById(t.chainId) }))
    .filter((x) => x.coin && x.chain);
  if (items.length === 0) return null;
  const row = items.map(({ t, coin, chain }) => (
    <Link key={t.txHash + t.curve} href={coinHref(coin!)} className="flex items-center gap-1.5 sm:gap-2 px-3 sm:px-4 shrink-0 text-[0.6875rem] sm:text-[0.8125rem]">
      {t.trader.toLowerCase() === "0x000000000000000000000000000000000000dead" ? (
        <span className="text-mint font-semibold">🔥 BURN</span>
      ) : (
        <span className={t.isBuy ? "text-up font-semibold" : "text-danger font-semibold"}>{t.isBuy ? "BUY" : "SELL"}</span>
      )}
      <span className="font-semibold">${coin!.symbol}</span>
      <span className="font-mono text-ink-2">{ethUsd ? usd((t.nativeAmount / 1e18) * ethUsd, 2) : `${(t.nativeAmount / 1e18).toFixed(4)} ETH`}</span>
      {/* Phones get a coloured dot instead of the chain chip: keeps the strip slim. */}
      <span className="sm:hidden w-1.5 h-1.5 rounded-full shrink-0" style={{ background: chain!.color }} title={chain!.name} aria-label={chain!.name} />
      <span className="hidden sm:inline-flex"><ChainChip chain={chain!} /></span>
      <span className="text-ink-3">{timeAgo(t.ts)}</span>
      <span className="text-line">|</span>
    </Link>
  ));
  return (
    <div className="border-b border-line bg-paper overflow-hidden" aria-label="Latest trades">
      <div className="ticker-track flex w-max py-1 sm:py-2">
        <div className="flex">{row}</div>
        <div className="flex" aria-hidden="true">{row}</div>
      </div>
    </div>
  );
}

/** The 24h change as a small tinted pill (bold, easy to scan). */
export function ChangePill({ value }: { value: number | null }) {
  if (value === null || !Number.isFinite(value)) {
    return <span className="font-mono font-bold text-[0.75rem] sm:text-[0.8125rem] px-2 py-1 rounded-lg bg-line/60 text-ink-3">—</span>;
  }
  const pct = value * 100;
  const up = pct > 0.05;
  const down = pct < -0.05;
  const text = Math.abs(pct) >= 1000 ? `${(Math.abs(pct) / 1000).toFixed(1)}K%` : `${Math.abs(pct) >= 100 ? Math.abs(pct).toFixed(0) : Math.abs(pct).toFixed(1)}%`;
  return (
    <span
      className={
        "font-mono font-bold tabular-nums whitespace-nowrap text-[0.75rem] sm:text-[0.8125rem] px-2 py-1 rounded-lg " +
        (up ? "bg-up/15 text-up" : down ? "bg-danger/15 text-danger" : "bg-line/60 text-ink-3")
      }
    >
      {up ? "+" : down ? "−" : ""}
      {text}
    </span>
  );
}
