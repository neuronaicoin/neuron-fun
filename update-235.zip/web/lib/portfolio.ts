/**
 * The money view: total balance (header), cash, coin positions with profit
 * and loss, and which money sheet is open (portfolio, deposit, withdraw, sell).
 *
 * Everything is shown in dollars. Cash is the chain's gas coin today (ETH);
 * the USDC cash mode comes with mainnet.
 */
import { useSyncExternalStore } from "react";
import type { Address } from "viem";
import { CHAINS, USD_MODE, type NeuronChain } from "./config";
import { usdcAbi } from "./abis";
import { clientFor, fetchPortfolio, fetchTrades, nativePerToken, type Coin } from "./data";
import { fetchRacePositions, verifyRacePositions, type RaceCoin, type RacePosition } from "./race";
import { fetchExtHoldings, type ExtHolding } from "./extheld";
import { fetchSolHoldings } from "./solheld";
import { PERPS_TRADING, fetchPerpAccount, type PerpPosition } from "./perps";
import { transitSettle, transitUsd } from "./transit";

/** What cash is held in: dollars (USDC; USDG on Robinhood mainnet) in the dollar edition. */
export const CASH_SYMBOL = USD_MODE ? "USDC" : "ETH";

export type Position = {
  coin: Coin;
  /** Tokens held, summed over chains. */
  tokens: number;
  valueUsd: number;
  /** What the tokens still held cost (average cost), in dollars at today's ETH price. */
  costUsd: number | null;
  pnlUsd: number | null;
  pnlPct: number | null;
  /** Market cap at the average buy price, in dollars (null if no buys found). */
  avgMcapUsd: number | null;
  /** 24h change of this position's value, in dollars. */
  dayUsd: number;
};

export type Portfolio = {
  totalUsd: number;
  cashUsd: number;
  cashByChain: { chain: NeuronChain; wei: bigint; usd: number }[];
  coinsUsd: number;
  openPnlUsd: number;
  realizedUsd: number;
  dayUsd: number;
  dayPct: number;
  positions: Position[];
  /** Race coins held (counted in coinsUsd and totalUsd). */
  racePositions: RacePosition[];
  /** Other DEXs' coins and Market coins bought on sasa (counted in coinsUsd and totalUsd). */
  extPositions: ExtHolding[];
  /** The futures (Hyperliquid) account: its value counts in totalUsd; open positions listed. */
  futures: { valueUsd: number; available: number; positions: PerpPosition[] } | null;
  /** Dollars moving between Base and Solana right now (lib/transit.ts), counted in totalUsd. */
  transitUsd: number;
  ethUsd: number | null;
};

export type MoneySheet = null | { kind: "portfolio" } | { kind: "deposit" } | { kind: "withdraw" } | { kind: "sell"; coin: Coin; pct: number };

type State = { address: string | null; portfolio: Portfolio | null; loading: boolean; sheet: MoneySheet; version: number };

let state: State = { address: null, portfolio: null, loading: false, sheet: null, version: 0 };
const SERVER = state;
const listeners = new Set<() => void>();
function set(p: Partial<State>) {
  state = { ...state, ...p };
  listeners.forEach((l) => l());
}
export function useMoney(): State {
  return useSyncExternalStore(
    (l) => {
      listeners.add(l);
      return () => listeners.delete(l);
    },
    () => state,
    () => SERVER
  );
}

export function openMoney(sheet: MoneySheet) {
  set({ sheet });
  if (sheet && (sheet.kind === "portfolio" || sheet.kind === "deposit")) void refreshPortfolio();
}
export const closeMoney = () => {
  set({ sheet: null });
  void refreshPortfolio();
};

// ------------------------------------------------------------------ loading

let timer: ReturnType<typeof setInterval> | null = null;
let inflight: Promise<void> | null = null;

/** Called by <MoneyHost/> whenever the logged-in wallet changes. */
export function setMoneyAddress(address: string | null) {
  const a = address ? address.toLowerCase() : null;
  if (a === state.address) return;
  set({ address: a, portfolio: null, sheet: null });
  if (timer) clearInterval(timer);
  timer = null;
  if (a) {
    void refreshPortfolio();
    timer = setInterval(() => {
      if (document.visibilityState === "visible") void refreshPortfolio();
    }, 15_000);
  }
}

// back to the app (another tab, the phone unlocked): the numbers are fresh at once
if (typeof window !== "undefined") {
  const wake = () => {
    if (document.visibilityState === "visible" && state.address) void refreshPortfolio();
  };
  document.addEventListener("visibilitychange", wake);
  window.addEventListener("focus", wake);
}

// Race coins just traded, read from the chains until the indexer has caught up.
let checkChainUntil = 0;
const justTraded = new Map<string, RaceCoin>();
const checkingChain = () => {
  if (Date.now() < checkChainUntil) return true;
  justTraded.clear();
  return false;
};

/**
 * Right after any trade or money move: cash at once (chain reads only), then everything again
 * a few times while the chains and the lists catch up (a trade to another chain lands in seconds).
 */
export function afterTrade(coin?: RaceCoin): void {
  if (coin) {
    // for the next two minutes race balances come from the chains, not the (slower) indexer
    checkChainUntil = Date.now() + 120_000;
    justTraded.set(coin.coin.toLowerCase(), coin);
  }
  void refreshCash();
  void refreshPortfolio(true);
  for (const ms of [2_500, 6_000, 12_000, 25_000, 45_000]) setTimeout(() => void refreshPortfolio(true), ms);
}

/**
 * Reloads cash and holdings. `fresh`: the caller just changed them (a trade), so
 * a load that started before must not count; run another one after it.
 */
export function refreshPortfolio(fresh = false): Promise<void> {
  const address = state.address;
  if (!address) return Promise.resolve();
  if (inflight) return fresh ? inflight.then(() => refreshPortfolio()) : inflight;
  set({ loading: true });
  inflight = loadPortfolio(address, state.address === address ? state.portfolio : null, (partial) => {
    if (state.address === address) set({ portfolio: partial, version: state.version + 1 });
  })
    .then((p) => {
      if (state.address === address) set({ portfolio: p, version: state.version + 1 });
    })
    .catch(() => {})
    .finally(() => {
      inflight = null;
      set({ loading: false });
    });
  return inflight;
}

/**
 * Reads only the cash balances (a couple of quick chain reads, no database) and
 * updates the shown cash and total. Used right after a trade, before the full
 * reload (holdings, P&L) arrives.
 */
export async function refreshCash(): Promise<void> {
  const address = state.address;
  const p = state.portfolio;
  if (!address || !p) return;
  try {
    const cash = await readCash(address, p);
    const cur = state.portfolio;
    if (!cur || state.address !== address) return;
    const cashByChain = cash.map(({ chain, wei }) => {
      const old = cur.cashByChain.find((x) => x.chain.chain.id === chain.chain.id);
      const perWei = old && old.wei > 0n ? old.usd / Number(old.wei) : USD_PER_WEI(chain, cur);
      return { chain, wei, usd: Number(wei) * perWei };
    });
    const cashUsd = cashByChain.reduce((a, c) => a + c.usd, 0);
    // a coin just sold must leave the total together with the cash arriving (and a bought one arrive)
    let racePositions = cur.racePositions;
    let coinsUsd = cur.coinsUsd;
    if (checkingChain()) {
      racePositions = await verifyRacePositions(address, cur.racePositions, [...justTraded.values()]).catch(() => cur.racePositions);
      coinsUsd = cur.coinsUsd - sumUsd(cur.racePositions) + sumUsd(racePositions);
    }
    const now = state.portfolio ?? cur;
    if (state.address !== address) return;
    const moving = settleTransit(cashByChain, now.futures?.valueUsd);
    set({ portfolio: { ...now, cashByChain, cashUsd, racePositions, coinsUsd, transitUsd: moving, totalUsd: coinsUsd + cashUsd + (now.futures?.valueUsd ?? 0) + moving }, version: state.version + 1 });
  } catch {
    /* the full reload will fix it */
  }
}

// USD value of one unit of a chain's cash (USDC has 6 decimals, ETH 18).
function USD_PER_WEI(_chain: NeuronChain, p: Portfolio): number {
  if (USD_MODE) return 1e-6;
  return (p.ethUsd ?? 0) / 1e18;
}

/**
 * Moves the shown cash (and total) by `deltaUsd` right away, before the chain
 * confirms. Returns an undo for when the trade fails. The next real load
 * replaces it either way.
 */
export function optimisticCash(deltaUsd: number): () => void {
  return optimisticTrade(deltaUsd, 0);
}

/**
 * Moves the header numbers the moment a trade is sent: cash by `cashUsd`, the coins'
 * value by `coinsUsd` (so a buy doesn't look like money vanished from the total).
 * Returns an undo for when the trade fails; a later refresh replaces both with chain data.
 */
export function optimisticTrade(cashUsd: number, coinsUsd: number): () => void {
  const p = state.portfolio;
  if (!p || !Number.isFinite(cashUsd) || !Number.isFinite(coinsUsd) || (cashUsd === 0 && coinsUsd === 0)) return () => {};
  const bump = (dc: number, dv: number) => {
    const cur = state.portfolio;
    if (!cur) return;
    const cash = Math.max(0, cur.cashUsd + dc);
    set({ portfolio: { ...cur, cashUsd: cash, totalUsd: Math.max(0, cur.totalUsd + (cash - cur.cashUsd) + dv) }, version: state.version + 1 });
  };
  bump(cashUsd, coinsUsd);
  let undone = false;
  return () => {
    if (undone) return;
    undone = true;
    bump(-cashUsd, -coinsUsd);
  };
}

const sumUsd = (list: RacePosition[]) => list.reduce((a, p) => a + p.valueUsd, 0);

function uniqueChains(): NeuronChain[] {
  const seen = new Set<number>();
  return CHAINS.filter((c) => !seen.has(c.chain.id) && seen.add(c.chain.id));
}

/**
 * Everything at once. Other DEXs' coins and futures (reads on several chains and Hyperliquid) can
 * take longer than the rest: if they do, `onPartial` gets the portfolio first with their last
 * known values, so the page never waits on the slowest chain.
 */
async function loadPortfolio(address: string, prev: Portfolio | null = null, onPartial?: (p: Portfolio) => void): Promise<Portfolio> {
  const chains = uniqueChains();
  let extrasDone = false;
  const extras = Promise.all([
    Promise.all([
      fetchExtHoldings(address, prev?.extPositions.filter((h) => h.network !== "solana")).catch(() => prev?.extPositions.filter((h) => h.network !== "solana") ?? ([] as ExtHolding[])),
      // Solana coins (only for people who see Solana yet; nothing for anyone else)
      fetchSolHoldings(address, prev?.extPositions.filter((h) => h.network === "solana")).catch(() => prev?.extPositions.filter((h) => h.network === "solana") ?? ([] as ExtHolding[])),
    ]).then(([evm, sol]) => [...evm, ...sol].sort((a, b) => b.valueUsd - a.valueUsd)),
    PERPS_TRADING ? fetchPerpAccount(address).catch(() => null) : Promise.resolve(null),
  ]).finally(() => (extrasDone = true));
  const [pf, cash, trades, racePositions] = await Promise.all([
    fetchPortfolio(address),
    // Cash: USDC in the dollar edition (the chain's coin otherwise).
    readCash(address, prev, chains),
    fetchTrades({ trader: address, limit: 1000 }).catch(() => []),
    fetchRacePositions(address)
      .catch(() => prev?.racePositions ?? ([] as RacePosition[]))
      .then((list) => (checkingChain() ? verifyRacePositions(address, list, [...justTraded.values()]).catch(() => list) : list)),
  ]);
  const build = (extPositions: ExtHolding[], futures: Portfolio["futures"]) => buildPortfolio(pf, cash, trades, racePositions, extPositions, futures);
  if (!extrasDone && onPartial) onPartial(build(prev?.extPositions ?? [], prev?.futures ?? null));
  const [extPositions, perp] = await extras;
  const futures = perp && (perp.accountValue > 0.005 || perp.positions.length) ? { valueUsd: perp.accountValue, available: perp.withdrawable, positions: perp.positions } : perp === null ? (prev?.futures ?? null) : null;
  return build(extPositions, futures);
}

function buildPortfolio(
  pf: Awaited<ReturnType<typeof fetchPortfolio>>,
  cash: { chain: NeuronChain; wei: bigint }[],
  trades: Awaited<ReturnType<typeof fetchTrades>>,
  racePositions: RacePosition[],
  extPositions: ExtHolding[],
  futures: Portfolio["futures"]
): Portfolio {
  const prices = pf.prices ?? {};
  const ethUsd = prices.ETH ?? null;
  const px = (c: NeuronChain) => (c.priceSymbol === "USD" ? 1 : prices[c.priceSymbol] ?? 0);

  const cashByChain = cash.map(({ chain, wei }) => ({ chain, wei, usd: (Number(wei) / 1e18) * px(chain) }));
  const cashUsd = cashByChain.reduce((a, c) => a + c.usd, 0);

  // Buys and sells per coin, in native units (wei floats), for average cost.
  const flows = new Map<string, { spent: number; bought: number; got: number; sold: number }>();
  for (const t of trades) {
    const f = flows.get(t.coinId) ?? { spent: 0, bought: 0, got: 0, sold: 0 };
    if (t.isBuy) {
      f.spent += t.nativeAmount;
      f.bought += t.tokenAmount;
    } else {
      f.got += t.nativeAmount;
      f.sold += t.tokenAmount;
    }
    flows.set(t.coinId, f);
  }

  // Positions, summed over chains.
  const byCoin = new Map<string, { coin: Coin; tokens: number; valueUsd: number }>();
  for (const h of pf.holdings) {
    const p = px(h.curve.chain);
    const value = h.amount * nativePerToken(h.curve) * p;
    const cur = byCoin.get(h.coin.id) ?? { coin: h.coin, tokens: 0, valueUsd: 0 };
    cur.tokens += h.amount;
    cur.valueUsd += value;
    byCoin.set(h.coin.id, cur);
  }
  const unit = ethUsd ?? 0; // native amounts are ETH on our chains

  let realizedUsd = 0;
  for (const [, f] of flows) {
    if (f.bought > 0 && f.sold > 0) {
      const avg = f.spent / f.bought;
      realizedUsd += ((f.got - avg * f.sold) / 1e18) * unit;
    }
  }

  const positions: Position[] = [...byCoin.values()]
    .filter((p) => p.valueUsd >= 0.01 || p.tokens >= 1)
    .map(({ coin, tokens, valueUsd }) => {
      const f = flows.get(coin.id);
      const avgWeiPerToken = f && f.bought > 0 ? f.spent / f.bought : null; // wei per token-wei = ETH per token
      const costUsd = avgWeiPerToken !== null && unit ? avgWeiPerToken * tokens * unit : null;
      const pnlUsd = costUsd !== null ? valueUsd - costUsd : null;
      const ch = coin.change24h;
      return {
        coin,
        tokens,
        valueUsd,
        costUsd,
        pnlUsd,
        pnlPct: costUsd && costUsd > 0 && pnlUsd !== null ? pnlUsd / costUsd : null,
        avgMcapUsd: avgWeiPerToken !== null && unit ? avgWeiPerToken * 1e9 * unit : null,
        dayUsd: ch !== null && ch > -1 ? valueUsd - valueUsd / (1 + ch) : 0,
      };
    })
    .sort((a, b) => b.valueUsd - a.valueUsd);

  const coinsUsd =
    positions.reduce((a, p) => a + p.valueUsd, 0) + racePositions.reduce((a, p) => a + p.valueUsd, 0) + extPositions.reduce((a, p) => a + p.valueUsd, 0);
  const openPnlUsd = positions.reduce((a, p) => a + (p.pnlUsd ?? 0), 0);
  const dayUsd = positions.reduce((a, p) => a + p.dayUsd, 0);
  const moving = settleTransit(cashByChain, futures?.valueUsd);
  const totalUsd = cashUsd + coinsUsd + (futures?.valueUsd ?? 0) + moving;
  const start = totalUsd - dayUsd;
  return {
    totalUsd,
    cashUsd,
    cashByChain,
    coinsUsd,
    openPnlUsd,
    realizedUsd,
    dayUsd,
    dayPct: start > 0 ? dayUsd / start : 0,
    positions,
    racePositions,
    extPositions,
    futures,
    transitUsd: moving,
    ethUsd,
  };
}

// ------------------------------------------------------------------ formatting

export function money(v: number): string {
  const neg = v < 0;
  const a = Math.abs(v);
  const s =
    a >= 1e6
      ? `$${(a / 1e6).toFixed(2)}M`
      : `$${a.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  return neg ? `−${s}` : s;
}
export const signed = (v: number) => `${v >= 0 ? "+" : "−"}${money(Math.abs(v))}`;
export const pctText = (v: number) => `${v >= 0 ? "+" : "−"}${Math.abs(v * 100).toFixed(1)}%`;
export function tokensText(n: number): string {
  if (n >= 1e9) return `${(n / 1e9).toFixed(2)}B`;
  if (n >= 1e6) return `${(n / 1e6).toFixed(2)}M`;
  if (n >= 1e3) return `${(n / 1e3).toFixed(1)}K`;
  return n.toFixed(n < 10 ? 2 : 0);
}
export function capText(v: number): string {
  if (v >= 1e9) return `$${(v / 1e9).toFixed(2)}B`;
  if (v >= 1e6) return `$${(v / 1e6).toFixed(2)}M`;
  if (v >= 1e3) return `$${(v / 1e3).toFixed(1)}K`;
  return `$${v.toFixed(v < 10 ? 2 : 0)}`;
}

/**
 * Cash on every chain. A chain whose read fails (a busy public node) keeps its last known
 * amount instead of counting as zero, so the total doesn't jump down and back.
 */
async function readCash(address: string, prev: Portfolio | null, chains = uniqueChains()): Promise<{ chain: NeuronChain; wei: bigint }[]> {
  return Promise.all(
    chains.map(async (c) => {
      const last = prev?.cashByChain.find((x) => x.chain.chain.id === c.chain.id)?.wei;
      for (let i = 0; i < 2; i++) {
        try {
          return { chain: c, wei: await cashOfStrict(c, address as Address) };
        } catch {
          if (i === 0) await new Promise((r) => setTimeout(r, 400));
        }
      }
      return { chain: c, wei: last ?? 0n };
    })
  );
}

/** Drops moves to Cash that have landed on Base; returns what is still on its way. */
function settleTransit(cashByChain: { chain: NeuronChain; usd: number }[], futuresUsd?: number): number {
  const base = cashByChain.find((c) => c.chain.key === "base");
  if (base) transitSettle(base.usd, futuresUsd);
  return transitUsd();
}

async function cashOfStrict(c: NeuronChain, address: Address): Promise<bigint> {
  const pub = clientFor(c);
  if (USD_MODE) return pub.readContract({ address: c.usdc, abi: usdcAbi, functionName: "balanceOf", args: [address] }) as Promise<bigint>;
  return pub.getBalance({ address });
}

/** Spendable cash on one chain: its USDC (dollar edition), else its native coin. Raw units. */
export async function cashOf(c: NeuronChain, address: Address): Promise<bigint> {
  const pub = clientFor(c);
  if (USD_MODE) return (pub.readContract({ address: c.usdc, abi: usdcAbi, functionName: "balanceOf", args: [address] }) as Promise<bigint>).catch(() => 0n);
  return pub.getBalance({ address }).catch(() => 0n);
}
