"use client";

import { GetAppButton } from "@/components/getapp";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { useWallet, walletAppLinks, type WalletOption } from "./wallet";
import { CHAINS, IS_TESTNET, V6 } from "@/lib/config";
import { useSafety } from "@/lib/safety";
import { SasaMark, SasaWordmark } from "./landing";
import { shortAddr } from "@/lib/format";
import { AlertsSync, HeaderBell } from "./alerts";
import { BalancePill, MoneyHost } from "./portfolio";
import { SocialSync } from "./social";
import { RefCapture } from "./refcapture";
import { useMyTotal } from "@/lib/points";
import { installHaptics } from "@/lib/haptics";

export function LogoMark({ size = 32 }: { size?: number }) {
  return <SasaMark size={size} />;
}

export function TestnetBanner() {
  if (!IS_TESTNET) return null;
  return (
    <div className="bg-paper border-b border-line text-ink-3 text-center text-[0.75rem] leading-snug px-4 py-1.5"><span className="inline-block w-1.5 h-1.5 rounded-full bg-warn-ink mr-2 align-middle" aria-hidden="true" />
      <span className="sm:hidden">Testnet · free test dollars, no real value</span>
      <span className="hidden sm:inline">Test version. It uses free test dollars (USDC), so nothing here has real value.</span>
    </div>
  );
}

/** Shown on every app page while buying is paused on any chain (beta safety lock). */
export function PauseBanner() {
  const safety = useSafety();
  const paused = CHAINS.filter((c) => safety[c.key]?.paused).map((c) => c.short);
  if (!paused.length) return null;
  const where =
    paused.length === CHAINS.length ? "every chain" : paused.length === 1 ? paused[0] : `${paused.slice(0, -1).join(", ")} and ${paused[paused.length - 1]}`;
  return (
    <div role="status" className="bg-warn-bg text-warn-ink text-center text-[0.8125rem] leading-snug px-4 py-2 border-b border-line">
      Buying on {where} is paused for a moment. Selling works as usual.
    </div>
  );
}

export function ConnectButton({ full = false }: { full?: boolean }) {
  const { address, wallets, connecting, connect, loginWithEmail } = useWallet();
  const [sheet, setSheet] = useState<"none" | "pick">("none");
  const [error, setError] = useState("");
  const base =
    "h-11 px-5 rounded-xl text-[0.9375rem] font-semibold inline-flex items-center justify-center gap-2 transition-colors " +
    (full ? "w-full " : "");

  async function pick(w: WalletOption) {
    setError("");
    try {
      await connect(w);
      setSheet("none");
    } catch (e) {
      const code = (e as { code?: number }).code;
      setError(
        code === 4001
          ? "You cancelled it in your wallet."
          : `${w.name} could not connect. Try MetaMask, Rabby or Coinbase Wallet.`
      );
    }
  }

  // Logged in: the balance (opens the portfolio, with address and log out) and ＋ Deposit.
  if (address) return <BalancePill />;
  return (
    <>
      <button
        type="button"
        className={base + "bg-ink text-on-accent hover:bg-ink-2 disabled:opacity-60"}
        disabled={connecting}
        onClick={() => {
          setError("");
          setSheet("pick");
        }}
      >
        {connecting ? "Connecting…" : "Log in"}
      </button>
      {error && sheet === "none" && <p className="text-[0.8125rem] text-danger mt-2 max-w-xs">{error}</p>}
      {sheet === "pick" && (
        <Sheet title="Log in to sasa" onClose={() => setSheet("none")}>
          <button
            type="button"
            onClick={() => {
              setSheet("none");
              loginWithEmail();
            }}
            className="h-14 w-full rounded-xl bg-emerald text-on-accent font-bold text-[1rem] hover:bg-emerald-dark"
          >
            Continue with email or Google
          </button>
          <p className="text-[0.75rem] text-ink-3 mt-2 text-center">No wallet needed. Network fees are paid from your USDC.</p>
          <div className="flex items-center gap-3 my-5 text-[0.75rem] text-ink-3" aria-hidden="true">
            <span className="h-px flex-1 bg-line" />
            or use your own wallet
            <span className="h-px flex-1 bg-line" />
          </div>
          {wallets.length > 0 ? (
            <div className="grid gap-2">
              {wallets.map((w) => (
                <button
                  key={w.id}
                  type="button"
                  disabled={connecting}
                  onClick={() => pick(w)}
                  className="h-14 px-4 rounded-xl border border-line bg-surface flex items-center gap-3 text-left font-semibold hover:border-emerald disabled:opacity-60"
                >
                  {w.icon ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img src={w.icon} alt="" width={30} height={30} className="rounded-lg" />
                  ) : (
                    <span className="w-[30px] h-[30px] rounded-lg bg-mist" aria-hidden="true" />
                  )}
                  {w.name}
                </button>
              ))}
            </div>
          ) : (
            <>
              <p className="text-ink-2 text-[0.9375rem] leading-relaxed">
                A wallet is an app that holds your coins. On a phone, open this page inside your wallet app. On a
                computer, install a wallet extension such as MetaMask or Rabby and refresh.
              </p>
              <div className="mt-4 grid grid-cols-2 gap-2">
                {walletAppLinks().map((l) => (
                  <a key={l.name} href={l.href} className="h-12 px-3 rounded-xl bg-emerald text-on-accent text-[0.875rem] font-semibold flex items-center justify-center text-center">
                    {l.name}
                  </a>
                ))}
              </div>
              <a
                href="https://metamask.io/download/"
                target="_blank"
                rel="noreferrer"
                className="mt-3 h-12 rounded-xl border border-ink text-ink font-semibold flex items-center justify-center"
              >
                Get a wallet
              </a>
            </>
          )}
          {error && <p className="text-[0.875rem] text-danger mt-4" role="alert">{error}</p>}
        </Sheet>
      )}
    </>
  );
}

/** Light / dark switch. Remembers the choice; light until the user picks. */
export function ThemeToggle() {
  const [theme, setTheme] = useState<"light" | "dark" | null>(null);
  useEffect(() => {
    setTheme(document.documentElement.getAttribute("data-theme") === "dark" ? "dark" : "light");
  }, []);
  const flip = () => {
    const next = theme === "light" ? "dark" : "light";
    document.documentElement.setAttribute("data-theme", next);
    try {
      localStorage.setItem("sasa-theme", next);
    } catch {}
    setTheme(next);
  };
  return (
    <button
      type="button"
      onClick={flip}
      aria-label={theme === "light" ? "Switch to dark mode" : "Switch to light mode"}
      title={theme === "light" ? "Dark mode" : "Light mode"}
      className="w-10 h-10 shrink-0 rounded-xl border border-line text-ink-2 hover:text-ink flex items-center justify-center"
    >
      {theme === "light" ? (
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" aria-hidden="true">
          <path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z" />
        </svg>
      ) : (
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" aria-hidden="true">
          <circle cx="12" cy="12" r="4" />
          <path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4" />
        </svg>
      )}
    </button>
  );
}

export function Sheet({ title, onClose, children }: { title: string; onClose: () => void; children: React.ReactNode }) {
  // Rendered into <body>: a parent with backdrop blur would otherwise trap
  // this "fixed" overlay inside itself.
  return createPortal(
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60" onClick={onClose}>
      <div
        role="dialog"
        aria-modal="true"
        aria-label={title}
        className="w-full sm:max-w-md max-h-[90dvh] overflow-y-auto overscroll-contain bg-surface rounded-t-2xl sm:rounded-2xl px-4 pt-5 sm:p-6 safe-bottom"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between gap-4 mb-4">
          <h2 className="font-display text-[1.125rem] font-bold">{title}</h2>
          <button type="button" onClick={onClose} aria-label="Close" className="w-10 h-10 -mr-2 rounded-full text-ink-3 text-[1.625rem] leading-none">
            ×
          </button>
        </div>
        {children}
      </div>
    </div>,
    document.body
  );
}

// `from`: the screen width a link first shows in the top bar, so it never
// overflows on tablets (md), small laptops (lg) or wide screens (xl).
// Pages that only work with v6 coins: hidden on mainnet (see V6 in lib/config.ts)
const V6_ONLY = new Set(["/traders/", "/copy/", "/swipe/"]);
const NAV_ALL = [
  { href: "/explore/", label: "Explore", from: "md" },
  { href: "/market/", label: "Market", from: "lg" },
  { href: "/terminal/", label: "Terminal", from: "lg" },
  { href: "/race/launch/", label: "Create a coin", from: "md" },
  { href: "/me/", label: "You", from: "lg" },
  // in "More" on computers too: a short, calm top bar
  { href: "/traders/", label: "Traders", from: "never" },
  { href: "/copy/", label: "Copy", from: "never" },
  { href: "/points/", label: "Points", from: "never" },
  { href: "/forum/", label: "Forum", from: "never" },
  { href: "/stats/", label: "Stats", from: "lg" },
] as const;
const NAV = NAV_ALL.filter((n) => V6 || !V6_ONLY.has(n.href));
const SHOW_FROM = { md: "", lg: "hidden lg:inline", xl: "hidden xl:inline", never: "hidden" } as const;

function isActive(pathname: string, href: string) {
  if (href === "/") return pathname === "/";
  // Futures is the second half of Market (Spot | Futures)
  if (href === "/market/" && /^\/(futures|perps|data)(\/|$)/.test(pathname)) return true;
  return pathname.startsWith(href.replace(/\/$/, ""));
}

export function Header() {
  const pathname = usePathname() || "/";
  // Download the chart library while the browser is idle: the first chart opens faster.
  useEffect(() => {
    const warm = () => void import("lightweight-charts").catch(() => {});
    const w = window as Window & { requestIdleCallback?: (cb: () => void) => number };
    if (w.requestIdleCallback) w.requestIdleCallback(warm);
    else setTimeout(warm, 2000);
  }, []);
  return (
    <header className="sticky top-0 z-40 bg-paper border-b border-line" style={{ paddingTop: "env(safe-area-inset-top, 0px)" }}>
      <div className="max-w-7xl mx-auto h-16 px-4 sm:px-6 flex items-center justify-between gap-3 lg:gap-4">
        <Link href="/explore/" className="flex items-center gap-2 text-ink shrink-0">
          <LogoMark size={32} />
          <SasaWordmark height={21} />
        </Link>
        <nav aria-label="Main" className="hidden md:flex items-center gap-3 lg:gap-4 xl:gap-6 text-[0.8125rem] lg:text-[0.875rem] xl:text-[0.9375rem] font-medium whitespace-nowrap min-w-0">
          {NAV.map((n) =>
            n.href === "/forum/" ? (
              // The forum is server-rendered HTML, not part of the app: a normal link.
              <a key={n.href} href={n.href} className={"text-ink-3 hover:text-ink " + SHOW_FROM[n.from]}>
                {n.label}
              </a>
            ) : (
              <Link
                key={n.href}
                href={n.href}
                className={(isActive(pathname, n.href) ? "text-ink font-semibold " : "text-ink-3 hover:text-ink ") + SHOW_FROM[n.from]}
              >
                {n.label}
              </Link>
            )
          )}
          <HeaderMore />
        </nav>
        <div className="flex items-center gap-1.5 sm:gap-2 min-w-0">
          <AlertsSync />
          <MoneyHost />
          <SocialSync />
          <RefCapture />
          <PointsPill />
          <ThemeToggle />
          <HeaderBell />
          <ConnectButton />
        </div>
      </div>
    </header>
  );
}

// Everything that doesn't fit in the phone's bottom bar (or a tablet's top bar).
// `tablet`: only listed on tablets (phones already have these in the bottom bar).
const MORE_ALL = [
  { href: "/market/", label: "Market", note: "Top coins, futures and market data", tablet: true },
  { href: "/terminal/", label: "Terminal", note: "Live trading", tablet: true },
  { href: "/me/", label: "You", note: "Your coins, futures and profile", tablet: true },
  { href: "/traders/", label: "Top traders", note: "Follow the best" },
  { href: "/copy/", label: "Copy trading", note: "Signals from traders you copy" },
  { href: "/points/", label: "Points", note: "Quests, invites, leaderboard" },
  { href: "/swipe/", label: "Swipe", note: "Discover coins fast" },
  { href: "/play/", label: "Play", note: "Chain Run and Pump Tower" },
  { href: "/forum/", label: "Forum", note: "Every coin's community", plain: true },
  { href: "/stats/", label: "Stats", note: "Volume, fees, graduations" },
  { href: "/how-it-works/", label: "How it works", note: "sasa in 2 minutes" },
  { href: "/help/", label: "Help", note: "Answers, or write to us" },
] as const;
const MORE = MORE_ALL.filter((m) => V6 || !V6_ONLY.has(m.href)).map((m) =>
  !V6 && m.href === "/stats/" ? { ...m, note: "Races, volume, winners" } : m
);

function MoreSheet({ onClose }: { onClose: () => void }) {
  const pathname = usePathname() || "/";
  const { address, disconnect } = useWallet();
  const points = useMyTotal(address);
  return (
    <Sheet title="More" onClose={onClose}>
      <div className="grid -mx-1">
        <GetAppButton variant="tile" />
        {MORE.map((m) => {
          const active = isActive(pathname, m.href);
          const cls =
            ("tablet" in m ? "hidden md:flex " : "flex ") +
            "items-center justify-between gap-3 px-1 py-3 border-b border-line " +
            (active ? "text-emerald" : "text-ink");
          const inner = (
            <>
              <span className="min-w-0">
                <span className="block font-semibold text-[0.9375rem]">{m.label}</span>
                <span className="block text-[0.75rem] text-ink-3 leading-snug">{m.note}</span>
              </span>
              {m.href === "/points/" && points !== null ? (
                <span className="font-mono text-[0.875rem] text-ink-2 shrink-0">{points.toLocaleString("en-US")}</span>
              ) : (
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="text-ink-3 shrink-0" aria-hidden="true"><path d="M9 6l6 6-6 6" /></svg>
              )}
            </>
          );
          // The forum is served outside the app, so it needs a full page load.
          return "plain" in m ? (
            <a key={m.href} href={m.href} className={cls} onClick={onClose}>
              {inner}
            </a>
          ) : (
            <Link key={m.href} href={m.href} className={cls} onClick={onClose}>
              {inner}
            </Link>
          );
        })}
        {/* log in / log out, so another phone or a shared computer is easy */}
        <div className="pt-4 pb-1">
          {address ? (
            <div className="flex items-center justify-between gap-3">
              <span className="text-[0.8125rem] text-ink-3 min-w-0 flex items-center gap-2">
                <span className="truncate">
                  Logged in as <span className="font-mono text-ink-2">{shortAddr(address)}</span>
                </span>
                <CopyAddress address={address} />
              </span>
              <button
                type="button"
                onClick={() => {
                  onClose();
                  disconnect();
                }}
                className="h-10 px-4 rounded-xl border border-line font-semibold text-[0.875rem] hover:border-danger hover:text-danger shrink-0"
              >
                Log out
              </button>
            </div>
          ) : (
            <ConnectButton full />
          )}
        </div>
      </div>
    </Sheet>
  );
}

/** Copies the full address (it is shown shortened). */
function CopyAddress({ address }: { address: string }) {
  const [done, setDone] = useState(false);
  return (
    <button
      type="button"
      onClick={() =>
        void navigator.clipboard
          ?.writeText(address)
          .then(() => {
            setDone(true);
            setTimeout(() => setDone(false), 1500);
          })
          .catch(() => {})
      }
      aria-label="Copy your address"
      className="shrink-0 h-7 px-2 rounded-lg border border-line text-[0.75rem] font-semibold text-emerald hover:bg-paper"
    >
      {done ? "Copied" : "Copy"}
    </button>
  );
}

/** "More" for tablets, where the top bar only fits the main links. */
function HeaderMore() {
  const [open, setOpen] = useState(false);
  return (
    <>
      <button type="button" onClick={() => setOpen(true)} className="hidden md:inline text-ink-3 hover:text-ink" aria-haspopup="dialog">
        More
      </button>
      {open && <MoreSheet onClose={() => setOpen(false)} />}
    </>
  );
}

export function BottomNav() {
  const pathname = usePathname() || "/";
  const [more, setMore] = useState(false);
  // a light tick under the finger on every tap, site-wide (phones; lib/haptics.ts)
  useEffect(() => installHaptics(), []);
  // Bars that sit above this menu (You page's Deposit / Withdraw) use its real height.
  const navRef = useRef<HTMLElement>(null);
  useEffect(() => {
    const el = navRef.current;
    if (!el) return;
    const set = () => {
      const h = el.getBoundingClientRect().height;
      if (h > 0) document.documentElement.style.setProperty("--money-bar-bottom", `${Math.ceil(h)}px`);
      else document.documentElement.style.removeProperty("--money-bar-bottom");
    };
    set();
    const ro = new ResizeObserver(set);
    ro.observe(el);
    return () => {
      ro.disconnect();
      document.documentElement.style.removeProperty("--money-bar-bottom");
    };
  }, []);
  const moreActive = MORE.some((m) => !("tablet" in m) && isActive(pathname, m.href));
  return (
    <nav ref={navRef} aria-label="Main" className="md:hidden fixed bottom-0 inset-x-0 z-40 bg-paper border-t border-line pt-1.5" style={{ paddingBottom: "calc(env(safe-area-inset-bottom, 0px) + 0.375rem)" }}>
      {more && <MoreSheet onClose={() => setMore(false)} />}
      <div className="grid grid-cols-6">
        {NAV.filter((n) => n.href !== "/stats/" && n.href !== "/forum/" && n.href !== "/traders/" && n.href !== "/copy/" && n.href !== "/points/").map((n) => {
          const active = isActive(pathname, n.href);
          return (
            <Link
              key={n.href}
              href={n.href}
              className={"flex flex-col items-center gap-0.5 py-1 text-[0.6875rem] font-medium " + (active ? "text-ink" : "text-ink-3")}
            >
              <NavIcon name={n.label} />
              {n.label === "Create a coin" ? "Create" : n.label === "Terminal" ? "Trade" : n.label}
            </Link>
          );
        })}
        <button
          type="button"
          onClick={() => setMore(true)}
          aria-haspopup="dialog"
          className={"flex flex-col items-center gap-0.5 py-1 text-[0.6875rem] font-medium " + (moreActive ? "text-ink" : "text-ink-3")}
        >
          <svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
            <circle cx="5" cy="12" r="2" />
            <circle cx="12" cy="12" r="2" />
            <circle cx="19" cy="12" r="2" />
          </svg>
          More
        </button>
      </div>
    </nav>
  );
}

function NavIcon({ name }: { name: string }) {
  const common = { width: 22, height: 22, viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: 1.8, strokeLinecap: "round" as const, strokeLinejoin: "round" as const, "aria-hidden": true };
  if (name === "Explore")
    return (
      <svg {...common}>
        <circle cx="11" cy="11" r="7" />
        <path d="M20 20 L16 16" />
      </svg>
    );
  if (name === "Market")
    return (
      <svg {...common}>
        <path d="M4 20 V10" />
        <path d="M10 20 V4" />
        <path d="M16 20 V13" />
        <path d="M21 20 H3" />
      </svg>
    );
  if (name === "Terminal")
    return (
      <svg {...common}>
        <path d="M4 17 L9 11 L13 14 L20 6" />
        <path d="M15 6 H20 V11" />
      </svg>
    );
  if (name === "You" || name === "Your coins")
    return (
      <svg {...common}>
        <circle cx="12" cy="8" r="4" />
        <path d="M4 21 c1.5 -4 4.5 -6 8 -6 s6.5 2 8 6" />
      </svg>
    );
  if (name === "Create a coin")
    return (
      <svg {...common}>
        <circle cx="12" cy="12" r="9" />
        <path d="M12 8 V16 M8 12 H16" />
      </svg>
    );
  return (
    <svg {...common}>
      <circle cx="12" cy="12" r="9" />
      <path d="M9.5 9.5 a2.5 2.5 0 1 1 3.5 2.3 c-.7.3-1 .8-1 1.5 V14" />
      <circle cx="12" cy="17" r="0.6" fill="currentColor" />
    </svg>
  );
}

export function Footer() {
  return (
    <footer className="border-t border-line bg-paper mt-16 pb-24 md:pb-0">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 py-10 grid gap-6 md:grid-cols-[1fr_auto] md:items-start">
        <div className="max-w-2xl">
          <div className="flex items-center gap-2.5">
            <LogoMark size={26} />
            <SasaWordmark height={16} className="text-ink" />
          </div>
          <p className="text-[0.8125rem] leading-relaxed text-ink-2 mt-3">
            Meme coins are risky and can lose all their value. Only use money you can afford to lose. Nothing on this
            site is financial advice. Every transaction is signed in your own wallet; sasa never holds your
            funds.
          </p>
          <p className="text-[0.8125rem] leading-relaxed text-ink mt-2 font-semibold">
            sasa has no token. Any coin using the sasa or Sasapad name or logo is not ours. We only announce from{" "}
            <a href="https://x.com/sasapadfun" target="_blank" rel="noreferrer" className="text-emerald">@sasapadfun</a> on X and{" "}
            <a href="https://t.me/sasapadfun" target="_blank" rel="noreferrer" className="text-emerald">t.me/sasapadfun</a> on Telegram.
          </p>
        </div>
        <nav aria-label="Footer" className="flex flex-wrap gap-x-6 gap-y-2 text-[0.875rem] font-medium">
          <a href="/forum/" className="text-emerald">Forum</a>
          <Link href="/how-it-works/" className="text-emerald">How it works</Link>
          <a href="/top/" className="text-emerald">Top coins</a>
          <Link href="/learn/" className="text-emerald">Learn</Link>
          <Link href="/help/" className="text-emerald">Help</Link>
          <Link href="/terms/" className="text-emerald">Terms</Link>
          <Link href="/privacy/" className="text-emerald">Privacy</Link>
          <Link href="/risk/" className="text-emerald">Risks</Link>
          <Link href="/security/" className="text-emerald">Security</Link>
          <Link href="/stats/" className="text-emerald">Stats</Link>
          <a href="/races/" className="text-emerald">Race results</a>
          <a href="https://x.com/sasapadfun" target="_blank" rel="noreferrer" className="text-emerald">X</a>
          <a href="https://t.me/sasapadfun" target="_blank" rel="noreferrer" className="text-emerald">Telegram</a>
        </nav>
      </div>
    </footer>
  );
}

/** Your points on very wide screens; elsewhere the "Points" link (and the You page on phones) leads there. */
function PointsPill() {
  const { address } = useWallet();
  const total = useMyTotal(address);
  if (!address || total === null) return null;
  return (
    <Link
      href="/points/"
      title="Your points"
      className="hidden 2xl:flex h-10 items-center gap-1.5 px-3 rounded-xl border border-line font-semibold text-[0.875rem] hover:text-ink"
    >
      <span className="font-mono tabular-nums">{total.toLocaleString("en-US")}</span>
      <span className="text-ink-3 font-normal">pts</span>
    </Link>
  );
}
