import { createPublicClient, encodeFunctionData, fallback, http, maxUint256, parseAbi, type Address, type Chain, type Hex, type PublicClient } from "viem";
import { mainnet } from "viem/chains";
import { getQuote, NATIVE, type Quote } from "./relay";
import { raceChain, raceClient, raceErc20Abi, type RaceChain } from "./race";
import { homeChain } from "./racecross";
import { IS_TESTNET } from "./config";
import { ELYSIUM_MAINNET, elysiumClient } from "./elysium";
import type { Call } from "./tx";

/**
 * Other DEXs' coins on chains where the user's dollars aren't: Relay moves the dollars and
 * swaps in one go. Buying: the user's USDC on Base → the coin on its chain (one Base step; for
 * email accounts the network fee is paid in USDC). If the user has almost no gas there, a few
 * cents of the same USDC also become that chain's gas coin, so they can sell later. Selling:
 * the coin on its chain → USDC on Base, sent from the user's own address there (gas from that
 * top-up). sasa pays no one's gas; its 1% fee is in Relay's quote.
 */

/** Elysium (Kinetiq's chain, HYPE gas): its coins are bought with Base USDC through Relay, like Ethereum's. */
export const ELY_CHAIN_ID = 99901;
/** Other DEXs' networks → chain ids ("ely": Elysium coins from other launchpads, vetted by indexer/elyext.mjs). */
const NETWORK_CHAIN: Record<string, number> = { base: 8453, bsc: 56, robinhood: 4663, arc: 5042, eth: 1, ely: ELY_CHAIN_ID };

/** A chain coins are traded on: a race chain, or Ethereum (no sasa contracts there, only Relay). */
export type XChain = { chainId: number; short: string; chain: Chain; usd: Address };

/** Ethereum: coins from the Market list are bought there from Base USDC through Relay. */
export const ETHEREUM: XChain = {
  chainId: 1,
  short: "Ethereum",
  chain: mainnet,
  usd: "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48",
};
/** Elysium mainnet (null until lib/elysium-mainnet.json is filled). USDC there is Relay's. */
export const ELYSIUM_X: XChain | null = ELYSIUM_MAINNET
  ? { chainId: ELY_CHAIN_ID, short: "Elysium", chain: ELYSIUM_MAINNET.chain, usd: "0xb47c4c8f73f009cc0c0d3f92b388d13e293f0b65" }
  : null;
let ethClient: PublicClient | null = null;
/** A reader for `c` (race chains share the race clients). */
export function xClient(c: XChain): PublicClient {
  if (c.chainId === ELY_CHAIN_ID) return elysiumClient();
  if (c.chainId !== 1) return raceClient(c as RaceChain);
  ethClient ??= createPublicClient({
    chain: mainnet,
    transport: fallback([http("https://ethereum-rpc.publicnode.com"), http("https://eth.llamarpc.com"), http()]),
  }) as PublicClient;
  return ethClient;
}
export const xChain = (chainId: number): XChain | null =>
  chainId === 1 ? ETHEREUM : chainId === ELY_CHAIN_ID ? ELYSIUM_X : (raceChain(chainId) ?? null);

/** Below this much gas coin on a chain, a buy brings a little with it. */
const GAS_FLOOR: Record<number, bigint> = { 4663: 50_000_000_000_000n, 56: 200_000_000_000_000n, 5042: 100_000_000_000_000_000n, 1: 600_000_000_000_000n, [ELY_CHAIN_ID]: 2_000_000_000_000_000n };
/** The gas top-up, in USDC (6 decimals on Base): 30 cents; $3 on Ethereum, where a sale costs more. */
export const GAS_TOPUP_USDC = 300_000n;
export const gasTopup = (chainId: number) => (chainId === 1 ? 3_000_000n : GAS_TOPUP_USDC);
/** Left on Base for the network fee of the Base step itself (email accounts pay it in USDC). */
const BASE_FEE_ROOM = 50_000n;

export type ExtRoute =
  | { kind: "same" } // the coin is where the dollars are: the existing same-chain swap
  | { kind: "cross"; home: RaceChain; there: XChain }
  | { kind: "none"; why: string };

/**
 * How a coin on `network` is traded. Base coins: on Base. Robinhood coins: wallets keep using
 * their Robinhood dollars; email accounts trade from Base. BNB Chain and Arc coins: from Base.
 */
export function extRoute(network: string, emailAccount: boolean): ExtRoute {
  if (IS_TESTNET) return { kind: "none", why: "Trading these coins opens at mainnet." };
  if (network === "base") return { kind: "same" };
  if (network === "robinhood" && !emailAccount) return { kind: "same" };
  const home = homeChain();
  const there = xChain(NETWORK_CHAIN[network] ?? -1);
  if (!home || !there) return { kind: "none", why: "Trading coins on this chain is coming soon." };
  return { kind: "cross", home, there };
}

/** The quote's transactions as calls on `chainId` (Relay's approve + deposit steps). */
export function quoteCallsOn(q: Quote, chainId: number): Call[] {
  const calls: Call[] = [];
  for (const step of q.steps) {
    if (step.kind !== "transaction") throw new Error("This trade needs a signature step we don't support yet.");
    for (const it of step.items) {
      if (Number(it.data.chainId) !== chainId) throw new Error("This route changed. Try again in a moment.");
      calls.push({ to: it.data.to as Address, data: it.data.data as Hex, value: it.data.value ? BigInt(it.data.value) : undefined });
    }
  }
  return calls;
}

/** True when the user has almost no gas coin on `c` (a buy then brings a little). */
export async function lowGas(c: XChain, user: Address): Promise<boolean> {
  const floor = GAS_FLOOR[c.chainId];
  if (floor === undefined) return false;
  const bal = await xClient(c).getBalance({ address: user });
  return bal < floor;
}

/** Price of a buy from Base (for "You get"). */
export function quoteCrossBuy(o: { user: Address; home: RaceChain; there: XChain; token: Address; amountHome: bigint; signal?: AbortSignal }) {
  return getQuote(
    {
      user: o.user,
      recipient: o.user,
      originChainId: o.home.chainId,
      destinationChainId: o.there.chainId,
      originCurrency: o.home.usd,
      destinationCurrency: o.token,
      amount: o.amountHome.toString(),
      fee: "swap",
    },
    o.signal
  );
}

/** Price of a sell back to Base. */
export function quoteCrossSell(o: { user: Address; home: RaceChain; there: XChain; token: Address; amount: bigint; signal?: AbortSignal }) {
  return getQuote(
    {
      user: o.user,
      recipient: o.user,
      originChainId: o.there.chainId,
      destinationChainId: o.home.chainId,
      originCurrency: o.token,
      destinationCurrency: o.home.usd,
      amount: o.amount.toString(),
      fee: "swap",
    },
    o.signal
  );
}

export type ExtSenders = {
  user: Address;
  sendHome: (chain: Chain, calls: Call[], onStep?: (m: string) => void) => Promise<Hex>;
  sendThere: (chain: Chain, calls: Call[], onStep?: (m: string) => void) => Promise<Hex>;
};

/** Buys `token` on `there` with `amountHome` of the user's USDC on Base (plus gas if they're low). */
export async function crossExtBuy(o: { s: ExtSenders; home: RaceChain; there: XChain; token: Address; amountHome: bigint; onStep?: (m: string) => void }) {
  const { s, home, there } = o;
  o.onStep?.("Getting the price…");
  const needGas = await lowGas(there, s.user).catch(() => false);
  const [q, gasQ] = await Promise.all([
    quoteCrossBuy({ user: s.user, home, there, token: o.token, amountHome: o.amountHome }),
    needGas
      ? getQuote({
          user: s.user,
          recipient: s.user,
          originChainId: home.chainId,
          destinationChainId: there.chainId,
          originCurrency: home.usd,
          destinationCurrency: NATIVE,
          amount: gasTopup(there.chainId).toString(),
        }).catch(() => null)
      : Promise.resolve(null),
  ]);
  if (there.chainId === ELY_CHAIN_ID) await elysiumSafeBuy({ user: s.user, home, there, token: o.token, amountHome: o.amountHome, q });
  const total = o.amountHome + (gasQ ? gasTopup(there.chainId) : 0n);
  const bal = (await raceClient(home).readContract({ address: home.usd, abi: raceErc20Abi, functionName: "balanceOf", args: [s.user] })) as bigint;
  if (bal < total + BASE_FEE_ROOM) throw new Error(`Not enough USDC. You have $${(Number(bal) / 1e6).toFixed(2)}${gasQ ? ` (a buy here also brings $${(Number(gasTopup(there.chainId)) / 1e6).toFixed(2)} of gas)` : ""}.`);
  // the gas top-up first, so the last transaction (what a browser wallet reports) is the trade itself
  const calls = [...(gasQ ? quoteCallsOn(gasQ, home.chainId) : []), ...quoteCallsOn(q, home.chainId)];
  const tx = await s.sendHome(home.chain, calls, o.onStep);
  return { tx, quote: q, gas: !!gasQ };
}

/** Sells `amount` of `token` on `there`; the USDC goes to the user's address on Base. */
export async function crossExtSell(o: { s: ExtSenders; home: RaceChain; there: XChain; token: Address; amount: bigint; onStep?: (m: string) => void }) {
  const { s, home, there } = o;
  // a sale is two transactions there (approve, then swap): about 300k gas at today's price, with room
  const client = xClient(there);
  const [gas, gasPrice] = await Promise.all([client.getBalance({ address: s.user }), client.getGasPrice()]);
  const need = (300_000n * gasPrice * 12n) / 10n;
  const sym = there.chain.nativeCurrency.symbol;
  if (gas === 0n || gas < need) {
    const have = gas === 0n ? "no" : `only ${(Number(gas) / 1e18).toPrecision(2)}`;
    throw new Error(`You have ${have} ${sym} on ${there.short}; this sale needs about ${(Number(need) / 1e18).toPrecision(2)} ${sym} for the network fee. Any buy there from sasa brings a little.`);
  }
  o.onStep?.("Getting the price…");
  let q = await quoteCrossSell({ user: s.user, home, there, token: o.token, amount: o.amount });
  let calls = quoteCallsOn(q, there.chainId);
  // The quote's approval and its sale are two transactions there. Sent back to back, the sale is
  // checked against a node that may not see the approval yet (it then "reverts"), and on a slow
  // chain the price can be stale by the time the approval lands. So: approve once (for good, no
  // approval on later sales), wait until the chain shows it, then a fresh price and the sale alone.
  const approve = calls.find((c) => c.data.toLowerCase().startsWith(APPROVE) && c.to.toLowerCase() === o.token.toLowerCase());
  if (approve) {
    const spender = `0x${approve.data.slice(34, 74)}` as Address;
    const allowed = () => client.readContract({ address: o.token, abi: allowanceAbi, functionName: "allowance", args: [s.user, spender] }).catch(() => 0n) as Promise<bigint>;
    if ((await allowed()) < o.amount) {
      o.onStep?.(`Approving ${there.short} (one time)…`);
      await s.sendThere(there.chain, [{ to: o.token, data: encodeFunctionData({ abi: allowanceAbi, functionName: "approve", args: [spender, maxUint256] }) }], o.onStep);
      for (let i = 0; i < 30 && (await allowed()) < o.amount; i++) await new Promise((r) => setTimeout(r, 1_000));
    }
    o.onStep?.("Getting the price…");
    q = await quoteCrossSell({ user: s.user, home, there, token: o.token, amount: o.amount });
    calls = quoteCallsOn(q, there.chainId).filter((c) => !(c.data.toLowerCase().startsWith(APPROVE) && c.to.toLowerCase() === o.token.toLowerCase()));
  }
  const tx = await s.sendThere(there.chain, calls, o.onStep);
  return { tx, quote: q };
}

/** Most a buy of an Elysium coin may lose to price impact and fees (sasa's 1% included). */
export const ELY_MAX_BUY_LOSS = 0.06;
/** Least a sale of what's bought must bring back right away (a coin that can't be sold fails this). */
export const ELY_MIN_ROUND_TRIP = 0.85;

/**
 * Elysium coins: before every buy, the price must be fair for the amount and selling what it buys
 * must work right now, at a fair price. Otherwise nothing is sent and the user is told why.
 */
export async function elysiumSafeBuy(o: { user: Address; home: RaceChain; there: XChain; token: Address; amountHome: bigint; q: Quote }) {
  const paid = Number(o.amountHome) / 1e6;
  const got = o.q.outUsd;
  if (!(got > 0) || got < paid * (1 - ELY_MAX_BUY_LOSS))
    throw new Error("This coin's pool is too thin for that amount right now. Try a smaller amount.");
  const back = await quoteCrossSell({ user: o.user, home: o.home, there: o.there, token: o.token, amount: BigInt(o.q.outRaw) }).catch(() => null);
  if (!back || !(back.outUsd > 0) || back.outUsd < paid * ELY_MIN_ROUND_TRIP)
    throw new Error("This coin can't be sold back at a fair price right now, so sasa won't buy it. Nothing was spent.");
}

const APPROVE = "0x095ea7b3";
const allowanceAbi = parseAbi(["function allowance(address owner, address spender) view returns (uint256)", "function approve(address spender, uint256 amount) returns (bool)"]);
