import { IS_TESTNET } from "@/lib/config";
import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ARTICLES, SITE_URL, articleBySlug } from "@/lib/articles";
import { ArticleBody, JsonLd, LearnFooter, LearnHeader, Rich, Takeaways } from "@/components/learn";

export const dynamicParams = false;

export function generateStaticParams() {
  return ARTICLES.map((a) => ({ slug: a.slug }));
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const a = articleBySlug((await params).slug);
  if (!a) return {};
  const url = `/learn/${a.slug}/`;
  return {
    title: `${a.title} | sasa`,
    description: a.description,
    alternates: { canonical: url },
    openGraph: { title: a.title, description: a.description, url, type: "article", publishedTime: a.date, modifiedTime: a.updated, images: ["/og-sasa-2.png"] },
    twitter: { card: "summary_large_image", title: a.title, description: a.description, images: ["/og-sasa-2.png"] },
  };
}

export default async function ArticlePage({ params }: { params: Promise<{ slug: string }> }) {
  const a = articleBySlug((await params).slug);
  if (!a) notFound();
  // Related reading: most shared topics first, then newest.
  const tags = new Set(a.tags ?? []);
  const others = ARTICLES.filter((x) => x.slug !== a.slug)
    .map((x) => ({ x, score: (x.tags ?? []).filter((t) => tags.has(t)).length }))
    .sort((p, q) => q.score - p.score || q.x.date.localeCompare(p.x.date))
    .slice(0, 6)
    .map((p) => p.x);
  const url = `${SITE_URL}/learn/${a.slug}/`;
  return (
    <div className="min-h-dvh flex flex-col bg-mist">
      <LearnHeader />
      <main className="flex-1 max-w-3xl w-full mx-auto px-5 py-10 sm:py-14">
        <nav aria-label="Breadcrumb" className="text-[0.8125rem] text-ink-3">
          <Link href="/learn/" className="hover:text-ink">Learn</Link> <span aria-hidden="true">/</span>
        </nav>
        <article>
          <h1 className="font-display font-bold text-[2rem] sm:text-[2.75rem] tracking-tight mt-3 leading-[1.08]">{a.title}</h1>
          <p className="text-[0.875rem] text-ink-3 mt-4 font-mono">
            {a.readMin} min read · Updated {new Date(a.updated).toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" })}
          </p>
          {!IS_TESTNET && (
            <div className="mt-8 rounded-2xl border border-line bg-surface p-5 flex flex-col sm:flex-row sm:items-center gap-3">
              <p className="flex-1 text-[0.9375rem] text-ink-2">
                <b className="text-ink">Launch your own coin on sasa in a minute.</b> Keep it above $10K market cap for an hour and you earn 60% of its trading fees.
              </p>
              <div className="flex gap-2 shrink-0">
                <Link href="/race/launch/" className="inline-flex h-11 px-5 rounded-full bg-[#ff6b1a] text-white font-bold items-center">Launch a coin</Link>
                <Link href="/explore/" className="inline-flex h-11 px-5 rounded-full border border-line font-semibold items-center">Trade</Link>
              </div>
            </div>
          )}
          {a.takeaways && a.takeaways.length > 0 && (
            <div className="mt-8">
              <Takeaways items={a.takeaways} />
            </div>
          )}

          <div className="mt-8">
            <ArticleBody blocks={a.body} />
          </div>

          <section className="mt-12" aria-labelledby="faq">
            <h2 id="faq" className="font-display font-bold text-[1.5rem]">Questions</h2>
            <div className="mt-4 grid gap-3">
              {a.faq.map((f) => (
                <details key={f.q} className="rounded-2xl border border-line bg-surface px-5 py-4 group">
                  <summary className="font-semibold cursor-pointer list-none flex justify-between gap-4">
                    {f.q}
                    <span className="text-ink-3 group-open:rotate-45 transition-transform" aria-hidden="true">+</span>
                  </summary>
                  <p className="text-ink-2 mt-3 leading-relaxed"><Rich text={f.a} /></p>
                </details>
              ))}
            </div>
          </section>
        </article>

        {/* today's live meme coin record, put in by the edge (functions/learn/[slug].js); empty in the static page */}
        <div id="learn-live" suppressHydrationWarning dangerouslySetInnerHTML={{ __html: "" }} />

        <section className="mt-12 rounded-3xl border border-line bg-surface p-6 sm:p-8">
          <p className="font-display font-bold text-[1.375rem]">Trade any coin. Launch your own.</p>
          <p className="text-ink-2 mt-2">
            {IS_TESTNET
              ? "sasa is live on testnet and coming to mainnet soon."
              : "One USDC balance for Solana, Base, BNB Chain, Robinhood Chain, Arc and Ethereum: buy any meme coin, launch your own, trade futures and predictions."}
          </p>
          {!IS_TESTNET && (
            <div className="mt-4 flex flex-wrap gap-x-5 gap-y-2 text-[0.875rem] font-semibold">
              <Link href="/race/launch/" className="text-emerald">Launch a coin</Link>
              <Link href="/explore/" className="text-emerald">Explore coins</Link>
              <a href="/top/" className="text-emerald">Top meme coins today</a>
              <a href="/day/" className="text-emerald">Daily archive</a>
            </div>
          )}
          <div className="mt-5 flex flex-wrap items-center gap-3">
            {!IS_TESTNET && (
              <Link href="/race/launch/" className="inline-flex h-12 px-6 rounded-full bg-[#ff6b1a] text-white font-bold items-center">
                Launch a coin
              </Link>
            )}
            <a href="https://x.com/sasapadfun" target="_blank" rel="noreferrer" className="inline-flex h-12 px-6 rounded-full border border-line font-semibold items-center">
              Follow @sasapadfun
            </a>
          </div>
        </section>

        <section className="mt-12" aria-labelledby="more">
          <h2 id="more" className="font-display font-bold text-[1.25rem]">Keep reading</h2>
          <ul className="mt-4 grid gap-3 sm:grid-cols-2">
            {others.map((o) => (
              <li key={o.slug}>
                <Link href={`/learn/${o.slug}/`} className="block h-full rounded-2xl border border-line bg-surface p-5 hover:border-emerald/60">
                  <span className="font-semibold leading-snug">{o.title}</span>
                  <span className="block text-[0.8125rem] text-ink-3 mt-2">{o.readMin} min read</span>
                </Link>
              </li>
            ))}
          </ul>
        </section>
      </main>
      <LearnFooter />
      <JsonLd
        data={{
          "@context": "https://schema.org",
          "@graph": [
            {
              "@type": "Article",
              headline: a.title,
              description: a.description,
              datePublished: a.date,
              dateModified: a.updated,
              mainEntityOfPage: url,
              image: `${SITE_URL}/og-sasa-2.png`,
              keywords: (a.tags ?? []).join(", "),
              inLanguage: "en",
              author: { "@type": "Organization", name: "sasa", url: SITE_URL },
              publisher: { "@type": "Organization", name: "sasa", url: SITE_URL, logo: { "@type": "ImageObject", url: `${SITE_URL}/sasa-icon-192.png` } },
            },
            {
              "@type": "FAQPage",
              mainEntity: a.faq.map((f) => ({ "@type": "Question", name: f.q, acceptedAnswer: { "@type": "Answer", text: f.a.replace(/\[([^\]]+)\]\([^)]+\)/g, "$1") } })),
            },
            {
              "@type": "BreadcrumbList",
              itemListElement: [
                { "@type": "ListItem", position: 1, name: "Learn", item: `${SITE_URL}/learn/` },
                { "@type": "ListItem", position: 2, name: a.title, item: url },
              ],
            },
          ],
        }}
      />
    </div>
  );
}
