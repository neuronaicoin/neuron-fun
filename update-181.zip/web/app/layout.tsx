import type { Metadata, Viewport } from "next";
// Two self-hosted fonts (no Google request): Sora for headings and numbers, Instrument Sans for text.
// Loaded through next/font: the files are preloaded and the stand-in system font is sized to match,
// so nothing jumps sideways when the real font arrives (on every load and pull-to-refresh).
import localFont from "next/font/local";
import "./globals.css";
import { WalletProvider } from "@/components/wallet";
import { Header, BottomNav, Footer, TestnetBanner, PauseBanner } from "@/components/chrome";
import { PullToRefresh } from "@/components/pulltorefresh";
import { IS_TESTNET } from "@/lib/config";

const sora = localFont({
  src: [
    { path: "../node_modules/@fontsource/sora/files/sora-latin-600-normal.woff2", weight: "600", style: "normal" },
    { path: "../node_modules/@fontsource/sora/files/sora-latin-700-normal.woff2", weight: "700", style: "normal" },
    { path: "../node_modules/@fontsource/sora/files/sora-latin-800-normal.woff2", weight: "800", style: "normal" },
  ],
  variable: "--font-sora",
  display: "swap",
  adjustFontFallback: "Arial",
});
const instrument = localFont({
  src: [
    { path: "../node_modules/@fontsource/instrument-sans/files/instrument-sans-latin-400-normal.woff2", weight: "400", style: "normal" },
    { path: "../node_modules/@fontsource/instrument-sans/files/instrument-sans-latin-500-normal.woff2", weight: "500", style: "normal" },
    { path: "../node_modules/@fontsource/instrument-sans/files/instrument-sans-latin-600-normal.woff2", weight: "600", style: "normal" },
  ],
  variable: "--font-inst",
  display: "swap",
  adjustFontFallback: "Arial",
});

const SITE = "https://sasapad.fun";

export const metadata: Metadata = {
  metadataBase: new URL(SITE),
  title: "sasa — Launch once. Live on every chain.",
  description:
    IS_TESTNET
      ? "sasa launches your coin on every chain at the same time. Testnet live, mainnet coming soon."
      : "sasa launches your coin on Base, BNB Chain, Robinhood Chain and Arc at once. Buy any coin with USDC in one tap: no wallet to set up, no bridge.",
  icons: {
    icon: [
      { url: "/sasa-icon.svg", type: "image/svg+xml" },
      { url: "/sasa-icon-192.png", type: "image/png", sizes: "192x192" },
    ],
    apple: [{ url: "/apple-touch-icon.png", sizes: "180x180" }],
  },
  // Lets phones add sasa to the Home Screen (needed for alerts on iPhone).
  manifest: "/manifest.webmanifest",
  appleWebApp: { capable: true, title: "sasa", statusBarStyle: "black" },
  openGraph: {
    title: "sasa — Launch once. Live on every chain.",
    description: IS_TESTNET ? "The multi-chain launchpad. Testnet live, mainnet coming soon." : "The multi-chain launchpad. Launch once, live on every chain.",
    siteName: "sasa",
    type: "website",
    images: [
      IS_TESTNET
        ? { url: "/og-sasa-2.png", width: 1200, height: 630, alt: "sasa — Trade any coin. Launch your own." }
        : { url: "/og-sasa-2.png", width: 1200, height: 630, alt: "sasa — Trade any coin. Launch your own." },
    ],
  },
  twitter: {
    card: "summary_large_image",
    site: "@sasapadfun",
    title: "sasa — Launch once. Live on every chain.",
    description: IS_TESTNET ? "The multi-chain launchpad. Testnet live, mainnet coming soon." : "The multi-chain launchpad. Launch once, live on every chain.",
    images: [IS_TESTNET ? "/og-sasa-2.png" : "/og-sasa-2.png"],
  },
};

/**
 * Runs before first paint. On sasapad.fun the home page is the pre-launch
 * page; /learn pages always use their own simple chrome.
 */
const HOST_CHECK = (IS_TESTNET ? "" : "var NOLANDING=1;") + String.raw`try{var h=location.hostname,p=location.pathname,c=document.documentElement.classList;if(p.indexOf("/learn")===0){c.add("is-learn")}else if(typeof NOLANDING==="undefined"&&p==="/"&&(/(^|\.)sasapad\.(fun|com)$/.test(h)||/[?&]landing\b/.test(location.search))){c.add("is-landing")}}catch(e){}`;
/** Runs before first paint: the saved theme, light by default. No flash. */
const THEME_CHECK = String.raw`try{var t=localStorage.getItem("sasa-theme");if(t!=="light"&&t!=="dark"){t="light"}document.documentElement.setAttribute("data-theme",t);if(!localStorage.getItem("sasa.session"))document.documentElement.classList.add("is-guest")}catch(e){document.documentElement.setAttribute("data-theme","light")}`;

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  // Inputs are under 16px on phones; this stops iOS zooming in on focus.
  // People can still pinch-zoom (iOS ignores this for manual zoom).
  maximumScale: 1,
  viewportFit: "cover",
  themeColor: "#ffffff",
};

// Google Analytics 4 (visits and traffic sources only): live site only, no ads features or
// Google signals, and no analytics cookies in the EU/EEA, UK and Switzerland (consent mode:
// Google gets cookieless pings there). Page changes are counted by GA's browser-history tracking.
const GA_ID = "G-G35JGWX5FT";
const GA_INIT = `(function(){try{if(location.hostname!=="sasapad.fun"&&location.hostname!=="www.sasapad.fun")return;
window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}window.gtag=gtag;
gtag("consent","default",{ad_storage:"denied",ad_user_data:"denied",ad_personalization:"denied",analytics_storage:"granted"});
gtag("consent","default",{analytics_storage:"denied",region:["AT","BE","BG","HR","CY","CZ","DK","EE","FI","FR","DE","GR","HU","IE","IT","LV","LT","LU","MT","NL","PL","PT","RO","SK","SI","ES","SE","IS","LI","NO","GB","CH"]});
gtag("js",new Date());gtag("config","${GA_ID}",{allow_google_signals:false,allow_ad_personalization_signals:false});
var s=document.createElement("script");s.async=true;s.src="https://www.googletagmanager.com/gtag/js?id=${GA_ID}";document.head.appendChild(s);}catch(e){}})();`;

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${sora.variable} ${instrument.variable}`} suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: HOST_CHECK }} />
        <script dangerouslySetInnerHTML={{ __html: THEME_CHECK }} />
        <script dangerouslySetInnerHTML={{ __html: GA_INIT }} />
      </head>
      <body className="min-h-dvh flex flex-col">
        <WalletProvider>
          <div className="app-chrome">
            <TestnetBanner />
            <PauseBanner />
            <Header />
          </div>
          {/* At least a screen tall: the footer never sits mid-page and then jumps down when data arrives (layout shift). */}
          <main className="flex-1 w-full min-h-[100dvh]">{children}</main>
          <div className="app-chrome">
            <Footer />
            <BottomNav />
            <PullToRefresh />
          </div>
        </WalletProvider>
      </body>
    </html>
  );
}
