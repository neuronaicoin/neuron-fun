import type { Metadata } from "next";

export const metadata: Metadata = { title: "Daily post · sasa", robots: { index: false }, alternates: { canonical: "/daily/" } };

export default function Layout({ children }: { children: React.ReactNode }) {
  return children;
}
