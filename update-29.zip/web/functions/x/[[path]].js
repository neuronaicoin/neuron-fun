import { isMemeForList, listFor } from "../../edge/top-render.js";
/**
 * Cloudflare Pages Function for /x/?n=<network>&a=<token> (coins from any DEX).
 *
 * Link previews (X, Telegram) and search engines read meta tags without
 * running JavaScript: fill them in for the coin (name, price, market cap,
 * chain), plus structured data. The page itself is unchanged.
 */
const SUPABASE_URL = "https://rkoassatqhdkdptekvdt.supabase.co";
const SUPABASE_KEY = "sb_publishable_200jvFq0EQhdLdVToTzI7w_eWGtE1Ol";
const SITE = "https://sasapad.fun";
const NETS = { base: "Base", bsc: "BNB Chain", eth: "Ethereum", robinhood: "Robinhood Chain", arc: "Arc" };

const money = (v) => {
  const n = Number(v);
  if (!Number.isFinite(n) || n <= 0) return null;
  const t = (x) => x.replace(/\.?0+$/, "");
  if (n >= 1e9) return `$${t((n / 1e9).toFixed(2))}B`;
  if (n >= 1e6) return `$${t((n / 1e6).toFixed(2))}M`;
  if (n >= 1e3) return `$${t((n / 1e3).toFixed(1))}K`;
  return `$${n.toFixed(n < 1 ? 6 : 2)}`;
};
// JSON inside <script>: only <, > and & need escaping (quotes are already JSON-escaped).
const esc = (s) => String(s).replace(/[<>&]/g, (c) => ({ "<": "\\u003c", ">": "\\u003e", "&": "\\u0026" })[c]);

export async function onRequestGet(ctx) {
  const res = await ctx.next();
  if (!(res.headers.get("content-type") || "").includes("text/html")) return res;
  const url = new URL(ctx.request.url);
  const network = url.searchParams.get("n") || "";
  const address = (url.searchParams.get("a") || "").toLowerCase();
  if (!Object.prototype.hasOwnProperty.call(NETS, network) || !/^0x[0-9a-f]{40}$/.test(address)) return res;

  let c = null;
  try {
    const r = await fetch(
      `${SUPABASE_URL}/rest/v1/ext_coins_all?network=eq.${network}&address=eq.${address}&select=name,symbol,image,price_usd,mcap_usd,fdv_usd,vol_24h,change_24h,liq_usd,buys_24h,sells_24h,pool_created,dex`,
      { headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}` }, cf: { cacheTtl: 120, cacheEverything: true } }
    );
    if (r.ok) c = (await r.json())[0] || null;
  } catch {}
  if (!c) return res;

  const chain = NETS[network];
  // A coin nobody trades any more (no volume today, pool older than 30 days) stays reachable
  // but is kept out of search results, so thin pages don't drag the rest of the site down.
  const dead = !(Number(c.vol_24h) > 0) && (!c.pool_created || Date.now() - Date.parse(c.pool_created) > 30 * 86400_000);
  const mc = money(Number(c.mcap_usd) > 0 ? c.mcap_usd : c.fdv_usd);
  const ch = Number(c.change_24h);
  const title = `${c.name} ($${c.symbol}) price, chart and market cap on ${chain} · sasa`;
  const description = [
    `Buy and sell ${c.name} ($${c.symbol}) on ${chain} with USDC in one tap on sasa.`,
    mc ? `Market cap ${mc}.` : "",
    money(c.vol_24h) ? `24h volume ${money(c.vol_24h)}.` : "",
    Number.isFinite(ch) ? `24h change ${ch >= 0 ? "+" : ""}${ch.toFixed(1)}%.` : "",
  ]
    .filter(Boolean)
    .join(" ")
    .slice(0, 300);
  const pageUrl = `${SITE}/x/?n=${network}&a=${address}`;
  const set = (value) => ({ element: (e) => e.setAttribute("content", value) });
  const ld = {
    "@context": "https://schema.org",
    "@type": "WebPage",
    name: title,
    description,
    url: pageUrl,
    about: { "@type": "Thing", name: `${c.name} (${c.symbol})`, identifier: address },
    isPartOf: { "@type": "WebSite", name: "sasa", url: SITE },
  };
  let rw = new HTMLRewriter()
    .on("title", { element: (e) => e.setInnerContent(title) })
    .on('meta[name="description"]', set(description))
    .on('meta[property="og:title"]', set(title))
    .on('meta[name="twitter:title"]', set(title))
    .on('meta[property="og:description"]', set(description))
    .on('meta[name="twitter:description"]', set(description))
    .on('meta[property="og:url"]', set(pageUrl))
    .on('link[rel="canonical"]', { element: (e) => e.setAttribute("href", pageUrl) })
    .on("head", { element: (e) => e.append(`<script type="application/ld+json">${esc(JSON.stringify(ld))}</script>${dead ? '<meta name="robots" content="noindex">' : ""}`, { html: true }) });
  // Share image: the coin's own card (drawn by the indexer for busy coins), else the plain sasa card.
  // Never the homepage's sample coin.
  const card = `${SUPABASE_URL}/storage/v1/object/public/cards/x-${network}-${address}.png`;
  let img = `${SITE}/og-plain.png`;
  try {
    const h = await fetch(card, { method: "HEAD", cf: { cacheTtl: 300 } });
    if (h.ok) img = card;
  } catch {}
  rw = rw
    .on('meta[property="og:image"]', set(img))
    .on('meta[name="twitter:image"]', set(img))
    .on('meta[property="og:image:width"]', set("1200"))
    .on('meta[property="og:image:height"]', set("630"))
    .on('meta[property="og:image:alt"]', set(title));
  // Other busy coins on the same chain: links that help crawlers find more pages.
  let related = "";
  try {
    const r = await fetch(`${SUPABASE_URL}/rest/v1/ext_coins?network=eq.${network}&select=network,address,name,symbol,vol_24h&order=vol_24h.desc.nullslast&limit=24`, {
      headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}` },
      cf: { cacheTtl: 1800, cacheEverything: true },
    });
    if (r.ok) {
      const esc2 = (x) => String(x ?? "").replace(/[&<>"]/g, (k) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[k]);
      const list = (await r.json()).filter((o) => o.address !== address && isMemeForList(o)).slice(0, 12);
      if (list.length)
        related = `<h2>More meme coins on ${esc2(NETS[network])}</h2><ul>${list.map((o) => `<li><a href="${SITE}/x/?n=${o.network}&amp;a=${o.address}">${esc2(o.name)} ($${esc2(o.symbol)})</a></li>`).join("")}</ul>`;
    }
  } catch {}

  // A plain-text summary for crawlers and AI engines that don't run JavaScript.
  const html = (x) => String(x ?? "").replace(/[&<>"]/g, (k) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[k]);
  const price = Number(c.price_usd);
  const facts = [
    `Chain: ${chain}`,
    Number.isFinite(price) && price > 0 ? `Price: $${price < 0.01 ? price.toPrecision(3) : price.toFixed(4)}` : "",
    mc ? `Market cap: ${mc}` : "",
    money(c.liq_usd) ? `Liquidity: ${money(c.liq_usd)}` : "",
    money(c.vol_24h) ? `24h volume: ${money(c.vol_24h)}` : "",
    Number.isFinite(ch) ? `24h change: ${ch >= 0 ? "+" : ""}${ch.toFixed(1)}%` : "",
    Number(c.buys_24h) + Number(c.sells_24h) > 0 ? `Trades in the last 24 hours: ${Number(c.buys_24h) || 0} buys, ${Number(c.sells_24h) || 0} sells` : "",
    c.dex ? `Main pool: ${c.dex}` : "",
    c.pool_created ? `Pool created: ${new Date(c.pool_created).toISOString().slice(0, 10)}` : "",
    `Contract: ${address}`,
  ].filter(Boolean);
  const summary =
    `<noscript><article><h1>${html(c.name)} ($${html(c.symbol)}) on ${html(chain)}</h1><p>${html(description)}</p>` +
    `<ul>${facts.map((f) => `<li>${html(f)}</li>`).join("")}</ul>` +
    `<p>On sasa you can buy and sell ${html(c.name)} with USDC in one tap, with no bridging and no gas token, and follow its live chart and trades.</p>` +
    related +
    `<p><a href="${SITE}/top/${listFor(network).slug}/">Top ${html(chain)} meme coins today</a> · <a href="${SITE}/top/${listFor(network, "gainers").slug}/">Biggest ${html(chain)} gainers</a> · <a href="${SITE}/top/${listFor(network, "new").slug}/">New ${html(chain)} meme coins</a> · <a href="${SITE}/explore/">Explore</a> · <a href="${SITE}/learn/">Guides</a></p></article></noscript>`;
  rw = rw.on("body", { element: (e) => e.append(summary, { html: true }) });
  return rw.transform(res);
}
